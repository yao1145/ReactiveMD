import { R as e, t } from "./default-components-B35-K5DU.js";
// src/presets/default.ts
var n = Object.freeze({
	id: "reactive-md/default",
	version: e,
	components: t
});
export { n as default, n as defaultPreset };
