import { A as e } from "./default-components-B35-K5DU.js";
import { d as t, n, p as r } from "./registry-DHpDpCD5.js";
import { c as i, i as a, l as o, o as s, r as c, s as l, u, v as d } from "./shareable-ksKOczg5.js";
import { i as f, n as p, r as m, t as h } from "./resources-DWUw49Zz.js";
// src/export/index.ts
function g(n, r) {
	let i = t(r);
	if (typeof n != "string" || !n.trim() || n.length > 33554432) throw TypeError("A standalone bundle must contain a nonempty script of at most 32 MiB.");
	return Object.freeze({
		script: n,
		seal: s(n, i),
		extensions: Object.freeze({
			protocol: "reactive-md-extensions/v1",
			components: Object.freeze(i.components.map((t) => Object.freeze({
				id: t.id,
				name: t.name,
				version: t.version,
				digest: e(t)
			})))
		})
	});
}
function _(e) {
	let a = t(e.config), s = e.document.extensions ?? {
		protocol: "reactive-md-extensions/v1",
		components: []
	}, c = f(s, a);
	c.push(...r(e.document, a)), c.push(...m({
		document: e.document,
		installed: n(a),
		externalNames: new Set(a.components.map((e) => e.name))
	}));
	let l = new Set(e.requiredResources ?? []), u = e.target;
	if (![
		"static",
		"ssr",
		"offline"
	].includes(u)) throw TypeError("Unknown export target.");
	for (let e of s.components) {
		let t = a.components.find((t) => t.id === e.id);
		if (!t) continue;
		for (let e of t.styles ?? []) l.add(e);
		let n = u === "offline" ? [
			"static",
			"interactive",
			"offline"
		] : [u];
		for (let e of n) t.capabilities[e] || c.push(p("local.extension.export-capability", `${t.id}@${t.version} does not support ${e} for ${u} export.`));
	}
	if (u === "offline") {
		if (!e.bundle?.script?.trim()) c.push(p("local.extension.bundle-missing", "Offline output requires an explicitly built standalone bundle."));
		else {
			c.push(...f(e.bundle.extensions, a));
			let t = e.bundle.seal;
			t && (t.protocol !== "reactive-md-bundle/v1" || t.sdkVersion !== "0.7.0" || t.configKey !== a.key || t.scriptDigest !== i(e.bundle.script)) && c.push(p("local.extension.bundle-integrity", "The bundle script or installed configuration differs from its sealed build manifest."));
			for (let t of s.components) e.bundle.extensions.components.some((e) => e.id === t.id && e.digest === t.digest) || c.push(p("local.extension.bundle-mismatch", `The standalone bundle does not include ${t.id}@${t.version}.`));
		}
	}
	let d = e.document.theme ?? "default", g = a.themes.find((e) => e.name === d);
	if (u === "offline" && g && e.bundle?.seal) {
		let t = e.bundle.seal.themes;
		Array.isArray(t) && t.some((e) => e.id === g.id && e.name === g.name && e.version === g.version && e.digest === o(g)) || c.push(p("local.extension.bundle-theme", `Bundle theme ${g.id}@${g.version} differs from the selected export theme. Rebuild the bundle.`));
	}
	d !== "default" && !g && c.push(p("local.extension.theme-missing", `Theme ${d} is not installed for export.`));
	let _ = h([...e.resources ?? [], ...g?.css ?? []]);
	c.push(..._.diagnostics);
	let v = new Map(_.resources.map((e) => [e.id, e]));
	for (let e of l) v.has(e) || c.push(p("local.extension.resource-missing", `Required style resource ${e} is missing.`));
	let y = Object.freeze([...v.values()]);
	return Object.freeze({
		target: u,
		extensions: s,
		resources: y,
		css: y.map((e) => e.css).join("\n"),
		diagnostics: Object.freeze(c),
		ok: c.length === 0
	});
}
function v(e) {
	if (e.document.source !== e.source) throw TypeError("The compiled document does not belong to this source.");
	let n = d(e.state);
	if (!n.ok) throw TypeError(n.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	let r = a(e.document, n.file);
	if (!r.ok) throw TypeError(r.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	let i = t(e.config);
	if (e.compileOptions?.hostComponents !== void 0 || e.compileOptions?.config && t(e.compileOptions.config).key !== i.key) throw TypeError("Conflicting export component configuration.");
	let o = _({
		...e,
		target: e.mode === "static" ? "static" : "offline"
	});
	if (!o.ok) throw TypeError(o.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	if (/data-rmd-extension-error\s*=|local-sdk-unavailable/.test(e.staticMarkup)) throw TypeError("Static output contains an unavailable extension component.");
	return c({
		...e,
		compileOptions: {
			...e.compileOptions,
			config: i
		},
		extensions: o.extensions,
		restoration: l(e.document, i, o.target, o.resources),
		resources: o.resources,
		runtimeScript: e.bundle?.script,
		css: `${e.css}\n${o.css}`
	});
}
export { s as createLocalBundleManifest, _ as createLocalExportPlan, l as createLocalRestorationRequirements, v as createLocalShareableHtml, g as defineLocalStandaloneBundle, i as localExportContentDigest, o as localThemeContractDigest, h as readLocalExportResources, m as validateLocalComponentContracts, f as validateLocalExtensionRequirements, u as validateLocalRestorationRequirements };
