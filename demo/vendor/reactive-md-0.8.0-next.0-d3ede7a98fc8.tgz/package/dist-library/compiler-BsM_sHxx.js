import { n as e, t } from "./compiler-core-BHoOCraa.js";
import { n } from "./math-display-CUtwV3Ky.js";
import { n as r, t as i } from "./options-DRZTLoJk.js";
// src/local/compiler.ts
function a(t, n) {
	return e(l(t, n));
}
function o(e, t, n) {
	let r, a = () => globalThis.performance?.now?.() ?? Date.now(), o = a(), s = {}, c = o, u = (e) => {
		let t = a();
		s[e] = t - c, c = t;
	};
	n?.semantic?.begin(i(t));
	let d = l(e, t, (e) => {
		r = e;
	}, n, u);
	return s.totalMs = a() - o, {
		result: d,
		parsed: r,
		...n?.semantic ? { semantic: n.semantic.stats } : {},
		timings: s
	};
}
function s(e) {
	return {
		ok: !1,
		diagnostics: [{
			code: "local.options.invalid",
			message: e.message,
			severity: "error",
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: e.key,
			...e.detail === void 0 ? {} : { params: { detail: e.detail } }
		}]
	};
}
function c(e) {
	return {
		...e?.parser ? { parser: e.parser } : {},
		...e?.semantic ? { semantic: e.semantic } : {},
		...e?.rowPlans ? { rowPlans: e.rowPlans } : {},
		display: e?.semantic ? (t, n) => e.semantic.display(t, n) : n
	};
}
function l(e, n, i, a, o) {
	let l = r(n);
	return l.ok ? t(e, n, l, c(a), i, o) : s(l);
}
export { o as n, a as t };
