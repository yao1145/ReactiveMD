import { $ as e, A as t, D as n, I as r, M as i, O as a, Q as o, a as s, c, i as l, it as u, nt as d, o as f, ot as p, r as m, rt as h, s as g, st as _, tt as v, u as y, x as b } from "./html-C8ehjOX3.js";
import { lt as x } from "./default-components-B35-K5DU.js";
import { p as S, u as C } from "./registry-core-cpcSrHKF.js";
import { t as w } from "./registry-DHpDpCD5.js";
// src/local/retention.ts
function T(e) {
	let n = /* @__PURE__ */ new Map();
	for (let r of t(e.nodes)) n.set(r.id, r);
	return n;
}
function E(e, t, n) {
	let r = e.bindingSlots?.[t.id];
	return r !== void 0 && Object.values(r).includes(n);
}
function D(e, t, n) {
	let r = t.name ? w(t.name) : void 0;
	if (r?.bindings) {
		let i = e.bindingSlots?.[t.id];
		for (let [e, a] of Object.entries(r.bindings)) if (t.attrs?.[a.bind] === n || e !== "value" && i?.[e] === n) return a.retain === !1 ? void 0 : a.initial;
	} else if (t.attrs?.bind === n || E(e, t, n)) return "initial";
}
function O(e) {
	let t = T(e), n = r(e), i = new Set(n?.retentionExclusions ?? []), a = /* @__PURE__ */ new Map();
	for (let [r, o] of Object.entries(e.bindings)) {
		let s = o.nodeIds.flatMap((e) => {
			let n = t.get(e);
			return n ? [n] : [];
		});
		if (!s.length || r.startsWith("@") || i.has(r)) continue;
		let c;
		if (n === void 0) {
			let t = s.map((t) => D(e, t, r));
			if (t.some((e) => e === void 0)) continue;
			c = t;
		} else {
			let e = n.bindingAttributes?.[r]?.initial ?? "initial";
			c = s.map(() => e);
		}
		let l = s.flatMap((e, t) => Object.hasOwn(e.attrs ?? {}, c[t]) ? [e.attrs[c[t]]] : []).sort();
		a.set(r, {
			type: o.type,
			initialDefinition: JSON.stringify([o.initial, l])
		});
	}
	return a;
}
function k(e, t) {
	return Object.freeze({
		name: e,
		reason: t
	});
}
function A(e) {
	let t = O(e.previous), n = O(e.next), r = {}, i = [], a = [];
	for (let o of Object.keys(e.state).sort()) {
		if (o.startsWith("@")) {
			a.push(k(o, "internal"));
			continue;
		}
		if (!Object.hasOwn(e.previous.bindings, o) || !Object.hasOwn(e.next.bindings, o)) {
			a.push(k(o, "unknown"));
			continue;
		}
		let s = t.get(o), c = n.get(o);
		if (!s || !c) {
			a.push(k(o, "unretainable"));
			continue;
		}
		if (s.type !== c.type) {
			a.push(k(o, "type"));
			continue;
		}
		if (s.initialDefinition !== c.initialDefinition) {
			a.push(k(o, "initial"));
			continue;
		}
		let l = e.state[o];
		r[o] = Array.isArray(l) ? Object.freeze([...l]) : l, i.push(o);
	}
	return Object.freeze({
		values: Object.freeze(r),
		retained: Object.freeze(i),
		dropped: Object.freeze(a)
	});
}
function j(e, t, n) {
	return Object.freeze({
		retained: Object.freeze([...e]),
		dropped: Object.freeze(t.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...n])
	});
}
function M(e, t) {
	let n = Object.keys(t.values).sort();
	if (!e.setParameters(t.values).length) return j(n, t.dropped, []);
	let r = [], i = [...t.dropped], a = [];
	for (let o of n) {
		let n = e.setParameter(o, t.values[o]);
		n.length ? (i.push(k(o, "invalid")), a.push(...n)) : r.push(o);
	}
	return i.sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name)), j(r, i, a);
}
// src/local/runtime.ts
var N = 1e-9, ee = 200;
function P(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function te(e) {
	return {
		...e,
		range: { ...e.range }
	};
}
function F(e, t) {
	return Array.isArray(e) || Array.isArray(t) ? !Array.isArray(e) || !Array.isArray(t) || e.length !== t.length ? !1 : e.every((e, n) => e === t[n]) : e === t;
}
function I(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= N * Math.max(1, Math.abs(r));
}
function ne(e) {
	for (let [t, n] of Object.entries(e)) Array.isArray(n) && !Object.isFrozen(n) && (e[t] = Object.freeze([...n]));
	return Object.freeze(e);
}
function L(e, t, n, r) {
	let i = Math.max(0, Math.min(e.source.length, t.range.start)), a = e.source.slice(0, i).split("\n");
	return {
		code: n,
		message: C(r),
		severity: "error",
		range: {
			start: i,
			end: Math.max(i + 1, Math.min(e.source.length, t.range.end))
		},
		line: a.length,
		column: (a.at(-1) ?? "").length + 1,
		messageKey: r.key,
		...r.params ? { params: r.params } : {}
	};
}
function R(e, t, n) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1,
		...n ? {
			messageKey: n.key,
			...n.params ? { params: n.params } : {}
		} : {}
	};
}
function z(e, t) {
	return e.attrs?.[t];
}
function B(e, t) {
	let n = z(e, t);
	if (n === "true") return !0;
	if (n === "false") return !1;
}
function V(e, t) {
	let n = z(e, t);
	if (n === void 0) return;
	let r = Number(n);
	return Number.isFinite(r) ? r : void 0;
}
function H(e) {
	return _(e);
}
function U(e, t) {
	return {
		ok: !1,
		detail: S(e, t)
	};
}
function W(e, t) {
	if (t !== void 0) return z(e, t);
}
function re(e, t) {
	if (t !== void 0) return V(e, t);
}
function ie(e, t, n, r = {}) {
	for (let a of n) if (a.kind === "date") {
		if (!i(t)) return U("local.runtime.value.date-invalid");
		let n = r.required ?? (a.required !== void 0 && B(e, a.required) === !0);
		if (t === "" && n) return U("local.runtime.value.date-required");
		let o = r.min ?? W(e, a.min), s = r.max ?? W(e, a.max);
		if (t !== "" && o && t < o) return U("local.runtime.value.date-earlier", { min: o });
		if (t !== "" && s && t > s) return U("local.runtime.value.date-later", { max: s });
	} else if (a.kind === "required") {
		let n = r.required ?? B(e, a.required) === !0;
		if (t === "" && n) return U("local.runtime.value.field-required");
	} else if (a.kind === "length") {
		let n = H(t), r = re(e, a.min), i = re(e, a.max);
		if (r !== void 0 && r > 0 && t !== "" && n < r) return U("local.runtime.value.min-length", { min: r });
		if (i !== void 0 && n > i) return U("local.runtime.value.max-length", { max: i });
	} else if (a.kind === "email" && (W(e, a.type) ?? "text") === a.value && t !== "") {
		if (t.length > 254) return U("local.runtime.value.email-length", { limit: 254 });
		if (!x(t)) return U("local.runtime.value.email-invalid");
	}
	return {
		ok: !0,
		value: t
	};
}
var G = /* @__PURE__ */ new Map();
function ae(e) {
	if (!e.name) return K;
	let t = G.get(e.name);
	if (t !== void 0) return t ?? K;
	let n = w(e.name), r = n ? o(n) : K;
	return G.set(e.name, n ? r : null), r;
}
var K = Object.freeze([]);
function q(e, t, n, r, a, o = !1) {
	switch (e.type) {
		case "number": {
			if (typeof n != "number" || !Number.isFinite(n)) return U("local.runtime.value.finite-number", { name: e.name });
			let i = e.step ?? 1, a = e.min ?? 0;
			for (let i of t) {
				let t = r(i, "min");
				if (t.present && !t.ok) return U("local.runtime.value.constraint", {
					name: e.name,
					attribute: "min"
				});
				if (t.present && t.ok) {
					if (typeof t.value != "number" || !Number.isFinite(t.value)) return U("local.runtime.value.constraint", {
						name: e.name,
						attribute: "min"
					});
					if (a = t.value, n < t.value) return U("local.runtime.value.min", {
						name: e.name,
						min: t.value
					});
				}
				let o = r(i, "max");
				if (o.present && !o.ok) return U("local.runtime.value.constraint", {
					name: e.name,
					attribute: "max"
				});
				if (o.present && o.ok) {
					if (typeof o.value != "number" || !Number.isFinite(o.value)) return U("local.runtime.value.constraint", {
						name: e.name,
						attribute: "max"
					});
					if (n > o.value) return U("local.runtime.value.max", {
						name: e.name,
						max: o.value
					});
				}
				if (t.present && t.ok && o.present && o.ok && typeof t.value == "number" && typeof o.value == "number" && t.value > o.value) return U("local.runtime.value.constraint-range", { name: e.name });
			}
			return e.min !== void 0 && n < e.min ? U("local.runtime.value.min", {
				name: e.name,
				min: e.min
			}) : e.max !== void 0 && n > e.max ? U("local.runtime.value.max", {
				name: e.name,
				max: e.max
			}) : i > 0 && !I(n, a, i) ? U("local.runtime.value.step", {
				name: e.name,
				step: i,
				base: a
			}) : {
				ok: !0,
				value: n
			};
		}
		case "boolean": return typeof n == "boolean" ? {
			ok: !0,
			value: n
		} : U("local.runtime.value.boolean", { name: e.name });
		case "string": {
			if (typeof n != "string") return U("local.runtime.value.string", { name: e.name });
			let s = u(n);
			if (s) return U("local.runtime.value.budget", {
				name: e.name,
				detail: C(s),
				detailKey: s.key,
				...s.params
			});
			for (let s of t) {
				let t = a?.get(s.id) ?? (o ? ae(s) : K);
				if (!t.length) continue;
				let c = {};
				for (let n of t) {
					if (n.kind === "date") {
						for (let t of ["min", "max"]) {
							if (n[t] === void 0) continue;
							let a = r(s, t);
							if (a.present) {
								if (!a.ok || typeof a.value != "string" || !i(a.value)) return U("local.runtime.value.constraint-date", {
									name: e.name,
									attribute: t
								});
								c[t] = a.value;
							}
						}
						let t = c.min ?? W(s, n.min), a = c.max ?? W(s, n.max);
						if (t && a && i(t) && i(a) && t > a) return U("local.runtime.value.constraint-range", { name: e.name });
					}
					if ((n.kind === "date" || n.kind === "required" ? n.required : void 0) !== void 0) {
						let t = r(s, "required");
						if (t.present) {
							if (!t.ok || typeof t.value != "boolean") return U("local.runtime.value.constraint", {
								name: e.name,
								attribute: "required"
							});
							c.required = t.value;
						}
					}
				}
				let l = ie(s, n, t, c);
				if (!l.ok) return l;
			}
			return e.options?.length && !e.options.includes(n) ? U("local.runtime.value.option", {
				value: n,
				options: e.options.join(", ")
			}) : {
				ok: !0,
				value: n
			};
		}
		case "array": {
			if (!Array.isArray(n)) return U("local.runtime.value.array", { name: e.name });
			let t = u(n);
			if (t) return U("local.runtime.value.budget", {
				name: e.name,
				detail: C(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "string") return U("local.runtime.value.array-members", { name: e.name });
			if (e.family === "collection") return e.maxItems !== void 0 && n.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
			let r = /* @__PURE__ */ new Set();
			for (let t of n) {
				if (e.options && !e.options.includes(t)) return U("local.runtime.value.checklist-option", { value: t });
				r.add(t);
			}
			let i = e.options ? e.options.filter((e) => r.has(e)) : [...r];
			return e.maxItems !== void 0 && i.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: i
			};
		}
		case "number-array": {
			if (!Array.isArray(n)) return U("local.runtime.value.number-array", { name: e.name });
			let t = u(n);
			if (t) return U("local.runtime.value.budget", {
				name: e.name,
				detail: C(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "number" || !Number.isFinite(t)) return U("local.runtime.value.number-array-members", { name: e.name });
			return e.maxItems !== void 0 && n.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
		}
		case "null": return n === null ? {
			ok: !0,
			value: n
		} : U("local.runtime.value.null", { name: e.name });
	}
	return U("local.runtime.value.unsupported-type", { name: e.name });
}
function J(t) {
	return t instanceof e ? t : new e("expression-eval", t instanceof Error ? t.message : String(t), 0);
}
function Y(e, t) {
	switch (e) {
		case "string": {
			if (typeof t != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string" }
			};
			let e = u(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t
			};
		}
		case "number": return typeof t == "number" && Number.isFinite(t) ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "number" }
		};
		case "boolean": return typeof t == "boolean" ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "boolean" }
		};
		case "array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			for (let e of t) if (typeof e != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			let e = u(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		case "number-array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			for (let e of t) if (typeof e != "number" || !Number.isFinite(e)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			let e = u(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		default: return {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: String(e) }
		};
	}
}
function X(e, t) {
	let n = t.get(e);
	if (n) return {
		expression: n,
		error: null
	};
	try {
		let n = v(e);
		if (t.size >= ee) {
			let e = t.keys().next().value;
			e !== void 0 && t.delete(e);
		}
		return t.set(e, n), {
			expression: n,
			error: null
		};
	} catch (e) {
		return {
			expression: null,
			error: J(e)
		};
	}
}
function oe(n, i) {
	let o = /* @__PURE__ */ new Map();
	for (let e of t(n.nodes)) o.set(e.id, e);
	let s = {}, l = /* @__PURE__ */ new Map();
	for (let [t, r] of Object.entries(n.bindings)) {
		let n = u(r.initial);
		if (n) throw new e("expression-budget", `Parameter "${t}": ${C(n)}`, 0);
		s[t] = P(r.initial);
		let i = [];
		for (let e of r.nodeIds) {
			let t = o.get(e);
			t && i.push(t);
		}
		l.set(t, i);
	}
	let d = /* @__PURE__ */ new Map();
	for (let [e, t] of Object.entries(n.bindingSlots ?? {})) d.set(e, { ...t });
	let f = r(n), p = new Map(Object.entries(f?.valueRules ?? {})), m = f === void 0, _ = /* @__PURE__ */ new Map();
	if (f) for (let e of f.slotRelations) {
		let t = d.get(e.nodeId), n = t?.[e.lower], r = t?.[e.upper];
		if (!n || !r) continue;
		let i = _.get(e.nodeId) ?? [];
		i.push({
			lower: n,
			upper: r
		}), _.set(e.nodeId, i);
	}
	else for (let [e, t] of d) t.start && t.end && _.set(e, [{
		lower: t.start,
		upper: t.end
	}]);
	let v = /* @__PURE__ */ new Map();
	for (let [e, t] of Object.entries(n.bindings)) for (let n of t.nodeIds) {
		if (d.has(n)) continue;
		let t = v.get(n);
		(t === void 0 || t.startsWith("@") && !e.startsWith("@")) && v.set(n, e);
	}
	let y = Object.freeze(Object.keys(n.bindings).filter((e) => !e.startsWith("@")).sort()), b = /* @__PURE__ */ new Map();
	for (let [e, t] of d) for (let n of Object.values(t)) {
		if (n.startsWith("@")) continue;
		let t = b.get(n) ?? /* @__PURE__ */ new Set();
		t.add(e), b.set(n, t);
	}
	let x = n.computations ?? {}, S = Object.keys(x), w = /* @__PURE__ */ new Map();
	for (let [e, t] of Object.entries(x)) {
		let n = X(t.source, i);
		n.expression && w.set(e, n.expression);
	}
	let { order: T, cyclic: E } = a(x), D = {}, O = /* @__PURE__ */ new Map();
	for (let t of T) {
		let n = x[t];
		if (!n || n.kind !== "const") continue;
		if (Object.hasOwn(n, "value")) {
			let r = n.value, i = h(r);
			if (i) {
				O.set(t, new e("expression-budget", `Constant "${t}": ${i}`, 0));
				continue;
			}
			D[t] = P(r);
			continue;
		}
		let r = w.get(t);
		if (!r) O.set(t, new e("expression-eval", `Constant "${t}" cannot be evaluated.`, 0));
		else try {
			let n = r.evaluate({ ...D }), i = h(n);
			if (i) {
				O.set(t, new e("expression-budget", `Constant "${t}": ${i}`, 0));
				continue;
			}
			D[t] = P(n);
		} catch (e) {
			O.set(t, J(e));
		}
	}
	let k = /* @__PURE__ */ new Map();
	for (let t of E) k.set(t, new e("expression-cycle", `Computation "${t}" is part of a dependency cycle.`, 0));
	let A = [];
	if (Array.isArray(n.validations)) for (let e of n.validations) {
		if (!g(e)) continue;
		let t = X(e.expression, i);
		A.push({
			rule: e,
			expression: t.expression,
			error: t.error
		});
	}
	return {
		document: n,
		nodeIndex: o,
		controls: l,
		slotKeys: d,
		publicNames: y,
		publicSlotOwners: b,
		initial: s,
		valueRules: p,
		legacyValueRules: m,
		slotRelations: _,
		bindingByNode: v,
		computationMetadata: x,
		computationNames: S,
		computationOrder: T,
		cyclicComputations: E,
		computationExpressions: w,
		constValues: D,
		constErrors: O,
		cycleErrors: k,
		validationRules: A,
		validationLineStarts: c(typeof n.source == "string" ? n.source : "")
	};
}
function se(e) {
	return !e || e.syntax !== "local" ? "createLocalRuntime requires a local interaction document." : e.syntaxVersion !== void 0 && e.syntaxVersion !== "local-draft-3" || e.versionDeclaration && e.versionDeclaration.version !== "local-draft-3" ? `createLocalRuntime requires ${b}; migrate the source before constructing a runtime.` : null;
}
function ce(e, t) {
	return (e.controls.get(t.name) ?? [])[0] ?? (t.owner ? e.nodeIndex.get(t.owner) : void 0) ?? (t.nodeIds[0] ? e.nodeIndex.get(t.nodeIds[0]) : void 0);
}
function Z(e, t, n) {
	let r = ce(e, t);
	return r ? L(e.document, r, "local.runtime.value", n) : R("local.runtime.value", C(n));
}
function Q(e, t, n) {
	let r = e.slotRelations.get(t);
	return r?.length ? r.some(({ lower: e, upper: t }) => {
		let r = n[e], i = n[t];
		return typeof r == "number" && typeof i == "number" && r > i;
	}) : !1;
}
function le(e, t) {
	let n = e.nodeIndex.get(t);
	return n ? L(e.document, n, "local.runtime.value", S("local.runtime.value.range-order")) : R("local.runtime.value", C(S("local.runtime.value.range-order")));
}
var ue = /* @__PURE__ */ new WeakMap();
function $(e) {
	return Object.freeze({
		ok: e.ok,
		changed: e.changed,
		revision: e.revision,
		retained: Object.freeze([...e.retained]),
		dropped: Object.freeze(e.dropped.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...e.diagnostics])
	});
}
function de(e, t, n) {
	let r = ue.get(e);
	if (!r) throw TypeError("updateLocalRuntime requires a runtime created by createLocalRuntime.");
	return r.update(t, n?.notify !== !1);
}
function fe(e) {
	ue.get(e)?.notify();
}
function pe(r, i) {
	let a = se(r);
	if (a) throw Error(a);
	let o = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), h = oe(r, c), g = () => h, _ = {};
	for (let [e, t] of Object.entries(r.externals ?? {})) {
		let n = i?.externalValues?.[e];
		if (n === void 0) continue;
		let r = Y(t.type, n);
		r.ok && (_[e] = r.value);
	}
	let b = (e) => {
		let t = {};
		for (let [n, r] of Object.entries(e.document.externals ?? {})) {
			if (!Object.hasOwn(_, n)) continue;
			let e = Y(r.type, _[n]);
			e.ok && (t[n] = e.value);
		}
		return t;
	}, x = (e, t, n, r = g()) => {
		let i = r.document.dynamicConstraints?.[e.id]?.[t];
		if (!i) return { present: !1 };
		let a = X(i.source, c);
		if (!a.expression) return {
			present: !0,
			ok: !1
		};
		try {
			let e = a.expression.evaluate(n), t = i.numeric;
			return t && (typeof e != "number" || !Number.isFinite(e) || t.integer === !0 && !Number.isInteger(e) || t.min !== void 0 && e < t.min || t.max !== void 0 && e > t.max) ? {
				present: !0,
				ok: !1
			} : {
				present: !0,
				ok: !0,
				value: e
			};
		} catch {
			return {
				present: !0,
				ok: !1
			};
		}
	}, w = h.initial, T = 0, E = {}, D = {}, O = {
		revision: 0,
		state: ne({})
	}, k = !1, j = null, M = /* @__PURE__ */ new Set(), N = /* @__PURE__ */ new Map(), I = () => {
		if (k) throw Error("The local interaction runtime has been disposed.");
	}, z = (t, r) => {
		let i = b(t), a = /* @__PURE__ */ new Map();
		for (let n of Object.keys(t.document.externals ?? {})) Object.hasOwn(i, n) || a.set(n, new e("external-missing", "External data \"" + n + "\" is not available.", 0));
		let o = {}, s = /* @__PURE__ */ new Map();
		if (t.computationNames.length > 0) {
			let e = n(t.computationMetadata, t.computationOrder, t.computationExpressions, {
				...r,
				...i
			}, t.constValues, a);
			o = e.values, s = e.errors;
			for (let [e, n] of t.constErrors) Object.hasOwn(o, e) || s.set(e, n);
			for (let [e, n] of t.cycleErrors) Object.hasOwn(o, e) || s.set(e, n);
		}
		let c = {};
		for (let [e, t] of Object.entries(r)) c[e] = t;
		for (let [e, t] of Object.entries(i)) c[e] = t;
		for (let [e, t] of Object.entries(o)) c[e] = t;
		for (let [e, t] of [...a, ...s]) Object.hasOwn(o, e) || Object.defineProperty(c, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw t;
			}
		});
		let l = {};
		for (let [e, t] of Object.entries(r)) l[e] = t;
		for (let [e, t] of Object.entries(i)) l[e] = t;
		for (let [e, t] of Object.entries(o)) l[e] = t;
		return {
			values: o,
			errors: s,
			environment: c,
			snapshotState: l
		};
	}, B = () => {
		let e = z(g(), w);
		e.values, e.errors, E = e.environment, D = e.snapshotState;
	}, V = (e, t = g(), n = w) => {
		let r;
		return (i, a) => t.document.dynamicConstraints?.[i.id]?.[a] ? (r ??= z(t, {
			...n,
			...e
		}).environment, x(i, a, r, t)) : { present: !1 };
	}, H = () => {
		O = {
			revision: T,
			state: ne(D)
		};
	}, U = () => {
		for (let e of M) e();
	}, W = (e) => {
		w = e, T += 1, B(), H(), U();
	}, re = (e) => {
		if (I(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setExternalValues requires an object of external values.");
		let t = [], n = {}, r = Object.keys(e).sort();
		for (let i of r) {
			if (i === "__proto__") {
				t.push(R("local.runtime.external", "External names cannot be \"__proto__\"."));
				continue;
			}
			let r = g().document.externals ?? {}, a = Object.hasOwn(r, i) ? r[i] : void 0;
			if (!a) {
				let e = S("local.runtime.external", { name: i });
				t.push(R("local.runtime.external", C(e), e));
				continue;
			}
			let o = Y(a.type, e[i]);
			if (o.ok) n[i] = o.value;
			else {
				let e = S(o.key, {
					name: i,
					...o.params ?? {}
				});
				t.push(R("local.runtime.external", C(e), e));
			}
		}
		if (t.length) return t;
		if (!r.some((e) => !F(_[e], n[e]))) return [];
		for (let [e, t] of Object.entries(n)) _[e] = t;
		return T += 1, B(), H(), U(), [];
	}, ie = (e) => {
		I();
		let t = g(), n = [], r = {}, i = Object.keys(e).sort(), a = V(e);
		for (let o of i) {
			if (o === "__proto__") {
				n.push(R("local.runtime.parameter", "Parameter names cannot be \"__proto__\"."));
				continue;
			}
			if (o.startsWith("@")) {
				n.push(R("local.runtime.parameter", `Internal parameter "${o}" cannot be written by name.`));
				continue;
			}
			if (!Object.hasOwn(t.document.bindings, o)) {
				n.push(R("local.runtime.parameter", `Unknown parameter "${o}".`));
				continue;
			}
			let i = t.document.bindings[o], s = q(i, t.controls.get(o) ?? [], e[o], a, t.valueRules, t.legacyValueRules);
			s.ok ? r[o] = P(s.value) : n.push(Z(t, i, s.detail));
		}
		if (n.length) return n;
		if (!i.some((e) => !F(w[e], r[e]))) return [];
		let o = {
			...w,
			...r
		}, s = /* @__PURE__ */ new Set();
		for (let e of i) for (let n of t.publicSlotOwners.get(e) ?? []) s.add(n);
		for (let e of [...s].sort()) Q(t, e, o) && n.push(le(t, e));
		return n.length ? n : (W(o), []);
	}, G = (e) => {
		let t = o.get(e);
		if (!t) {
			if (t = v(e), o.size >= ee) {
				let e = o.keys().next().value;
				e !== void 0 && o.delete(e);
			}
			o.set(e, t);
		}
		return t;
	}, ae = () => {
		let e = g(), t = [], n = typeof e.document.source == "string" ? e.document.source : "";
		for (let r of e.validationRules) {
			if (r.error) {
				t.push(y(n, e.validationLineStarts, r.rule.range, m, f(`Validation expression is invalid: ${r.error.message}`)));
				continue;
			}
			if (!r.expression) continue;
			let i;
			try {
				i = r.expression.evaluate(E);
			} catch (i) {
				t.push(y(n, e.validationLineStarts, r.rule.range, m, f(`Validation expression failed: ${i instanceof Error ? i.message : String(i)}`)));
				continue;
			}
			typeof i == "boolean" ? i || t.push(y(n, e.validationLineStarts, r.rule.range, l, K(r.rule.message))) : t.push(y(n, e.validationLineStarts, r.rule.range, m, "Validation expression must evaluate to a boolean."));
		}
		return t;
	}, K = (e) => {
		let t;
		try {
			t = d(e, E);
		} catch {
			t = s;
		}
		return f(t);
	}, J = (e, t) => {
		let n = A({
			previous: h.document,
			state: w,
			next: e
		}), r = {};
		for (let [t, n] of Object.entries(e.bindings)) r[t] = P(n.initial);
		let i = /* @__PURE__ */ new Map();
		for (let e of n.dropped) i.set(e.name, Object.freeze({ ...e }));
		let a = [], o = {}, s = [];
		for (let c of n.retained) {
			let l = e.bindings[c];
			if (!l) continue;
			let u = q(l, t.controls.get(c) ?? [], n.values[c], V(n.values, t, r), t.valueRules, t.legacyValueRules);
			u.ok ? (o[c] = P(u.value), s.push(c)) : (a.push(Z(t, l, u.detail)), i.set(c, Object.freeze({
				name: c,
				reason: "invalid"
			})));
		}
		let c = {
			...r,
			...o
		}, l = /* @__PURE__ */ new Set();
		for (let e of s) for (let n of t.publicSlotOwners.get(e) ?? []) l.add(n);
		let u = !1;
		for (let e of [...l].sort()) if (Q(t, e, c)) {
			u = !0;
			break;
		}
		let d;
		if (!u) Object.assign(r, o), d = s;
		else {
			d = [];
			for (let e of s) {
				let n = r[e];
				r[e] = o[e];
				let s = !1;
				for (let n of [...t.publicSlotOwners.get(e) ?? []].sort()) Q(t, n, r) && (a.push(le(t, n)), s = !0);
				s ? (r[e] = n, i.set(e, Object.freeze({
					name: e,
					reason: "invalid"
				}))) : d.push(e);
			}
		}
		for (let [n, o] of t.slotRelations) if (Q(t, n, r)) {
			for (let t of o) for (let n of [t.lower, t.upper]) {
				let t = e.bindings[n];
				if (!t) continue;
				r[n] = P(t.initial);
				let a = d.indexOf(n);
				a >= 0 && d.splice(a, 1), i.set(n, Object.freeze({
					name: n,
					reason: "invalid"
				}));
			}
			if (a.push(le(t, n)), Q(t, n, r)) return {
				values: {},
				retained: [],
				dropped: [],
				diagnostics: []
			};
		}
		let f = !0;
		for (; f;) {
			let n = V({}, t, r), o = [];
			for (let i of d) {
				let s = e.bindings[i], c = q(s, t.controls.get(i) ?? [], r[i], n, t.valueRules, t.legacyValueRules);
				c.ok || (a.push(Z(t, s, c.detail)), o.push(i));
			}
			for (let t of o) r[t] = P(e.bindings[t].initial), d.splice(d.indexOf(t), 1), i.set(t, Object.freeze({
				name: t,
				reason: "invalid"
			}));
			f = o.length > 0;
		}
		let p = [...i.values()].sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name));
		return d.sort(), {
			values: r,
			retained: d,
			dropped: p,
			diagnostics: a
		};
	}, ce = (e, t) => {
		if (I(), e === h.document) return $({
			ok: !0,
			changed: !1,
			revision: T,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		if (se(e)) return $({
			ok: !1,
			changed: !1,
			revision: T,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let n;
		try {
			n = oe(e, c);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: T,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let r = J(e, n);
		if (Object.keys(r.values).length === 0 && Object.keys(e.bindings).length > 0) return $({
			ok: !1,
			changed: !1,
			revision: T,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let i;
		try {
			i = z(n, r.values);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: T,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let a = b(n);
		for (let e of Object.keys(_)) delete _[e];
		if (Object.assign(_, a), h = n, w = r.values, i.values, i.errors, E = i.environment, D = i.snapshotState, j = null, T += 1, H(), t) for (let e of M) e();
		return $({
			ok: !0,
			changed: !0,
			revision: T,
			retained: r.retained,
			dropped: r.dropped,
			diagnostics: r.diagnostics
		});
	}, de = (e) => {
		let n = /* @__PURE__ */ new Set();
		for (let r of t([e])) n.add(r.id);
		return n;
	}, fe = {
		get document() {
			return h.document;
		},
		snapshot() {
			return I(), O;
		},
		get(e, t) {
			I();
			let n = g(), r = n.nodeIndex.get(e.id);
			if (!r) return null;
			let i = t === void 0 ? n.slotKeys.get(r.id)?.value ?? n.bindingByNode.get(r.id) ?? p(r) : n.slotKeys.get(r.id)?.[t];
			return i && Object.hasOwn(w, i) ? P(w[i]) : null;
		},
		set(e, t, n) {
			I();
			let r = g(), i = r.nodeIndex.get(e.id);
			if (!i) return [L(r.document, e, "local.runtime.binding", S("local.runtime.binding.no-writable"))];
			let a = r.slotKeys.get(i.id), o;
			if (n === void 0) {
				if (a && !a.value) return [L(r.document, i, "local.runtime.binding", S("local.runtime.binding.needs-slot"))];
				o = a?.value ?? r.bindingByNode.get(i.id) ?? p(i);
			} else if (o = a?.[n], !o) return [L(r.document, i, "local.runtime.binding", S("local.runtime.binding.unknown-slot", { slot: n }))];
			let s = Object.hasOwn(r.document.bindings, o) ? r.document.bindings[o] : void 0;
			if (!s) return [L(r.document, i, "local.runtime.binding", S("local.runtime.binding.no-writable"))];
			let c = q(s, r.controls.get(o) ?? [], t, V({ [o]: t }), r.valueRules, r.legacyValueRules);
			if (!c.ok) return [L(r.document, i, "local.runtime.value", c.detail)];
			let l = P(c.value);
			if (F(w[o], l)) return [];
			let u = {
				...w,
				[o]: l
			};
			return Q(r, i.id, u) ? [L(r.document, i, "local.runtime.value", S("local.runtime.value.range-order"))] : (W(u), []);
		},
		setMany(e, t) {
			I();
			let n = g(), r = n.nodeIndex.get(e.id);
			if (!r) return [L(n.document, e, "local.runtime.binding", S("local.runtime.binding.no-writable"))];
			let i = n.slotKeys.get(r.id);
			if (!i) return [L(n.document, r, "local.runtime.binding", S("local.runtime.binding.no-multi-slot"))];
			let a = Object.entries(t);
			if (!a.length) return [];
			let o = { ...w }, s = z(n, {
				...w,
				...Object.fromEntries(a.map(([e, t]) => [i[e], t]))
			}).environment;
			for (let [e, t] of a) {
				let a = i[e];
				if (!a || !Object.hasOwn(n.document.bindings, a)) return [L(n.document, r, "local.runtime.binding", S("local.runtime.binding.unknown-slot", { slot: e }))];
				let c = q(n.document.bindings[a], n.controls.get(a) ?? [], t, (e, t) => x(e, t, s), n.valueRules, n.legacyValueRules);
				if (!c.ok) return [L(n.document, r, "local.runtime.value", c.detail)];
				o[a] = P(c.value);
			}
			return Q(n, r.id, o) ? [L(n.document, r, "local.runtime.value", S("local.runtime.value.range-order"))] : (a.every(([e, t]) => F(w[i[e]], t)) || W(o), []);
		},
		parameterNames() {
			return I(), g().publicNames;
		},
		getParameter(e) {
			I();
			let t = g();
			if (!e.startsWith("@") && Object.hasOwn(t.document.bindings, e)) return Object.hasOwn(w, e) ? P(w[e]) : void 0;
		},
		getParameters() {
			I();
			let e = g(), t = {};
			for (let n of e.publicNames) {
				let e = w[n];
				t[n] = Array.isArray(e) ? Object.freeze([...e]) : e;
			}
			return Object.freeze(t);
		},
		setParameter(e, t) {
			I();
			let n = Object.create(null);
			return n[e] = t, ie(n);
		},
		setParameters(e) {
			if (I(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setParameters requires an object of parameter values.");
			return ie(e);
		},
		getExternal(e) {
			if (I(), Object.hasOwn(g().document.externals ?? {}, e) && Object.hasOwn(_, e)) return P(_[e]);
		},
		getExternalValues() {
			I();
			let e = {};
			for (let [t, n] of Object.entries(_)) e[t] = Array.isArray(n) ? Object.freeze([...n]) : n;
			return Object.freeze(e);
		},
		setExternalValues(e) {
			return re(e);
		},
		evaluate(e) {
			I();
			let t = G(e).evaluate(E);
			return Array.isArray(t) ? t.slice() : t;
		},
		validate() {
			if (I(), j && j.revision === T) return j.diagnostics.map(te);
			let e = ae();
			return j = {
				revision: T,
				diagnostics: e
			}, e.map(te);
		},
		text(e) {
			return I(), d(e, E);
		},
		reset(t) {
			I();
			let n = g(), r = n.nodeIndex.get(t.id);
			if (!r) return;
			let i = de(r), a = { ...w };
			for (let [t, r] of Object.entries(n.document.bindings)) {
				if (!(n.controls.get(t) ?? []).some((e) => i.has(e.id))) continue;
				let o = u(r.initial);
				if (o) throw new e("expression-budget", `Parameter "${t}": ${C(o)}`, 0);
				a[t] = P(r.initial);
			}
			for (let e of i) N.set(e, (N.get(e) ?? 0) + 1);
			W(a);
		},
		resetToken(e) {
			I();
			let t = g().nodeIndex.get(e.id);
			return t ? N.get(t.id) ?? 0 : 0;
		},
		subscribe(e) {
			return I(), M.add(e), () => {
				M.delete(e);
			};
		},
		dispose() {
			k || (k = !0, M.clear(), o.clear(), c.clear(), h.computationExpressions.clear(), h.constErrors.clear(), h.cycleErrors.clear(), h.validationRules.length = 0, N.clear());
		}
	};
	return ue.set(fe, {
		update: ce,
		notify() {
			if (!k) for (let e of M) e();
		}
	}), B(), H(), fe;
}
export { A as a, M as i, fe as n, de as r, pe as t };
