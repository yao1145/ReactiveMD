/**
 * Pure text transformations behind the Markdown source toolbar.
 *
 * Every command receives the current source value and selection, clamps the
 * selection, and returns a new value plus the selection that should be
 * restored on the textarea. Nothing in this module touches the DOM.
 *
 * Commands that insert human-readable text accept an optional locale and
 * default to English, so direct callers keep their original output.
 */
import type { EditorEdit, EditorLocale, EditorSelection } from './command-types.js';
export type { EditorEdit, EditorSelection } from './command-types.js';
export interface InsertTemplateOptions {
    block?: boolean;
}
export declare function formatBold(value: string, selection: EditorSelection, locale?: EditorLocale): EditorEdit;
export declare function formatItalic(value: string, selection: EditorSelection, locale?: EditorLocale): EditorEdit;
export declare function formatStrike(value: string, selection: EditorSelection, locale?: EditorLocale): EditorEdit;
export declare function formatInlineCode(value: string, rawSelection: EditorSelection, locale?: EditorLocale): EditorEdit;
export declare function formatHeading(value: string, rawSelection: EditorSelection, level: 0 | 1 | 2 | 3 | 4 | 5 | 6): EditorEdit;
export declare function formatBulletList(value: string, selection: EditorSelection): EditorEdit;
export declare function formatOrderedList(value: string, selection: EditorSelection): EditorEdit;
export declare function formatTaskList(value: string, selection: EditorSelection): EditorEdit;
export declare function formatQuote(value: string, selection: EditorSelection): EditorEdit;
export declare function indentSelection(value: string, rawSelection: EditorSelection): EditorEdit;
export declare function outdentSelection(value: string, rawSelection: EditorSelection): EditorEdit;
export declare function insertLink(value: string, rawSelection: EditorSelection, locale?: EditorLocale): EditorEdit;
export declare function insertImage(value: string, rawSelection: EditorSelection, locale?: EditorLocale): EditorEdit;
export declare function insertCodeBlock(value: string, rawSelection: EditorSelection, locale?: EditorLocale): EditorEdit;
export declare function insertTable(value: string, rawSelection: EditorSelection, locale?: EditorLocale): EditorEdit;
export declare function insertDivider(value: string, rawSelection: EditorSelection): EditorEdit;
export declare function insertText(value: string, rawSelection: EditorSelection, text: string): EditorEdit;
export declare function insertTemplate(value: string, rawSelection: EditorSelection, template: string, options?: InsertTemplateOptions): EditorEdit;
export type EditorListType = 'bullet' | 'ordered' | 'task';
export interface EditorFormatState {
    headingLevel: 0 | 1 | 2 | 3 | 4 | 5 | 6;
    bold: boolean;
    italic: boolean;
    strike: boolean;
    inlineCode: boolean;
    list: EditorListType | null;
    quote: boolean;
}
/**
 * Reads the formatting that applies at the selection without changing the
 * document. Line-level state comes from the line holding `selection.start`;
 * inline state comes from markers around or enclosing the selection (or
 * around the caret when the selection is collapsed).
 */
export declare function readFormatState(value: string, rawSelection: EditorSelection): EditorFormatState;
