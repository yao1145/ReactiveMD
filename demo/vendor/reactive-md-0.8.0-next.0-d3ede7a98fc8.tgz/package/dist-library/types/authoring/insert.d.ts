import type { EditorEdit, EditorLocale, EditorSelection } from './command-types.js';
import type { LocalCompileOptions } from '../local/types.js';
import type { LocalConfig } from '../sdk/types.js';
import { type LocalComponentCatalogEntry } from './catalog.js';
/** Insert one already-resolved catalog entry. */
export declare function insertCatalogEntryFromOptions(entry: LocalComponentCatalogEntry, options: LocalCompileOptions | undefined, source: string, selection: EditorSelection): EditorEdit;
/**
 * Insert one component id from the compile-option catalog.
 *
 * The public catalog validates external templates before offering them, so a
 * snippet taken from it inserts a document that compiles. Conformance uses
 * `insertCatalogEntryFromOptions` with an unchecked catalog instead.
 */
export declare function insertLocalComponentFromOptions(options: LocalCompileOptions | undefined, componentId: string, source: string, selection: EditorSelection, locale?: EditorLocale): EditorEdit;
/** Compatibility wrapper for hosts that already hold a validated config. */
export declare function insertLocalComponent(config: LocalConfig, componentId: string, source: string, selection: EditorSelection, locale?: EditorLocale): EditorEdit;
