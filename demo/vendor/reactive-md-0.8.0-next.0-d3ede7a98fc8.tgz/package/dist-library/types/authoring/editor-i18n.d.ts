/**
 * Typed copy for the source editor: toolbar chrome and command placeholders.
 *
 * English strings are the canonical defaults. Chinese strings use the wording
 * shipped in the demo. Default component labels, descriptions, groups and
 * templates are authoring data owned by `src/presets/default-authoring.ts`.
 */
import type { EditorLocale } from './command-types.js';
export interface EditorCommandCopy {
    boldPlaceholder: string;
    italicPlaceholder: string;
    strikePlaceholder: string;
    inlineCodePlaceholder: string;
    linkText: string;
    imageAlt: string;
    codeBlockPlaceholder: string;
    tableHeaders: readonly [string, string, string];
    tableRows: readonly [
        readonly [string, string, string],
        readonly [string, string, string]
    ];
}
export interface EditorToolbarCopy {
    toolbarLabel: string;
    headingLabels: readonly [string, string, string, string, string, string, string];
    headingLevelLabel(heading: string): string;
    headingMenuLabel: string;
    bold: string;
    italic: string;
    listLabel: string;
    listLabelWithType(list: string): string;
    listMenuLabel: string;
    listLabels: {
        bullet: string;
        ordered: string;
        task: string;
    };
    decreaseIndent: string;
    increaseIndent: string;
    insertLink: string;
    insert: string;
    insertMenuLabel: string;
    insertItems: {
        image: string;
        table: string;
        divider: string;
        codeBlock: string;
        inlineCode: string;
        strikethrough: string;
        quote: string;
    };
    emoji: string;
    insertEmojiMenuLabel: string;
    insertEmojiLabel(emoji: string): string;
    componentsTriggerLabel: string;
    componentsLabel: string;
    componentsCompactLabel: string;
    nativeMenuLabel: string;
    nativeTitle: string;
    closeNativeLabel: string;
    searchPlaceholder: string;
    searchLabel: string;
    nativeListLabel: string;
    noMatchingComponents: string;
    inlineBadge: string;
    historyLabel: string;
    undo: string;
    redo: string;
    download: string;
    more: string;
    moreMenuLabel: string;
    linkMenuItem: string;
}
export interface EditorChromeCopy {
    /** Accessible name for the textarea when the host passes no ariaLabel. */
    sourceLabel: string;
    region: string;
    previewRegion: string;
    viewLabel: string;
    count(value: string): string;
    keyboardHint: string;
    edit: string;
    split: string;
    preview: string;
}
export declare const EDITOR_CHROME_COPY: Record<EditorLocale, EditorChromeCopy>;
export declare const EDITOR_COMMAND_COPY: Record<EditorLocale, EditorCommandCopy>;
export declare const EDITOR_TOOLBAR_COPY: Record<EditorLocale, EditorToolbarCopy>;
