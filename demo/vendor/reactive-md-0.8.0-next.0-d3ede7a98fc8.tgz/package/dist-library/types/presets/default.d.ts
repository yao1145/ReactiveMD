import type { LocalComponentDefinition } from '../sdk/types.js';
/**
 * The default component preset. Its components are ordinary public SDK
 * manifests, validated by `defineLocalComponent` at construction. Language
 * declarations (`theme`, `computed`, `const`, `external`) remain kernel grammar
 * metadata and are not preset components.
 */
export interface LocalDefaultPreset {
    readonly id: string;
    readonly version: string;
    readonly components: readonly LocalComponentDefinition[];
}
export declare const defaultPreset: LocalDefaultPreset;
export default defaultPreset;
