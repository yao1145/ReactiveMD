import { LOCAL_THEME_PROTOCOL, type LocalThemeDefinition } from '../local/theme.js';
/**
 * Preview theme-package contract.
 *
 * A theme package is plain, serializable data: identity plus a bounded list of
 * inline CSS resources. CSS is scoped to the document root that selects the
 * theme (`[data-rmd-theme="name"]`) so one document instance can never restyle
 * its host page or another instance. Phase one supports inline CSS only, with
 * `data:` URLs and no network resources.
 *
 * `defineLocalTheme` validates and freezes a package. `composeLocalTheme`
 * derives a new theme from a base package plus ordered overrides; every base
 * selector is retargeted to the composed theme name. `collectLocalThemeCss`
 * returns the concatenated stylesheet in resource order, ready for a `<style>`
 * element or an export asset list.
 */
export interface LocalStyleResource {
    readonly id: string;
    readonly css: string;
}
export interface LocalThemePackage extends LocalThemeDefinition {
    /** Stable package identity, independent from the document theme name. */
    readonly id: string;
    /** Package implementation version, for requirement checks. */
    readonly version: string;
    /** Inline CSS resources in stylesheet order. */
    readonly css: readonly LocalStyleResource[];
}
export interface LocalThemeInput {
    readonly id: string;
    readonly name: string;
    readonly version: string;
    /** Defaults to `reactive-md-theme-1`; any other value is rejected. */
    readonly protocol?: typeof LOCAL_THEME_PROTOCOL;
    /** Defaults to both light and dark; both are required. */
    readonly colorSchemes?: readonly ('light' | 'dark')[];
    readonly css: readonly LocalStyleResource[];
}
export interface LocalThemeCompositionInput {
    readonly id: string;
    readonly name: string;
    readonly version: string;
    readonly base: LocalThemePackage;
    /** Ordered resources appended after the base theme. */
    readonly overrides: readonly LocalStyleResource[];
}
/** Network-free literal CSS for component resources as well as theme packages. */
export declare function isLocalInlineCss(value: unknown): value is string;
/**
 * Validate, scope and freeze a theme package. The input is cloned; the result
 * and every nested resource are frozen.
 */
export declare function defineLocalTheme(input: LocalThemeInput): LocalThemePackage;
/**
 * Compose a base theme with ordered overrides under a new theme name.
 *
 * Base selectors are retargeted from the base theme root to the composed
 * theme root, so the result is a self-contained package that documents can
 * select with `<theme name="...">`. Overrides follow the base resources in
 * order and may not repeat an existing resource id.
 */
export declare function composeLocalTheme(input: LocalThemeCompositionInput): LocalThemePackage;
/**
 * Concatenate the package stylesheet in resource order. The returned text has
 * already been scoped at define/compose time.
 */
export declare function collectLocalThemeCss(theme: LocalThemePackage): string;
