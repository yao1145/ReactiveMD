import { type LocalConfig, type LocalConfigInput } from './types.js';
import type { Diagnostic, LocalDocument } from '../local/types.js';
/** Identifiers the default preset contributes in phase one. */
export declare const DEFAULT_PRESET_ID: string;
export declare const DEFAULT_PRESET_VERSION: string;
/** Bounded theme/resource registration budgets for one configuration. */
export declare const MAX_LOCAL_SDK_THEMES = 16;
/** Aggregate serialized-size budget for one configuration, including theme CSS. */
export declare const MAX_LOCAL_SDK_CONFIG_BYTES: number;
/** Create an immutable, validated instance configuration. */
export declare function createLocalConfig(input?: LocalConfigInput): LocalConfig;
/** Fingerprint of the manifests that the compiler actually used. */
export declare function localComponentConfigKey(config?: LocalConfig): string;
/** Older compiled documents have no fingerprint and retain contract-based checks. */
export declare function validateLocalDocumentConfig(document: LocalDocument, config?: LocalConfig): Diagnostic[];
/**
 * Revalidate arbitrary configuration data, including a Worker snapshot or a
 * hand-built payload. The supplied `key` is ignored and recomputed from the
 * validated contents.
 */
export declare function readLocalConfig(value: unknown): LocalConfig;
/** Cache/transport key that never throws; invalid payloads stay distinct. */
export declare function localConfigKey(value: unknown): string;
/**
 * Worker-side copy. A valid configuration is revalidated into fresh frozen
 * data; an invalid one is passed through so the compiler can report it.
 */
export declare function snapshotLocalConfig(value: unknown): unknown;
