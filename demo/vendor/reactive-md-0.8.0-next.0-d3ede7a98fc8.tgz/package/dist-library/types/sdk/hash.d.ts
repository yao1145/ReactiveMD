/**
 * Deterministic, non-cryptographic digest for SDK semantic identity.
 *
 * The digest is stable across processes and platforms (unlike object identity
 * or `Math.random`), and is used only to detect contract changes. It is not a
 * security primitive: document payloads must still be validated by the
 * receiving side.
 */
export declare function localHash(text: string): string;
