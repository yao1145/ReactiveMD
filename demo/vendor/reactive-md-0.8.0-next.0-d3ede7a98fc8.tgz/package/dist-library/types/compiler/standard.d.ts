/**
 * Standard single-pass compiler entry.
 *
 * Same result contract as the minimal factory, but wired to the full
 * experience: the default component preset is supplied explicitly and the
 * KaTeX display precheck stays on. It is the single-pass counterpart of the
 * legacy `compileLocal` without sessions, workers, React or theme loading.
 */
import type { LocalCompileOptions } from '../local/types.js';
import { type Compiler } from './types.js';
export { CompilerConfigurationError } from './types.js';
export type { CheckCoverage, CompileFailure, CompileResult, CompileSuccess, Compiler, CompilerConfigurationErrorOptions, OptionalCheck, Program, } from './types.js';
export type { DeepReadonly } from './types.js';
export type { LocalCompileOptions, LocalCompileResult, LocalRecovery } from '../local/types.js';
export declare function createStandardCompiler(options?: LocalCompileOptions): Compiler;
