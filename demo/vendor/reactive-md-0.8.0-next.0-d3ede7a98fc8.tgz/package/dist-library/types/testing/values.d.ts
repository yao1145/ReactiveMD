import { type LocalComplianceValue } from './types.js';
export declare function isPlainRecord(value: unknown): value is Record<string, unknown>;
export declare function requireRecord(value: unknown, path: string): Record<string, unknown>;
export declare function checkKeys(record: Record<string, unknown>, allowed: ReadonlySet<string>, path: string): void;
export declare function readString(value: unknown, path: string, limit?: number): string;
export declare function readBoolean(value: unknown, path: string): boolean;
export declare function readFiniteNumber(value: unknown, path: string): number;
export declare function readInteger(value: unknown, path: string, min?: number, max?: number): number;
/** Validate one public compliance value and return a defensive copy. */
export declare function readComplianceValue(value: unknown, path: string): LocalComplianceValue;
export declare function readComplianceValueRecord(value: unknown, path: string, maxEntries: number): Readonly<Record<string, LocalComplianceValue>>;
export declare function readStringList(value: unknown, path: string, maxEntries: number): readonly string[];
export declare function sameComplianceValue(left: unknown, right: unknown): boolean;
export declare function sameComplianceRecord(left: Readonly<Record<string, LocalComplianceValue>>, right: Readonly<Record<string, LocalComplianceValue>>): boolean;
/** Keep spec parity keys stable and reject duplicate case ids. */
export declare function readCaseId(value: unknown, path: string, seen: Set<string>, fallback: string): string;
/** Bounded diagnostic view of compiler/runtime output. */
export declare function readDiagnostics(value: unknown): readonly {
    code: string;
    message: string;
}[];
export declare function readErrorMessage(error: unknown): string;
