import type { LocalConfig } from '../sdk/types.js';
import { LOCAL_BROWSER_SPEC_PROTOCOL, type LocalComplianceSuiteResult, type LocalComplianceValue } from './types.js';
/**
 * Portable browser driver contract.
 *
 * A driver may adapt Playwright, WebDriver, a remote grid or an in-process DOM.
 * The compliance runner only sees these bounded operations; it never imports a
 * browser framework.
 */
export interface LocalBrowserPageDriver {
    goto(url: string): Promise<void>;
    reload(): Promise<void>;
    waitFor(selector: string, timeoutMs: number): Promise<void>;
    count(selector: string): Promise<number>;
    text(selector: string): Promise<string | null>;
    attribute(selector: string, name: string): Promise<string | null>;
    visible(selector: string): Promise<boolean>;
    enabled(selector: string): Promise<boolean>;
    click(selector: string): Promise<void>;
    fill(selector: string, value: string): Promise<void>;
    press(selector: string, key: string): Promise<void>;
    evaluate<T = unknown>(expression: string): Promise<T>;
}
export interface LocalBrowserSessionDriver {
    readonly page: LocalBrowserPageDriver;
    readonly errors: readonly string[];
    readonly requests: readonly string[];
    readonly offline: boolean;
    close(): Promise<void>;
}
export interface LocalBrowserOpenOptions {
    readonly url: string;
    readonly offline: boolean;
    readonly javaScriptEnabled?: boolean;
    readonly timeoutMs: number;
}
export interface LocalBrowserDriver {
    readonly name: string;
    open(options: LocalBrowserOpenOptions): Promise<LocalBrowserSessionDriver>;
}
export type LocalBrowserPhase = 'mount' | 'hydration' | 'edit' | 'hide-show' | 'disabled' | 'reset' | 'descendant-error' | 'unmount';
export type LocalBrowserCaseKind = 'visible' | 'text' | 'attribute' | 'count' | 'enabled' | 'wait' | 'click' | 'fill' | 'press' | 'evaluate' | 'isolation' | 'unmount';
export interface LocalBrowserCase {
    readonly id: string;
    readonly phase: LocalBrowserPhase;
    readonly kind: LocalBrowserCaseKind;
    readonly selector?: string;
    readonly name?: string;
    readonly value?: string;
    readonly key?: string;
    readonly expression?: string;
    readonly expected?: LocalComplianceValue;
    readonly trigger?: string;
    readonly placeholder?: string;
    readonly survivor?: string;
}
export interface LocalBrowserSpec {
    readonly protocol: typeof LOCAL_BROWSER_SPEC_PROTOCOL;
    /** A local file: or data: URL. Offline compliance must never use the network. */
    readonly url: string;
    readonly offline: boolean;
    readonly javaScriptEnabled?: boolean;
    readonly timeoutMs?: number;
    readonly cases: readonly LocalBrowserCase[];
    /** Error substrings a descendant-error phase may legitimately emit. */
    readonly expectedErrors?: readonly string[];
    /** Defaults to a built-in unmount hook, then removing the document root. */
    readonly unmountExpression?: string;
    /** Phases the report must prove; defaults to the full lifecycle. */
    readonly requiredPhases?: readonly LocalBrowserPhase[];
}
export interface LocalBrowserComplianceOptions {
    readonly driver: LocalBrowserDriver;
    readonly spec: LocalBrowserSpec | unknown;
    /** Optional: used for the report's config key and component identity. */
    readonly config?: LocalConfig | unknown;
    readonly component?: string;
}
/** Validate a browser spec before opening a browser. */
export declare function readLocalBrowserSpec(value: unknown): LocalBrowserSpec;
/**
 * Execute a portable browser compliance scenario.
 *
 * Required lifecycle phases are proven from passed cases, not declarations.
 * Offline evidence additionally requires an offline context, a hydration pass,
 * no unexpected page errors and zero http(s)/ws requests.
 */
export declare function runLocalBrowserCompliance(options: LocalBrowserComplianceOptions): Promise<LocalComplianceSuiteResult>;
export interface LocalPlaywrightLocatorLike {
    count(): Promise<number>;
    first(): LocalPlaywrightLocatorLike;
    textContent(): Promise<string | null>;
    getAttribute(name: string): Promise<string | null>;
    isVisible(): Promise<boolean>;
    isEnabled(): Promise<boolean>;
    click(): Promise<void>;
    fill(value: string): Promise<void>;
    press(key: string): Promise<void>;
}
export interface LocalPlaywrightPageLike {
    goto(url: string, options?: {
        waitUntil?: 'load' | 'domcontentloaded';
        timeout?: number;
    }): Promise<unknown>;
    reload(options?: {
        timeout?: number;
    }): Promise<unknown>;
    waitForSelector(selector: string, options?: {
        state?: 'attached' | 'visible';
        timeout?: number;
    }): Promise<unknown>;
    locator(selector: string): LocalPlaywrightLocatorLike;
    evaluate<T = unknown>(expression: string): Promise<T>;
    on(event: string, listener: (...args: any[]) => void): unknown;
    close(): Promise<void>;
}
export interface LocalPlaywrightContextLike {
    newPage(): Promise<LocalPlaywrightPageLike>;
    setOffline?(offline: boolean): Promise<void>;
}
/**
 * Optional Playwright adapter. It takes an already-created browser context and
 * never imports Playwright, so `reactive-md/testing/browser` has no hard
 * dependency. Create the context with `offline: true` for offline compliance.
 */
export declare function createPlaywrightBrowserDriver(context: LocalPlaywrightContextLike): LocalBrowserDriver;
