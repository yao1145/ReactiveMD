import type { LocalConfig } from '../sdk/types.js';
import { type LocalBehaviorSpec, type LocalComplianceSuiteResult } from './types.js';
/** Validate a behavior spec before any document is compiled. */
export declare function readLocalBehaviorSpec(value: unknown): LocalBehaviorSpec;
/**
 * Execute a component's public binding behavior.
 *
 * The suite compiles the supplied source with the same immutable config used
 * by rendering, then performs real runtime writes. Accepted writes must change
 * values and advance the revision; rejected writes must roll back with an
 * unchanged revision. Reset restores authored initials and advances the reset
 * token. Collections additionally prove defensive copies.
 */
export declare function runLocalBehaviorCompliance(input: LocalBehaviorSpec | unknown, configInput: LocalConfig | unknown): LocalComplianceSuiteResult;
export declare const BEHAVIOR_LIMITS: Readonly<{
    maxWrites: 64;
    maxSlots: 16;
    maxStringLength: 4096;
}>;
