import { type LocalComplianceSuiteResult } from './types.js';
/**
 * Execute manifest-level compliance for one component definition.
 *
 * Every case calls the public manifest/prop readers. A definition either
 * normalizes to an identical semantic digest, applies its declared defaults,
 * rejects illegal input and rejects corrupted identity/default data, or the
 * case fails with the actual error text.
 */
export declare function runLocalManifestCompliance(input: unknown): LocalComplianceSuiteResult;
