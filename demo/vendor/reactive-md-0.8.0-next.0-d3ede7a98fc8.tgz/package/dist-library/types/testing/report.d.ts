import { type LocalComplianceCaseResult, type LocalComplianceParityResult, type LocalComplianceReport, type LocalComplianceReportInput, type LocalComplianceSuiteResult } from './types.js';
/**
 * Aggregate suite results into one report.
 *
 * A declared capability is satisfied only by a passed case that names it.
 * Missing suites therefore produce an explicit unsupported/skipped evidence
 * entry and, by default, make the report fail. Callers can pass an explicit
 * capability subset for an intentionally partial run.
 */
export declare function createLocalComplianceReport(input: LocalComplianceReportInput): LocalComplianceReport;
/**
 * Compare two suite results case by case. Case ids and observed values are
 * stable, so a built-in component and an external alias of the same contract
 * must produce the same statuses and observed parameter values.
 */
export declare function compareLocalComplianceParity(left: LocalComplianceSuiteResult, right: LocalComplianceSuiteResult): LocalComplianceParityResult;
/** Exposed for hosts that want one-line diagnostics without reading cases. */
export declare function describeLocalComplianceCase(item: LocalComplianceCaseResult): string;
/** Defensive helper used by adapters that catch asynchronous errors. */
export declare function localErrorCase(id: string, suite: LocalComplianceSuiteResult['suite'], error: unknown): LocalComplianceCaseResult;
