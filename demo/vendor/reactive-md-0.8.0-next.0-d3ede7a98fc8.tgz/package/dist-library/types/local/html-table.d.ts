import type { LocalNode } from './types.js';
/** Contextual names: they do not reserve new component names globally. */
export declare const HTML_TABLE_NAMES: ReadonlySet<string>;
export declare const HTML_TABLE_ATTRIBUTES: Readonly<Record<string, ReadonlySet<string>>>;
export declare function validHtmlTableValue(name: string, value: string): boolean;
export type HtmlTableProblem = 'structure' | 'mixed' | 'attribute' | 'value' | 'unclosed';
interface Hooks {
    shield(offset: number, end: number): number | null;
    budget(offset: number, tokens: number): void;
    node(type: string, start: number, end: number, extra: Partial<LocalNode>): LocalNode;
    attributes(tag: string, start: number, end: number): Record<string, string>;
    content(start: number, end: number): LocalNode[];
    problem(kind: HtmlTableProblem, start: number, end: number, tag?: string, name?: string): void;
}
/**
 * Parse only the table skeleton with the HTML parser. Cell/caption bodies are
 * opaque spaces of equal length, then parsed from the original source through
 * the normal ReactiveMD pipeline. This preserves offsets and avoids HTML's
 * foster-parenting of Markdown, custom controls or example tags in code.
 */
export declare function readHtmlTable(source: string, start: number, limit: number, hooks: Hooks): {
    node: LocalNode;
    end: number;
} | null;
export {};
