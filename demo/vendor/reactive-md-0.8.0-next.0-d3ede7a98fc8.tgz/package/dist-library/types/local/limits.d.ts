/**
 * Shared defensive limits for source compilation, runtime values and visual work.
 *
 * Units matter:
 * - Source text, names, string values/templates, diagnostic text and JSON-ish
 *   lengths are UTF-16 code units (JavaScript `string.length`). These are
 *   allocation/CPU guards, not author-visible character counts.
 * - Author-visible `len()` text and text-control `min-length`/`max-length` use
 *   Unicode code points via `countLocalCodePoints`.
 * - Arrays and plot sample counts are element counts.
 *
 * Each limit is inclusive: a value equal to the limit is accepted, a larger
 * value is rejected. Only the per-compilation parser budgets are configurable:
 * `limits.maxSyntaxNodes`, `limits.maxParseWork` and `limits.maxMarkdownDepth`.
 */
/** Original source length for one compilation, in UTF-16 code units. */
export declare const MAX_LOCAL_DOCUMENT_LENGTH = 1000000;
/** Cumulative `LocalNode` constructions during one parse, including intermediates. */
export declare const DEFAULT_MAX_LOCAL_SYNTAX_NODES = 10000;
/**
 * Deterministic Markdown parsing work per parse, in abstract work units.
 * A unit is roughly one source code unit scanned or committed to a parser.
 * This intentionally excludes wall-clock time so compilation results stay
 * reproducible; hosts may raise it for unusually dense documents.
 */
export declare const DEFAULT_MAX_LOCAL_PARSE_WORK = 20000000;
/**
 * Nested Markdown container depth (blockquotes plus open list levels).
 * Fenced and indented code content is not a container and is not counted.
 * The value is inclusive: a depth equal to the limit is accepted.
 */
export declare const DEFAULT_MAX_LOCAL_MARKDOWN_DEPTH = 1000;
/** One string value, attribute, template or concatenation result, in UTF-16 code units. */
export declare const MAX_LOCAL_STRING_LENGTH = 100000;
/** Number of elements in one array value or selection. */
export declare const MAX_LOCAL_ARRAY_LENGTH = 10000;
/** Sum of UTF-16 lengths of all string members in one array. */
export declare const MAX_LOCAL_VALUE_CHARACTERS = 100000;
/** Diagnostics retained per parse/compile; new errors may displace warnings. */
export declare const MAX_LOCAL_DIAGNOSTICS = 100;
/** Displayed diagnostic message length, in UTF-16 code units. */
export declare const MAX_LOCAL_DIAGNOSTIC_LENGTH = 2000;
/** Curves allowed in one `<plot>` component. */
export declare const MAX_LOCAL_PLOT_CURVES = 16;
/** Curve sample points requested across one document compilation. */
export declare const MAX_LOCAL_PLOT_POINTS = 20000;
/** Shared node-visit budget for all plot sampling in one runtime revision. */
export declare const MAX_LOCAL_PLOT_STEPS = 2000000;
/** Email address guard, in UTF-16 code units; validated in linear time. */
export declare const MAX_LOCAL_EMAIL_LENGTH = 254;
export declare const MAX_LOCAL_VALIDATIONS = 100;
export declare const MAX_LOCAL_DATA_TABLE_ROWS = 1000;
export declare const DEFAULT_LOCAL_DATA_TABLE_ROWS = 100;
export declare const MAX_LOCAL_DATA_TABLE_COLUMNS = 20;
export declare const MAX_LOCAL_DATA_DOCUMENT_ROWS = 2000;
export declare const MAX_LOCAL_DATA_DOCUMENT_CELLS = 10000;
/** Host component schemas accepted in one compilation. */
export declare const MAX_LOCAL_HOST_COMPONENTS = 32;
/** Host component and property name length, in UTF-16 code units. */
export declare const MAX_LOCAL_HOST_NAME_LENGTH = 128;
/** Host property RegExp source length, in UTF-16 code units. */
export declare const MAX_LOCAL_HOST_PATTERN_LENGTH = 512;
/** Allowed literals in one host enum property. */
export declare const MAX_LOCAL_HOST_ENUM_VALUES = 64;
/** Linear validation; the final dot must have text on both sides in the domain. */
export declare function isLocalEmail(value: string): boolean;
