import type { LocalNode } from './types.js';
/** Offset-only Markdown nodes consumed by the existing semantic transform. */
interface FastNode {
    type: string;
    position: {
        start: {
            offset: number;
        };
        end: {
            offset: number;
        };
    };
    children?: FastNode[];
    value?: string;
    ordered?: boolean;
    start?: number | null;
    checked?: null;
    align?: ('left' | 'right' | 'center' | null)[];
}
/**
 * A fully validated scan of the simple Markdown subset. `nodeCount` and the
 * overflow ranges are exact, not estimates: `emit` creates the final
 * `LocalNode`s in the same children-first order as the remark transform, so a
 * caller can enforce its cumulative budget without an intermediate tree.
 */
export interface FastMarkdownPlan {
    /** Advisory shielding scan; never materialize this plan as document nodes. */
    readonly shieldOnly?: boolean;
    /** Exact number of `LocalNode` constructions, excluding the root. */
    readonly nodeCount: number;
    /** Number of top-level nodes. */
    readonly blockCount: number;
    /** Exact scanned text this plan was validated against. */
    readonly source: string;
    /**
     * Inline plans discovered while validating this block, keyed by exact inline
     * text. A caller that recompiles a structurally similar block can hand this
     * map back as an `InlinePlanLookup` so unchanged rows/items never have to be
     * rescanned. Values may be `undefined` (a cached rejection).
     */
    readonly rows: ReadonlyMap<string, InlinePlan | undefined>;
    /**
     * Range of the `(remaining + 1)`-th node in transform order, or `undefined`
     * when the plan does not construct that many nodes. Never creates nodes.
     */
    overflowAt(remaining: number): {
        start: number;
        end: number;
    } | undefined;
    /**
     * Build the final nodes children-first. Validation already succeeded when a
     * plan exists, so `create` is never called for an ambiguous document.
     */
    emit(create: (type: string, start: number, end: number, extra?: Partial<LocalNode>) => LocalNode): LocalNode[];
}
/** One validated inline token; offsets are relative to the scanned text. */
export interface InlineTextToken {
    readonly type: 'text';
    readonly from: number;
    readonly to: number;
    readonly value: string;
}
export interface InlineStrongToken {
    readonly type: 'strong';
    readonly from: number;
    readonly to: number;
    /** Inner text value; the inner range is `[from + 2, to - 2)`. */
    readonly value: string;
}
export interface InlineOpaqueToken {
    readonly type: 'opaque';
    readonly from: number;
    readonly to: number;
    readonly value: string;
}
export type InlineToken = InlineTextToken | InlineStrongToken | InlineOpaqueToken;
/** Only parser-created interpolation placeholders may bypass Markdown syntax. */
export interface FastMarkdownContext {
    /** Parser-owned same-line interpolation masking for the advisory first pass. */
    readonly shield?: (text: string, offset: number) => string | undefined;
    readonly allowBraces?: boolean;
    readonly offset?: number;
    readonly placeholders?: ReadonlyMap<number, {
        readonly end: number;
        readonly marker: string;
    }>;
}
/** Read-only inline plan. `undefined` means the text is outside the subset. */
export type InlinePlan = readonly InlineToken[];
/**
 * Row-level inline plans carried by a previous compile. Used in preference to
 * the bounded global LRU so a sequence of edits over a large list/table never
 * has to re-scan unchanged rows (and cannot thrash the LRU).
 */
export type InlinePlanLookup = ReadonlyMap<string, InlinePlan | undefined>;
/** Distinguishes a cached rejection from a cache miss. */
export type CacheLookup<T> = {
    readonly hit: true;
    readonly value: T | undefined;
} | {
    readonly hit: false;
};
/**
 * Optional session cache used by the parser. Only read-only scan results are
 * stored; implementations must bound their entry count.
 */
export interface FastMarkdownCache {
    readPlan(text: string): CacheLookup<FastMarkdownPlan>;
    writePlan(text: string, value: FastMarkdownPlan | undefined): void;
    readInline(text: string): CacheLookup<InlinePlan>;
    writeInline(text: string, value: InlinePlan | undefined): void;
    /** Called when an inline plan was served from this cache. */
    noteInlineReuse?(kind: 'row' | 'item'): void;
    /** Called when a non-rejected fast plan was served from this cache. */
    notePlanReuse?(): void;
}
/**
 * Legacy offset-only scanner. Its entry restriction is unchanged: inputs
 * without a pipe or a list marker stay with remark. New production callers
 * should use `planFastMarkdown`, which also accepts single-line prose.
 */
export declare function parseFastMarkdown(source: string): FastNode | undefined;
/**
 * Validate the whole input before exposing a plan. The counting pass uses
 * placeholder values, so no `LocalNode` and no identifier/budget state exists
 * until `emit` runs. Prose-only inputs are accepted here; the legacy entry
 * restriction above applies only to `parseFastMarkdown`.
 *
 * When a session cache is supplied, identical block text reuses the complete
 * plan (and, on a plan miss, identical rows/items reuse their inline plans).
 * `rowPlans` is an additional, caller-owned hint from the previous revision;
 * it is consulted before the bounded cache so large row blocks cannot thrash
 * it. Inline plans are pure functions of their text, so this never changes
 * validation, emission order or node counts.
 */
export declare function planFastMarkdown(source: string, cache?: FastMarkdownCache, rowPlans?: InlinePlanLookup, context?: FastMarkdownContext): FastMarkdownPlan | undefined;
export {};
