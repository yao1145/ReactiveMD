import { type RefObject } from 'react';
/**
 * A Markdown image that opens its original source in a native modal dialog.
 *
 * The trigger is the original `<img>` element, so the rendered markup, URL
 * handling and loading hints stay identical to the plain image. The preview is
 * portalled into the document root only after a user opens it: the root carries
 * the theme tokens and an inline `<dialog>` inside a paragraph would break
 * server rendering and hydration.
 *
 * `static` mode always returns the plain image. In `interactive` mode the image
 * is a button only when it is not already wrapped in a Markdown link; a
 * link-wrapped image keeps the anchor's navigation and has no extra tab stop.
 */
export declare function ZoomableImage({ src, alt, title, mode, rootRef, imageProps, }: {
    src: string;
    alt: string;
    title?: string;
    mode: 'interactive' | 'static';
    rootRef: RefObject<HTMLElement | null>;
    /** Validated source attributes for P0 HTML images; zoom behaviour is shared. */
    imageProps?: Record<string, string | number | undefined>;
}): import("react").JSX.Element;
