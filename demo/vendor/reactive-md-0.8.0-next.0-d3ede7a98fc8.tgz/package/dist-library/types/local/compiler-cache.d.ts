import { type LocalExpression } from './expression.js';
import { type LatexExpression } from './math.js';
import type { LocalValueKind, LocalMathDisplayIssue } from './types.js';
export interface SemanticCacheStats {
    expressionsCompiled: number;
    expressionsReused: number;
    typesInferred: number;
    typesReused: number;
    attributesValidated: number;
    attributesReused: number;
    bindingsResolved: number;
    bindingsReused: number;
    formulasCompiled: number;
    formulasReused: number;
    displaysInspected: number;
    displaysReused: number;
    entries: number;
}
/** Session-owned successful semantic products; no source-position diagnostics. */
export declare class LocalSemanticCache {
    private readonly capacity;
    private readonly maxWeight;
    private key;
    private values;
    private weight;
    private counts;
    constructor(capacity?: number, maxWeight?: number);
    begin(key: string): void;
    get stats(): SemanticCacheStats;
    clear(): void;
    private get;
    private put;
    expression(source: string): LocalExpression;
    infer(expression: LocalExpression, environment: Record<string, LocalValueKind>): LocalValueKind;
    attributes<T>(key: string): {
        value: T;
        origin: number;
    } | undefined;
    rememberAttributes(key: string, origin: number, value: unknown): void;
    binding<T>(key: string): T | undefined;
    rememberBinding(key: string, value: unknown): void;
    latex(source: string): LatexExpression;
    display(source: string, block: boolean): LocalMathDisplayIssue[];
}
