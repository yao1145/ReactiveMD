import type { LocalNode } from './types.js';
/**
 * Split a `<details>` child list into its summary and body. A direct summary
 * wins, matching the parser's historical behavior; only when none exists is a
 * summary-bearing paragraph inspected. Later summaries stay in the body, and
 * nested details are left untouched.
 */
export declare function splitHtmlDetailsChildren(nodes: readonly LocalNode[]): {
    summary?: LocalNode;
    body: LocalNode[];
};
/**
 * Parser-level normalization: store the summary first and the body afterwards.
 * Idempotent, and safe to call on an already normalized list.
 */
export declare function normalizeHtmlDetailsChildren(nodes: readonly LocalNode[]): LocalNode[];
