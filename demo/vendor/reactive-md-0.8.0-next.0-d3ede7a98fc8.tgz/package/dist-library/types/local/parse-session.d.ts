import { type ParsedLocal } from './parser.js';
import type { LocalCompileOptions } from './types.js';
import type { SourceContext } from './source-context.js';
import type { CacheLookup, FastMarkdownPlan, InlinePlan, InlinePlanLookup } from './fast-markdown.js';
import type { ParseSessionCache, ParseSessionCounters } from './parse-budget.js';
/**
 * Session-scoped reuse for the Markdown parser.
 *
 * The session stores only read-only intermediate data: validated fast-block
 * plans, inline plans for table rows/list items, and general Markdown ASTs.
 * Every `parse()` still rebuilds the final `LocalNode` tree through the
 * parser's own factory, so ids, source ranges and the exact cumulative node
 * budget match an independent full compilation.
 *
 * Caches are bounded and keyed by exact source text. Changing compile options,
 * permissions or budgets clears them. Independent `parseLocal`/`compileLocal`
 * calls never see this state.
 */
export declare class LocalParseSession implements ParseSessionCache {
    private disposed;
    private optionKey;
    private recoveryMode;
    private readonly plans;
    private readonly inline;
    private readonly trees;
    private counts;
    parse(source: string, options?: LocalCompileOptions, context?: SourceContext, rowPlans?: InlinePlanLookup): ParsedLocal;
    clear(): void;
    dispose(): void;
    get stats(): Readonly<{
        hits: number;
        misses: number;
        reusedBlocks: number;
        reusedRows: number;
        reusedItems: number;
        reusedRowNodes: number;
        reusedItemNodes: number;
        entries: number;
    }>;
    private reset;
    counters(): ParseSessionCounters;
    readPlan(text: string): CacheLookup<FastMarkdownPlan>;
    writePlan(text: string, value: FastMarkdownPlan | undefined): void;
    readInline(text: string): CacheLookup<InlinePlan>;
    writeInline(text: string, value: InlinePlan | undefined): void;
    notePlanReuse(): void;
    noteInlineReuse(kind: 'row' | 'item'): void;
    /**
     * The incremental compiler substitutes an unchanged flat row/item subtree
     * from the previous revision. That is node-level reuse rather than an
     * inline-plan hit, so it is counted separately from plan reuse.
     */
    noteRowReuse(kind: 'row' | 'item'): void;
    readTree(text: string): {
        readonly hit: true;
        readonly value: unknown;
    } | {
        readonly hit: false;
    };
    writeTree(text: string, value: unknown): void;
    private lookup;
}
