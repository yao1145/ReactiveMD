import { type ReactNode } from 'react';
import type { LocalLocale } from './locale.js';
export type { LocalLocale } from './locale.js';
/**
 * A localizer pair supplied at the call site. The English half is returned for
 * `en`, so the default renderer output stays byte-identical to the original
 * English strings.
 */
export type Localize = (en: string, zh: string) => string;
/** The English-only localizer used by helpers outside a React render. */
export declare const defaultLocalize: Localize;
export declare function LocalLocaleProvider({ locale, children, }: {
    locale?: LocalLocale;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useLocalLocale(): LocalLocale;
export declare function localize(locale: LocalLocale, en: string, zh: string): string;
export declare function useLocalize(): Localize;
