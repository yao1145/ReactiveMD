import type { LocalCompileOptions } from './types.js';
/** Copy only validated, serializable compile semantics into a portable payload. */
export declare function portableCompileOptions(input?: LocalCompileOptions): LocalCompileOptions | undefined;
