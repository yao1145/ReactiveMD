import type { LocalValue, SourceRange } from './types.js';
/**
 * Computable LaTeX for local plots.
 *
 * The parser builds an explicit AST; evaluation never uses eval/Function and
 * only reads the independent variable x plus numeric bindings from the
 * document. Unsupported structures (integrals, matrices, macros, ...) are
 * rejected at compile time with an offset into the LaTeX source.
 */
export declare class LatexError extends Error {
    readonly code: string;
    readonly offset: number;
    constructor(code: string, message: string, offset?: number);
}
export interface LatexExpression {
    readonly source: string;
    dependencies: string[];
    evaluate(x: number, env: Record<string, LocalValue>, budget?: LatexEvaluationBudget): number;
}
/** Shared step budget used by samplePlot so the whole curve has one bound. */
export interface LatexEvaluationBudget {
    steps: number;
    limit: number;
}
export interface PlotPoint {
    x: number;
    y: number | null;
}
export interface PlotSample {
    points: PlotPoint[];
    endpoint: number | null;
}
/** Internal authoring support: only AST variable nodes represent plot reads. */
export declare function localLatexReferences(source: string): {
    name: string;
    range: SourceRange;
}[];
export declare function compileLatex(source: string): LatexExpression;
/**
 * Samples y(x) across [min, max]. Undefined points and the sample after a
 * detected break become null so a renderer cannot join the two sides of an
 * asymptote. The array always has exactly `samples` points.
 *
 * The optional final budget is shared by every curve/plot in a document. Each
 * evaluation is limited by whatever remains of both that shared budget and the
 * per-curve budget, and a `latex-budget` error aborts the whole sampling pass.
 */
export declare function samplePlot(expression: LatexExpression, env: Record<string, LocalValue>, min: number, max: number, samples?: number, sharedBudget?: LatexEvaluationBudget): PlotSample;
