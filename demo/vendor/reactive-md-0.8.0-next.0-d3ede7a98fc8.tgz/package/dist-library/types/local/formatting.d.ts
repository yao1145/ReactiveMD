/**
 * Deterministic number formatting for the local expression language.
 *
 * Every formatter receives an explicit supported locale and explicit
 * `Intl.NumberFormat` options. It never falls back to the host default locale,
 * and half-way values round away from zero (`halfExpand`). Helpers raise
 * `LocalFunctionError` without a source offset; the evaluator converts these
 * to `LocalExpressionError` at the call site.
 */
export declare class LocalFunctionError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare const SUPPORTED_LOCALES: readonly string[];
/** Enforce the shared string budget for a formatting or data result. */
export declare function ensureStringBudget(value: string, label: string): string;
/** Restrict locales to the explicitly supported set; no host fallback. */
export declare function requireLocale(locale: string): string;
/**
 * Fixed-point decimal text with optional digit grouping.
 * `value === null` renders an empty string after the options are validated.
 */
export declare function formatNumber(value: number | null, digits?: number, locale?: string, grouping?: boolean): string;
/**
 * Percent text for a ratio: `0.125` with zero digits renders `13%`.
 * `value === null` renders an empty string after the options are validated.
 */
export declare function formatPercent(value: number | null, digits?: number, locale?: string): string;
/**
 * Scientific-notation text with a fixed number of fraction digits.
 * `value === null` renders an empty string after the options are validated.
 */
export declare function formatScientific(value: number | null, digits?: number, locale?: string): string;
/**
 * Currency text. `currency` must be an uppercase three-letter code. Codes that
 * Intl accepts are allowed even when they are not assigned to a real currency;
 * Intl then displays the code itself. The explicit `digits` override applies to
 * every currency, including currencies such as JPY whose default is zero.
 * `value === null` renders an empty string after the options are validated.
 */
export declare function formatCurrency(value: number | null, currency?: string, digits?: number, locale?: string): string;
