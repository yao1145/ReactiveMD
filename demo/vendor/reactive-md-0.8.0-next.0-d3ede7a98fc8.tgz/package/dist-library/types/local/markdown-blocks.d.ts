import { type FastMarkdownCache, type InlinePlanLookup, type FastMarkdownContext } from './fast-markdown.js';
import type { SourceContext } from './source-context.js';
/** Per-parse accounting used by the compiler's performance diagnostics. */
export interface MarkdownBlockStats {
    fastBlocks: number;
    generalBlocks: number;
    fastCharacters: number;
    generalCharacters: number;
    lines: number;
}
export interface Candidate {
    from: number;
    to: number;
    type: string;
}
export interface MarkdownStructure {
    candidates: Candidate[];
    maxDepth: number;
    codeRanges: {
        start: number;
        end: number;
    }[];
}
/**
 * Split a Markdown document into independently parseable simple blocks.
 *
 * A whole-document fast plan is used when possible. Otherwise Lezer only
 * proposes top-level boundaries; every proposal is re-validated with the fast
 * planner, which rejects syntax whose meaning depends on surrounding context.
 * Safe ranges are blanked with equal-length spaces (line endings preserved) and
 * parsed once by the general parser, so reference and footnote resolution still
 * sees the whole document. Any overlap between a general node and a blanked
 * range means the boundaries were not trustworthy and the whole source is
 * re-parsed normally.
 */
export declare function parseMarkdownBlocks(source: string, parseGeneral: (source: string) => any, context?: SourceContext, cache?: FastMarkdownCache, structure?: MarkdownStructure, rowPlans?: InlinePlanLookup, fastContext?: FastMarkdownContext): {
    tree: any;
    stats: MarkdownBlockStats;
};
/** Lezer is advisory only: its top-level nodes seed candidate ranges. */
export declare function scanMarkdownStructure(source: string): MarkdownStructure;
export interface MarkdownTreeFacts {
    codeRanges: {
        start: number;
        end: number;
    }[];
    definitions: {
        start: number;
        end: number;
    }[];
    mathLiterals: {
        start: number;
        end: number;
    }[];
}
/** One iterative semantic-fact traversal shared by shielding and containers. */
export declare function markdownTreeFacts(tree: any, enterFootnotes?: boolean): MarkdownTreeFacts;
