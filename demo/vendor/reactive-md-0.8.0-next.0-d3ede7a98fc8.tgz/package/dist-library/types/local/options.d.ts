import { LOCAL_HTML_FLAGS, LOCAL_RECOVERY_STRATEGY_VERSION } from './options-core.js';
import type { LocalOptionCheck } from './options-core.js';
import type { LocalCompileOptions } from './types.js';
export { LOCAL_HTML_FLAGS, LOCAL_RECOVERY_STRATEGY_VERSION };
export type { LocalHtmlFlag, LocalOptionCheck } from './options-core.js';
/**
 * Compatibility entry: validates the full instance configuration, including
 * themes, and always honors the default preset. The rules themselves live in
 * `options-core.ts`; this module only supplies the standard assembly.
 */
export declare function readLocalCompileOptions(options: LocalCompileOptions | undefined): LocalOptionCheck;
/**
 * Stable signature of the option values that affect compilation. Used to
 * recompile on flag/limit changes and to keep worker races keyed by more than
 * the source text. Unknown keys are deliberately ignored.
 */
export declare function localCompileOptionsKey(options?: LocalCompileOptions): string;
