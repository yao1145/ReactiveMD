import type { LocalDocument, LocalNode } from './types.js';
/** One rendered reference occurrence and the endnote it points at. */
export interface LocalFootnoteReferenceSite {
    node: LocalNode;
    /** Unique, instance-scoped DOM id for this occurrence. */
    id: string;
}
/** One referenced definition, numbered by first reference order. */
export interface LocalFootnoteEntry {
    identifier: string;
    /** 1-based number shared by every reference to this identifier. */
    number: number;
    definition: LocalNode;
    /** Instance-scoped DOM id of the endnote list item. */
    id: string;
    references: LocalFootnoteReferenceSite[];
}
/** What a single `footnoteReference` node renders as. */
export interface LocalFootnoteSite {
    /** Unique DOM id of the reference link; empty for an undefined reference. */
    id: string;
    /** The matching entry, or `null` when no definition exists. */
    entry: LocalFootnoteEntry | null;
    /** Original label, shown as `[^label]` for undefined references. */
    label: string;
}
export interface LocalFootnoteIndex {
    /** Referenced definitions in first-reference order. */
    entries: LocalFootnoteEntry[];
    siteFor(node: LocalNode): LocalFootnoteSite | undefined;
}
/**
 * The parser already normalizes identifiers, but a hand-built tree may carry
 * raw labels. Whitespace runs collapse and case is folded so references and
 * definitions still meet; the renderer never uses this value in HTML.
 */
export declare function normalizeFootnoteIdentifier(value: string): string;
/** Normalized, non-empty identifier used to pair references and definitions. */
export declare function footnoteIdentifier(node: LocalNode): string;
/** Original label shown to readers; never used to build a DOM id. */
export declare function footnoteLabelText(node: LocalNode): string;
/**
 * Collect definitions and references for one document instance.
 *
 * Numbering follows the order references become visible: body references in
 * source order first, then references exposed inside already-numbered endnote
 * bodies. References inside a definition that is never displayed therefore do
 * not create an endnote or a dangling backlink. Duplicate definitions keep the
 * first one; unresolved references render as `[^label]` and are not numbered.
 */
export declare function collectLocalFootnotes(document: LocalDocument, instanceId: string): LocalFootnoteIndex;
