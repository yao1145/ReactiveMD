import type { LocalDocument, LocalRuntime } from './types.js';
/**
 * Binding keys a node subtree reads. `null` marks nodes whose reads cannot be
 * decided statically; their memo boundary must re-render on every revision.
 */
export type NodeDependencies = readonly string[] | null;
export type DependencyIndex = ReadonlyMap<string, NodeDependencies>;
/**
 * Wildcard index used when no analysis is available: a missing entry means the
 * node reads cannot be decided, so it must re-render on every revision.
 */
export declare const EMPTY_DEPENDENCY_INDEX: DependencyIndex;
/**
 * Memo boundaries must observe resets anywhere below them. Keep these sums
 * separate from runtime.resetToken: a descendant reset must not reset the
 * ancestor's own UI state. One traversal per revision also keeps nested block
 * rendering from repeatedly walking the same subtrees.
 */
export declare function collectSubtreeResetTokens(runtime: LocalRuntime): ReadonlyMap<string, number>;
/**
 * Collects, for every node, the union of binding keys read by the node and its
 * descendants. `null` marks a subtree whose reads cannot be decided statically
 * (own analysis failure or any undecidable descendant).
 */
export declare function collectNodeDependencies(document: LocalDocument): DependencyIndex;
/**
 * Persists the dependency index on the document so compiled documents carry
 * the analysis as data. Documents built by hand keep working: the renderer
 * falls back to running the same analysis on first use.
 */
export declare function attachNodeDependencies(document: LocalDocument): void;
