import type { LocalNode } from './types.js';
type CreateNode = (type: string, start: number, end: number, extra?: Partial<LocalNode>) => LocalNode;
/**
 * Parse the text-only subset without allocating Markdown tokenizer events.
 * Validate the entire input before constructing nodes: a later definition,
 * delimiter or indented line can change the meaning of earlier paragraphs.
 * Ambiguous inputs return undefined and use the ordinary Markdown pipeline.
 */
export declare function parsePlainParagraphs(source: string, markdownBreaks: boolean, node: CreateNode): LocalNode[] | undefined;
export {};
