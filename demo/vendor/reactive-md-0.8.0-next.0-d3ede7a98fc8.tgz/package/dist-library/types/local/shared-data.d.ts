import type { LocalCompileResult } from './types.js';
export interface SharedDataResult<T> {
    value: T;
    reused: number;
    created: number;
}
/** Persistent plain-data publication. Neither input nor any prior revision is mutated. */
export declare function shareCompiledData<T>(previous: T | undefined, next: T): SharedDataResult<T>;
/** Lightweight identity index for diagnostics/benchmarking, without publishing it. */
export declare function countSharedNodes(previous: LocalCompileResult | null, next: LocalCompileResult): number;
