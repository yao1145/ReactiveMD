import type { FastMarkdownCache } from './fast-markdown.js';
/** Which deterministic parser budget a rejection belongs to. */
export type ParseBudgetKind = 'parse-work' | 'markdown-depth';
export interface ParseBudgetLimits {
    readonly maxParseWork: number;
    readonly maxMarkdownDepth: number;
}
/**
 * Deterministic budget failure. The parser converts this into a
 * `local.budget` diagnostic; it is never derived from wall-clock time, so a
 * document that fits the budget always compiles the same way.
 */
export declare class ParseBudgetError extends Error {
    readonly kind: ParseBudgetKind;
    readonly limit: number;
    readonly start: number;
    readonly end: number;
    constructor(kind: ParseBudgetKind, limit: number, start: number, end: number);
}
/**
 * Per-parse work and depth accounting.
 *
 * Work units are deliberately abstract: roughly one source code unit scanned
 * or submitted to a general Markdown parse. Cache hits still charge the same
 * units as cache misses so that a session never changes whether a document is
 * accepted. Fenced code, inline code and indented code never contribute
 * Markdown depth; depth is observed from the shared `SourceContext` facts.
 */
export declare class ParseWorkBudget {
    readonly limits: ParseBudgetLimits;
    private usedWork;
    private observedDepth;
    constructor(limits: ParseBudgetLimits);
    get parseWork(): number;
    get maxDepth(): number;
    charge(units: number, start: number, end: number): void;
    observeDepth(depth: number, start: number, end: number): void;
}
/** Cumulative counters exposed by a parse session to the parser. */
export interface ParseSessionCounters {
    readonly hits: number;
    readonly misses: number;
    readonly reusedBlocks: number;
    readonly reusedRows: number;
    readonly reusedItems: number;
    readonly reusedRowNodes: number;
    readonly reusedItemNodes: number;
    readonly reusedAst: number;
}
/**
 * Internal bridge between `parseLocal` and `LocalParseSession`.
 *
 * Only read-only intermediate data (fast plans, inline plans and remark ASTs)
 * is cached. Final `LocalNode` objects are never stored here because the
 * compiler mutates them; `parseLocal` always rebuilds nodes through its own
 * factory with fresh ids and the exact cumulative budget.
 */
export interface ParseSessionCache extends FastMarkdownCache {
    counters(): ParseSessionCounters;
    readTree(text: string): {
        readonly hit: true;
        readonly value: unknown;
    } | {
        readonly hit: false;
    };
    writeTree(text: string, value: unknown): void;
}
