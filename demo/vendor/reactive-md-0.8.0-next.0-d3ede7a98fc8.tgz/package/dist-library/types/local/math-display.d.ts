/**
 * KaTeX-backed display for local LaTeX.
 *
 * This module owns the single rendering and diagnostic implementation used by
 * the React view (`math-view.tsx`) and by compile-time display diagnostics. It
 * stays React-free so the compiler can inspect formulas without importing the
 * renderer.
 *
 * Rendering never throws. The source is pre-scanned against resource budgets
 * and forbidden author commands, then typeset by KaTeX. Any failure falls back
 * to bounded literal text and produces a source-ranged issue, so "shown as
 * literal text" and "reported as a warning" stay in sync.
 */
import type { LocalMathDisplayIssue } from './types.js';
export type { LocalMathDisplayIssue } from './types.js';
import 'katex/contrib/mhchem';
export type LocalMathDisplayIssueReason = 'unsupported-command' | 'unsupported-environment' | 'budget' | 'syntax';
/** Result of typesetting one formula; `html === null` means literal fallback. */
export interface LocalMathDisplayRender {
    /** KaTeX `htmlAndMathml` markup, or `null` when the formula must fall back. */
    html: string | null;
    issues: LocalMathDisplayIssue[];
}
/** Diagnostic code emitted for every display-compatibility issue. */
export declare const MATH_DISPLAY_DIAGNOSTIC_CODE = "local.math.display";
export declare const MATH_DISPLAY_MESSAGE_KEYS: {
    readonly 'unsupported-command': 'local.math.display.unsupported-command';
    readonly 'unsupported-environment': 'local.math.display.unsupported-environment';
    readonly budget: 'local.math.display.budget';
    readonly 'stray-end': 'local.math.display.stray-end';
    readonly 'environment-unclosed': 'local.math.display.environment-unclosed';
    readonly 'environment-missing-name': 'local.math.display.environment-missing-name';
    readonly syntax: 'local.math.display.syntax';
};
export declare const MAX_LOCAL_MATH_DISPLAY_SOURCE = 50000;
export declare const MAX_LOCAL_MATH_DISPLAY_TOKENS = 20000;
export declare const MAX_LOCAL_MATH_DISPLAY_DEPTH = 120;
export declare const MAX_LOCAL_MATH_DISPLAY_FALLBACK = 2000;
/** Bounded literal text used when the whole formula cannot be rendered. */
export declare function boundedLocalMathLiteral(source: string): string;
/**
 * Typeset one formula body with KaTeX, using HTML plus hidden MathML.
 *
 * `html === null` means the caller must show bounded literal text; `issues`
 * then explains why. The pre-scan rejects author macros, HTML/URL/file access
 * and budget overruns before KaTeX runs. KaTeX itself runs with
 * `trust: false`, `throwOnError: true`, a bounded expansion count and a fresh
 * macro table for every formula.
 */
export declare function renderLocalMathDisplay(source: string, display?: boolean): LocalMathDisplayRender;
/**
 * Report every construct that the display renderer degrades to literal text.
 *
 * Offsets are relative to the formula body (`LocalNode.value`). Compute-only
 * limitations (for example `\int` in `<plot>`) are intentionally not reported:
 * they do not affect display.
 */
export declare function inspectLocalMathDisplay(source: string, display?: boolean): LocalMathDisplayIssue[];
