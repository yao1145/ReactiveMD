export declare function trimText(text: string): string;
/** Unicode default lower-case mapping; not tailored to a locale. */
export declare function lowerText(text: string): string;
/** Unicode default upper-case mapping; not tailored to a locale. */
export declare function upperText(text: string): string;
export declare function startsWithText(text: string, search: string): boolean;
export declare function endsWithText(text: string, search: string): boolean;
/**
 * Replace every non-overlapping literal occurrence. There is no pattern or
 * replacement-template interpretation, so `$&` and friends stay literal.
 * The exact output size is counted before building any result.
 */
export declare function replaceLiteral(text: string, search: string, replacement: string): string;
/**
 * Slice by Unicode code point, matching `len()` rather than UTF-16 units.
 * Negative indexes count from the end and out-of-range indexes are clamped.
 */
export declare function sliceCodePoints(text: string, start: number, end: number | undefined): string;
/** Compare two calendar dates: -1 when `left` is earlier, 0 when equal, 1 later. */
export declare function compareDates(left: string, right: string): number;
/** Signed `left - right` difference in the requested unit. */
export declare function diffDates(left: string, right: string, unit?: string): number;
