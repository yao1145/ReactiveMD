export declare function sumNumberArray(values: readonly number[]): number;
export declare function averageNumberArray(values: readonly number[]): number | null;
export declare function minNumberArray(values: readonly number[]): number | null;
export declare function maxNumberArray(values: readonly number[]): number | null;
