import type { Diagnostic } from '../local/types.js';
/** Build a host-level diagnostic for payload, fetch and mount failures. */
export declare function standaloneDiagnostic(code: string, message: string): Diagnostic;
/** Human-readable text used inside thrown errors and the alert fallback. */
export declare function formatStandaloneDiagnostics(diagnostics: readonly Diagnostic[], limit?: number): string;
export declare function errorText(error: unknown): string;
/**
 * Thrown by `mount`/`prepareStandaloneDocument` before any content is mounted.
 * The message embeds the diagnostics; the array is also available programmatically.
 */
export declare class ReactiveMDMountError extends Error {
    readonly diagnostics: Diagnostic[];
    constructor(message: string, diagnostics: Diagnostic[]);
}
/** Recover a diagnostic list from a caught value, keeping unknown errors readable. */
export declare function diagnosticsFromError(error: unknown, fallbackCode?: string): Diagnostic[];
