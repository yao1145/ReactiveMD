import type { Diagnostic } from '../local/types.js';
import type { ShareableMountPayload } from '../shareable.js';
export type MountPayloadParseResult = {
    ok: true;
    payload: ShareableMountPayload;
} | {
    ok: false;
    diagnostics: Diagnostic[];
};
/**
 * Validate the JSON payload embedded by a shareable HTML export. This is a
 * plain-data parser: the source text is never executed and no field is ever
 * interpolated into HTML or a selector.
 */
export declare function parseMountPayload(value: unknown): MountPayloadParseResult;
