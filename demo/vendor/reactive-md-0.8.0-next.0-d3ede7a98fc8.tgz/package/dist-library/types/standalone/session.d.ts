import { type LocalImageResolver, type LocalUrlPolicy } from '../local/LocalDocumentView.js';
import type { LocalLocale } from '../local/locale.js';
import { type LocalStateFile, type LocalStateGenerator } from '../local/state.js';
import type { LocalColorScheme, LocalThemeDefinition } from '../local/theme.js';
import type { Diagnostic, LocalCompileOptions } from '../local/types.js';
import type { LocalReactConfig } from '../react/sdk.js';
import type { LocalExtensionRequirements } from '../sdk/types.js';
import { type LocalRestorationRequirements } from '../export/restoration.js';
import type { LocalStyleResource } from '../sdk/theme.js';
export interface ReactiveMDMountOptions {
    source: string;
    /** Versioned, shareable state; validated against the compiled source. */
    state?: LocalStateFile | string;
    locale?: LocalLocale;
    colorScheme?: LocalColorScheme;
    themes?: readonly LocalThemeDefinition[];
    urlPolicy?: LocalUrlPolicy;
    imageResolver?: LocalImageResolver;
    /** Verified relative image URL -> inline raster data URL for shareable exports. */
    images?: Readonly<Record<string, string>>;
    /** True when hydrating server-rendered static-first markup. */
    hydrate?: boolean;
    generator?: LocalStateGenerator;
    /**
     * Capability flags and limits used by the export. Only explicit host or
     * payload values enable the native HTML route; source text and state never do.
     */
    compileOptions?: LocalCompileOptions;
    /** Trusted implementations explicitly installed by the standalone host. */
    reactConfig?: LocalReactConfig;
    /** Companion contracts checked before state restoration. */
    extensions?: LocalExtensionRequirements;
    restoration?: LocalRestorationRequirements;
    resources?: readonly LocalStyleResource[];
}
export interface ReactiveMDHandle {
    element: HTMLElement;
    getState(): LocalStateFile;
    unmount(): void;
}
/** Internal hooks used by the Web Component; not part of the public mount API. */
export interface StandaloneHostHooks {
    /** Host-only theme override, applied to an immutable document clone. */
    theme?: string;
    onDiagnostics?: (diagnostics: Diagnostic[]) => void;
    onStateChange?: (state: LocalStateFile) => void;
}
export declare const REACTIVE_MD_MOUNTED_ATTRIBUTE = "data-reactive-md-mounted";
export declare function isReactiveMDMounted(element: HTMLElement): boolean;
/**
 * Mount a compiled document and wrap the live runtime in a disposable handle.
 * Used by the public API and by `<reactive-md-doc>`, which supplies host hooks.
 */
export declare function createStandaloneMount(element: HTMLElement, options: ReactiveMDMountOptions, hooks?: StandaloneHostHooks): ReactiveMDHandle;
/** Mount one document into an element. Compiles and validates before touching it. */
export declare function mount(element: HTMLElement, options: ReactiveMDMountOptions): ReactiveMDHandle;
/**
 * Scan the document once for `application/reactive-md+json` auto-mount payloads.
 * Targets are resolved by id only, state is validated by `mount`, and failures
 * are isolated per payload. No MutationObserver is installed.
 */
export declare function mountAll(root?: ParentNode, host?: Pick<ReactiveMDMountOptions, 'reactConfig'>): ReactiveMDHandle[];
