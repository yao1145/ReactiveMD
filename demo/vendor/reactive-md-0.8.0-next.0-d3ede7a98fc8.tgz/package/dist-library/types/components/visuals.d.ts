import { type ReactNode } from 'react';
import type { LocalComponentContext } from '../react/component-api.js';
export declare function VisualFrame({ className, label, children, }: {
    className: string;
    label: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function TableView(context: LocalComponentContext): import("react").JSX.Element;
export declare function ChartView(context: LocalComponentContext): import("react").JSX.Element;
export declare function PlotView(context: LocalComponentContext): import("react").JSX.Element;
export declare function TimelineView(context: LocalComponentContext): import("react").JSX.Element;
export declare function DiagramView(context: LocalComponentContext): import("react").JSX.Element;
export declare function NodeView(context: LocalComponentContext): import("react").JSX.Element;
