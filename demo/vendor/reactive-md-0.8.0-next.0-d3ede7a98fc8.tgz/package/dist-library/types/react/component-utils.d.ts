import { type CSSProperties, type ReactNode } from 'react';
import type { Diagnostic, LocalValue } from './component-primitives.js';
import type { LocalLocale, Localize } from './component-primitives.js';
import type { LocalComponentContext, LocalComponentContent, LocalComponentHint, LocalComponentValue } from './component-api.js';
/**
 * Builtin modules import these from this public React entry instead of
 * reaching into kernel/local internals. The evaluators themselves stay
 * canonical kernel code; nothing is copied here.
 */
export * from './component-primitives.js';
/** Convenience view over one public component context. */
export interface LocalComponentView {
    readonly context: LocalComponentContext;
    readonly content: LocalComponentContent;
    readonly props: Readonly<Record<string, LocalComponentValue>>;
    readonly runtime: LocalComponentContext['runtime'];
    readonly bindings: LocalComponentContext['bindings'];
    readonly children: LocalComponentContext['children'];
    readonly mode: LocalComponentContext['mode'];
    readonly visible: boolean;
    readonly disabled: boolean;
    readonly disabledInvalid: boolean;
    readonly resetToken: number;
    readonly t: Localize;
    readonly locale: LocalLocale;
    readonly validation: LocalComponentContext['validation'];
    readonly source: LocalComponentContext['source'];
    readonly navigation: LocalComponentContext['navigation'];
    readonly url: LocalComponentContext['url'];
    readonly report: (diagnostics: Diagnostic[]) => void;
    render(items?: readonly LocalComponentContent[], visible?: boolean): ReactNode;
    renderInline(items?: readonly LocalComponentContent[], visible?: boolean): ReactNode;
}
export declare function useComponentView(context: LocalComponentContext): LocalComponentView;
export declare function useWriter(context: LocalComponentContext): {
    write: (value: LocalValue, slot?: string) => boolean;
    writeMany: (values: Readonly<Record<string, LocalValue>>) => boolean;
    error: string | null;
    setError: import("react").Dispatch<import("react").SetStateAction<string | null>>;
};
export declare function useDisabled(context: LocalComponentContext): {
    disabled: boolean;
    invalid: boolean;
};
export declare function useValidationField(context: LocalComponentContext, item?: LocalComponentContent): import("./component-api.js").LocalComponentField;
export declare function useValidationHint(context: LocalComponentContext, item?: LocalComponentContent): LocalComponentHint | null;
export declare function useSourceAttributes(context: LocalComponentContext, item?: LocalComponentContent): Record<string, string>;
export declare function useResetToken(context: LocalComponentContext, onReset: () => void): void;
export declare function rawAttr(content: LocalComponentContent, name: string): string | undefined;
export declare function componentProp(context: LocalComponentContext, name: string): LocalComponentValue;
/** Resolved text prop with the legacy fallback and failure marker. */
export declare function textAttr(context: LocalComponentContext, name: string, fallback?: string): string;
export declare function numberAttr(context: LocalComponentContext, name: string, fallback: number): number;
/** Text prop of a projected child component (e.g. tab/step/option labels). */
export declare function itemText(context: LocalComponentContext, item: LocalComponentContent, name: string, fallback?: string): string;
/** Boolean prop of a projected child component. */
export declare function itemBool(context: LocalComponentContext, item: LocalComponentContent, name: string, fallback?: boolean): boolean;
export type ConstraintRead<T> = {
    present: false;
    error: false;
} | {
    present: true;
    error: true;
} | {
    present: true;
    error: false;
    value: T;
};
export declare function numberConstraint(context: LocalComponentContext, name: string): ConstraintRead<number>;
export declare function dateConstraint(context: LocalComponentContext, name: string): ConstraintRead<string>;
export declare function readBooleanAttr(context: LocalComponentContext, name: string, fallback: boolean): {
    ok: true;
    value: boolean;
} | {
    ok: false;
};
export declare function boolAttr(context: LocalComponentContext, name: string, fallback?: boolean): boolean;
export declare function toneAttr<T extends string>(context: LocalComponentContext, name: string, values: readonly T[], fallback: T): {
    tone: T;
    error: boolean;
};
export declare function localColor(content: LocalComponentContent): string | undefined;
export declare function accentStyle(color: string | undefined): CSSProperties | undefined;
export declare function scalarText(value: LocalValue | LocalComponentValue): string | null;
export declare function displayValue(value: LocalComponentValue): string;
export declare function currentValue(context: LocalComponentContext): LocalComponentValue;
export declare function slotNumber(context: LocalComponentContext, slot: string, fallback: number): number;
export declare function clamp(value: number, min: number, max: number): number;
export declare function snapToStep(value: number, min: number, max: number, step: number): number;
export declare function numericRange(context: LocalComponentContext, minName: string, maxName: string, minFallback: number, maxFallback: number, stepFallback?: number): {
    min: number;
    max: number;
    step: number;
};
export declare const EMPTY_STATIC_VALUE = "\u2014";
export declare function staticText(value: string): string;
export declare function StaticValue({ label, value, hint, className, multiline, }: {
    label: string;
    value: ReactNode;
    hint?: ReactNode;
    className?: string;
    multiline?: boolean;
}): import("react").JSX.Element;
export declare function PrintValue({ value, block }: {
    value: ReactNode;
    block?: boolean;
}): import("react").JSX.Element;
export declare function FieldError({ message }: {
    message: string | null;
}): import("react").JSX.Element | null;
export declare function LocalError({ message }: {
    message?: string;
}): import("react").JSX.Element;
export declare function ToneProblem({ message }: {
    message: string;
}): import("react").JSX.Element;
export declare function formatSeconds(seconds: number, t: Localize): string;
export declare function formatNumber(value: number): string;
/** Plain text of a projected inline child list (interpolations evaluated). */
export declare function inlinePlainText(context: LocalComponentContext, items: readonly LocalComponentContent[] | undefined, seen?: number): string;
export declare function optionLabel(context: LocalComponentContext, option: {
    content: LocalComponentContent;
}): string;
export declare function renderInlineNodes(view: LocalComponentView, items: readonly LocalComponentContent[] | undefined, visible?: boolean): ReactNode;
