/**
 * Stable public adapter primitives for component implementations.
 *
 * These are canonical kernel/rendering utilities re-exported behind a public
 * entry so builtin and external components can share the same limits, text
 * length, expression, math, table surface and diagram layout behaviour. The
 * implementations are not copied: they remain the kernel modules.
 */
export { DEFAULT_LOCAL_DATA_TABLE_ROWS, MAX_LOCAL_ARRAY_LENGTH, MAX_LOCAL_DATA_TABLE_COLUMNS, MAX_LOCAL_DATA_TABLE_ROWS, MAX_LOCAL_PLOT_CURVES, MAX_LOCAL_PLOT_POINTS, MAX_LOCAL_PLOT_STEPS, MAX_LOCAL_STRING_LENGTH, MAX_LOCAL_VALUE_CHARACTERS, isLocalEmail, } from '../local/limits.js';
export { countLocalCodePoints } from '../local/text-length.js';
export { formatLocalDiagnostic } from '../local/diagnostics.js';
export { compileExpression, type LocalExpression } from '../local/expression.js';
export { compileLatex, LatexError, samplePlot, type LatexEvaluationBudget, } from '../local/math.js';
export { LatexView } from '../local/math-view.js';
export { TableSurface } from '../local/table-surface.js';
export { createDiagramLayoutFallback, diagramEdgePath, diagramLayoutKey, layoutDiagram, type DiagramLayoutInput, type DiagramLayoutResult, } from '../local/diagram-layout.js';
export { isLocalColor } from '../local/colors.js';
export type { Diagnostic, LocalValue } from '../local/types.js';
export type { LocalRenderMode } from '../local/render-types.js';
export type { LocalLocale, Localize } from '../local/i18n.js';
