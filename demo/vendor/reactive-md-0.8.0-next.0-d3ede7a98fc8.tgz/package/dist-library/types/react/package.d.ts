import { type LocalComponentDefinition } from '../sdk/types.js';
import type { LocalStyleResource, LocalThemePackage } from '../sdk/theme.js';
import { type LocalReactConfig } from './sdk.js';
import { type LocalReactComponent, type LocalReactComponentImplementation } from './component-api.js';
export interface LocalPackageNotice {
    readonly id: string;
    readonly name?: string;
    readonly version?: string;
    readonly license?: string;
    readonly url?: string;
    readonly text?: string;
}
export type LocalReactComponentPackageInput = Omit<LocalComponentDefinition, 'protocol' | 'form' | 'props'> & Partial<Pick<LocalComponentDefinition, 'protocol' | 'form' | 'props'>> & LocalReactComponentImplementation & {
    readonly css?: string;
    readonly resources?: readonly LocalStyleResource[];
};
export interface LocalReactPackage {
    readonly components: readonly LocalReactComponent[];
    readonly resources?: readonly LocalStyleResource[];
    readonly themes?: readonly LocalThemePackage[];
    readonly notices?: readonly LocalPackageNotice[];
}
export interface LocalReactComponentPackage extends LocalReactPackage {
    readonly definition: LocalComponentDefinition;
    readonly resources: readonly LocalStyleResource[];
}
/** One authoring declaration; its manifest stays plain data for Worker use. */
export declare function defineReactComponentPackage(input: LocalReactComponentPackageInput): LocalReactComponentPackage;
export interface LocalReactHostInput {
    readonly packages?: readonly LocalReactPackage[];
    readonly components?: readonly LocalReactComponent[];
    readonly themes?: readonly LocalThemePackage[];
    readonly resources?: readonly LocalStyleResource[];
    readonly notices?: readonly LocalPackageNotice[];
}
export interface LocalReactHost {
    readonly config: LocalReactConfig['config'];
    readonly reactConfig: LocalReactConfig;
    readonly compileOptions: Readonly<{
        config: LocalReactConfig['config'];
    }>;
    readonly resources: readonly LocalStyleResource[];
    readonly css: string;
    readonly notices: readonly LocalPackageNotice[];
}
/** Compose packages once for compiler, renderer, authoring and export. */
export declare function createReactHost(input?: LocalReactHostInput): LocalReactHost;
