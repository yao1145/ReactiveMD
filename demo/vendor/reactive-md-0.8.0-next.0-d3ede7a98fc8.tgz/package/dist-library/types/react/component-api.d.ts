import { type ComponentType, type ReactNode } from 'react';
import type { Diagnostic, LocalNode, LocalRuntime, LocalSnapshot, LocalValue, SourceRange } from '../local/types.js';
import type { LocalRenderMode, LocalSourceTarget } from '../local/render-types.js';
import type { LocalUrlPolicy } from '../local/LocalDocumentView.js';
import type { LocalLocale } from '../local/i18n.js';
import type { LocalComponentDefinition, LocalComponentRequirement } from '../sdk/types.js';
import type { LocalExtensionRequirements } from '../sdk/types.js';
/** A public component value. Arrays are the immutable collection form. */
export type LocalComponentValue = string | number | boolean | null | readonly string[] | readonly number[];
/** @deprecated phase-one alias; scalar-only views can keep using it. */
export type LocalComponentPropValue = string | number | boolean | null;
export interface LocalComponentSetResult {
    readonly ok: boolean;
    readonly diagnostics: Diagnostic[];
}
export interface LocalComponentBindingHandle {
    get(): LocalComponentValue;
    set(next: LocalComponentValue): LocalComponentSetResult;
}
/**
 * Normalized content projection handed to builtin and external components.
 *
 * This is deliberately not `LocalNode`: it carries only identity, the
 * component name, resolved props, explicitly requested raw attributes, plain
 * text/format and projected children. The adapter keeps the internal node
 * behind an opaque symbol that no component implementation can read.
 */
export interface LocalComponentContent {
    readonly id: string;
    /** `'component'` or the Markdown/content kind (text, table, list, math, ...). */
    readonly kind: string;
    /** Component tag name for `kind: 'component'`, otherwise an empty string. */
    readonly name: string;
    readonly form?: 'leaf' | 'inline' | 'container';
    readonly props: Readonly<Record<string, LocalComponentValue>>;
    /** Raw authored attributes, available only when a view explicitly asks. */
    readonly attrs: Readonly<Record<string, string>>;
    /** Current binding value of this node (null when it owns no binding). */
    readonly value: LocalComponentValue;
    /** Plain text for Markdown text/leaf nodes and math source. */
    readonly text: string;
    /** Markdown/content format marker (`math`, `inlineMath`, code language, ...). */
    readonly format?: string;
    readonly visible: boolean;
    readonly children: readonly LocalComponentContent[];
    readonly range: Readonly<SourceRange>;
}
export declare function readContentNode(content: LocalComponentContent): LocalNode;
export type LocalComponentTableCellKind = 'number' | 'string' | 'boolean' | 'null' | 'array' | 'empty' | 'error';
export interface LocalComponentTableCell {
    readonly text: string;
    readonly value: LocalValue | undefined;
    readonly kind: LocalComponentTableCellKind;
    readonly numeric: number | null;
    readonly error: string | null;
    readonly render: () => ReactNode;
}
export interface LocalComponentTableProjection {
    readonly header: readonly LocalComponentTableCell[];
    readonly headerText: readonly string[];
    readonly rows: readonly {
        readonly index: number;
        readonly cells: readonly LocalComponentTableCell[];
    }[];
}
export interface LocalComponentOption {
    readonly value: string;
    readonly content: LocalComponentContent;
    readonly label: string;
    render(): ReactNode;
}
export interface LocalComponentField {
    readonly describedBy?: string;
    readonly invalid: boolean;
}
export interface LocalComponentHint {
    readonly id: string;
    readonly failed: boolean;
    readonly error: boolean;
    readonly message: string;
}
export interface LocalComponentRuntime {
    /** Opaque identity shared by components using the same document runtime. */
    readonly identity: object;
    get(item: LocalComponentContent, slot?: string): LocalComponentValue;
    set(item: LocalComponentContent, next: LocalComponentValue, slot?: string): Diagnostic[];
    setMany(item: LocalComponentContent, values: Readonly<Record<string, LocalComponentValue>>): Diagnostic[];
    reset(item: LocalComponentContent): void;
    resetToken(item: LocalComponentContent): number;
    evaluate(expression: string): LocalComponentValue;
    snapshot(): LocalSnapshot;
    validate(): Diagnostic[];
    text(template: string): string;
}
export interface LocalComponentChildrenApi {
    render(): ReactNode;
    inline(): ReactNode;
    text(): string;
    items(): readonly LocalComponentContent[];
    /** Render a projected child list as blocks. */
    renderItems(items: readonly LocalComponentContent[], visible?: boolean): ReactNode;
    /** Render a projected child list as inline content. */
    renderInlineItems(items: readonly LocalComponentContent[], visible?: boolean): ReactNode;
    /** Plain text of a projected child list (interpolations evaluated). */
    textOf(items: readonly LocalComponentContent[]): string;
    options(): readonly LocalComponentOption[];
    table(): LocalComponentTableProjection | null;
    math(): readonly LocalComponentContent[];
}
export interface LocalComponentNavigationApi {
    targetId(to: string): string | undefined;
    anchorId(): string | undefined;
    /** Host URL policy check for an internal jump target. */
    allowed(to: string): boolean;
    /** Focus and scroll to an anchor; returns why it failed otherwise. */
    jump(to: string): 'ok' | 'missing' | 'hidden';
}
export interface LocalComponentUrlApi {
    resolve(raw: string | undefined, kind: 'image' | 'link'): string | null;
    image(raw: string | undefined): string | null;
}
export interface LocalComponentLocaleApi {
    readonly locale: LocalLocale;
    t(en: string, zh: string): string;
    formatNumber(value: number): string;
}
/** Context passed to every SDK component. It contains no AST. */
export interface LocalComponentContext {
    readonly props: Readonly<Record<string, LocalComponentValue>>;
    readonly content: LocalComponentContent;
    readonly bindings: {
        readonly value: LocalComponentBindingHandle;
        readonly slots: Readonly<Record<string, LocalComponentBindingHandle>>;
        readonly isReadOnly: boolean;
        get(name?: string): LocalComponentValue;
        set(name: string, next: LocalComponentValue): LocalComponentSetResult;
        setMany(values: Readonly<Record<string, LocalComponentValue>>): LocalComponentSetResult;
    };
    readonly children: LocalComponentChildrenApi;
    readonly runtime: LocalComponentRuntime;
    readonly instance: LocalComponentInstance;
    readonly mode: LocalRenderMode;
    readonly visible: boolean;
    readonly disabled: boolean;
    readonly disabledInvalid: boolean;
    readonly resetToken: number;
    readonly validation: {
        fieldFor(item: LocalComponentContent): LocalComponentField;
        hintFor(item: LocalComponentContent): LocalComponentHint | null;
    };
    readonly source: {
        attributes(item?: LocalComponentContent): Record<string, string>;
    };
    readonly navigation: LocalComponentNavigationApi;
    readonly url: LocalComponentUrlApi;
    readonly locale: LocalComponentLocaleApi;
    report(diagnostics: Diagnostic[]): void;
}
export interface LocalComponentInstance {
    readonly id: string;
    readonly componentId: string;
    readonly range: Readonly<SourceRange>;
}
export type LocalComponentRender = ComponentType<LocalComponentContext>;
export interface LocalReactComponentImplementation {
    render: LocalComponentRender;
    renderStatic?: LocalComponentRender;
}
export interface LocalReactComponent extends LocalReactComponentImplementation {
    readonly definition: LocalComponentDefinition;
    readonly digest: string;
}
export interface LocalReactPreset {
    readonly id: string;
    readonly version: string;
    readonly components: readonly LocalReactComponent[];
}
/**
 * Host surface used by the adapter to construct public contexts. It exposes
 * internal nodes only to `component-api`, never to component implementations.
 */
export interface LocalComponentAdapterEnvironment {
    readonly runtime: LocalRuntime;
    readonly mode: LocalRenderMode;
    readonly locale: LocalLocale;
    readonly visible: boolean;
    readonly disabled: boolean;
    readonly disabledInvalid: boolean;
    readonly resetToken: number;
    readonly definitionFor: (name: string) => LocalComponentDefinition | undefined;
    readonly validationFieldFor: (node: LocalNode) => LocalComponentField;
    readonly validationHintFor: (node: LocalNode) => LocalComponentHint | null;
    readonly sourceAttributes: (node: LocalNode, componentName?: string) => Record<string, string>;
    readonly renderChildren: (nodes: LocalNode[] | undefined, visible: boolean, block?: boolean) => ReactNode;
    readonly renderInline: (nodes: LocalNode[] | undefined, visible: boolean) => ReactNode;
    readonly renderToText: (nodes: LocalNode[] | undefined) => string;
    readonly report: (diagnostics: Diagnostic[]) => void;
    /** Optional source position for adapter-owned diagnostics. */
    readonly positionOf?: (offset: number) => {
        line: number;
        column: number;
    };
    readonly targetId: (to: string) => string | undefined;
    readonly anchorId: (node: LocalNode) => string | undefined;
    readonly jumpAllowed: (to: string) => boolean;
    readonly jumpTo: (target: string) => 'ok' | 'missing' | 'hidden';
    readonly urlPolicy?: LocalUrlPolicy;
    readonly imageResolver?: (url: string) => string | null;
}
export declare function formatComponentNumber(value: number): string;
/** Public values are immutable; kernel arrays are copied on the way out. */
export declare function publicComponentValue(value: LocalValue | undefined): LocalComponentValue;
export interface PropFailureSink {
    readonly environment: LocalComponentAdapterEnvironment;
    /** Minimal adapter-side identity; not an AST handle. */
    readonly node: {
        readonly id: string;
        readonly name?: string;
        readonly range: SourceRange;
    };
}
/**
 * Start one document render pass. Static rendering clears its per-pass prop
 * diagnostic memory so a later independent render still reports, while
 * nested contexts in the same pass do not duplicate the same failure.
 */
export declare function beginLocalComponentRender(runtime: LocalRuntime): void;
export declare function resolveComponentProps(definition: LocalComponentDefinition | undefined, attrs: Readonly<Record<string, string>> | undefined, runtime: LocalRuntime, failure?: PropFailureSink): Record<string, LocalComponentValue>;
/**
 * Build the public context for one component node. Called by the renderer;
 * external implementations receive exactly this object.
 */
export declare function createLocalComponentContext(node: LocalNode, environment: LocalComponentAdapterEnvironment): LocalComponentContext;
/**
 * Bind a React implementation to a validated manifest. The digest is captured
 * here and rechecked when the config is assembled.
 */
export declare function defineReactComponent(definition: LocalComponentDefinition, implementation: LocalReactComponentImplementation): LocalReactComponent;
export interface LocalExtensionRequirementsLike extends LocalExtensionRequirements {
}
export type { LocalComponentDefinition, LocalComponentRequirement, LocalSourceTarget };
