import { r as e } from "./compiler-core-BHoOCraa.js";
import { g as t, h as n } from "./html-C8ehjOX3.js";
import { t as r } from "./default-components-B35-K5DU.js";
import { t as i } from "./registry-core-cpcSrHKF.js";
import { n as a } from "./options-DRZTLoJk.js";
// src/local/parser.ts
function o(t, n, r, i, o) {
	return typeof t != "string" || t.length > 1e6 ? e(t, void 0, r, i, o) : e(t, a(n), r, i, o);
}
// src/local/schema.ts
function s() {
	let e = r.map(i), t = e.findIndex((e) => e.name === "validation"), a = t < 0 ? e.length : t;
	return Object.freeze([
		...e.slice(0, a),
		...n,
		...e.slice(a)
	]);
}
var c = s(), l = Object.freeze(Object.fromEntries(c.map((e) => [e.name, Object.freeze(e)]))), u = Object.freeze(c.map((e) => e.name)), d = Object.freeze({
	leaf: Object.freeze(c.filter((e) => e.form === "leaf").map((e) => e.name)),
	inline: Object.freeze(c.filter((e) => e.form === "inline").map((e) => e.name)),
	container: Object.freeze(c.filter((e) => e.form === "container").map((e) => e.name))
});
function f(e) {
	return d[e];
}
function p(e) {
	return Object.hasOwn(l, e) ? l[e] : void 0;
}
function m(e, t) {
	return e.props[t]?.default;
}
function h(e) {
	return t(e, u);
}
function g(e, n) {
	return t(n, Object.keys(e.props));
}
export { f as a, o as c, m as i, u as n, g as o, p as r, h as s, l as t };
