import { n as e } from "./props-DyiH0-0M.js";
import { A as t, G as n, I as r, J as i, K as a, M as o, P as s, R as c, U as l, X as u, Y as d, Z as f, at as p, ct as m, nt as ee, st as h } from "./default-components-B35-K5DU.js";
import { a as g, c as _, i as te, o as v, p as y, s as ne, t as re, u as ie } from "./registry-core-cpcSrHKF.js";
// src/local/dates.ts
function ae(e) {
	let t = /^(\d{4})-(\d{2})-(\d{2})$/.exec(e);
	if (!t) return null;
	let n = Number(t[1]), r = Number(t[2]), i = Number(t[3]);
	if (n < 1 || r < 1 || r > 12 || i < 1 || i > 31) return null;
	let a = /* @__PURE__ */ new Date(0);
	return a.setUTCFullYear(n, r - 1, i), a.getUTCFullYear() === n && a.getUTCMonth() === r - 1 && a.getUTCDate() === i ? a.getTime() : null;
}
// src/local/text-length.ts
function oe(e) {
	if (typeof e != "string") return 0;
	let t = 0;
	for (let n of e) t += 1;
	return t;
}
// src/local/types.ts
var se = (e) => e.attrs?.bind ?? `@${e.id}`, ce = class extends Error {
	code;
	constructor(e, t) {
		super(t), this.name = "LocalFunctionError", this.code = e;
	}
}, le = [
	"en-US",
	"zh-CN",
	"de-DE",
	"fr-FR",
	"ja-JP"
], ue = new Set(le), de = /^[A-Z]{3}$/, fe = 20;
function pe(e) {
	throw new ce("expression-domain", e);
}
function me(e, t) {
	if (e.length > 1e5) throw new ce("expression-budget", `${t} exceeds the ${h}-character limit.`);
	return e;
}
function he(e) {
	return ue.has(e) || pe(`Unsupported locale "${e}"; expected one of ${le.join(", ")}.`), e;
}
function ge(e, t) {
	return (!Number.isInteger(e) || e < 0 || e > fe) && pe(`${t} digits must be an integer from 0 to ${fe}.`), e;
}
function _e(e) {
	if (!Number.isFinite(e)) throw new ce("expression-number", "Value must be a finite number.");
	return e;
}
function ve(e) {
	return e === 0 ? 0 : e;
}
function ye(e, t) {
	let n = _e(e);
	return n === 0 || Math.abs(n) < .5 * 10 ** -t ? 0 : n;
}
function be(e, t) {
	let n = _e(e);
	return n === 0 || Math.abs(n) < .5 * 10 ** -(t + 2) ? 0 : n;
}
function xe(e, t, n, r, i) {
	let a;
	try {
		a = new Intl.NumberFormat(e, t);
	} catch {
		a = void 0;
	}
	return a === void 0 && pe(i), me(a.format(n), r);
}
function Se(e, t = 2, n = "en-US", r = !0) {
	let i = he(n), a = ge(t, "formatNumber");
	return typeof r != "boolean" && pe("formatNumber grouping must be a boolean."), e === null ? "" : xe(i, {
		useGrouping: r,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, ye(e, a), "Formatted number", `Cannot format a number for locale "${i}".`);
}
function Ce(e, t = 0, n = "en-US") {
	let r = he(n), i = ge(t, "formatPercent");
	return e === null ? "" : xe(r, {
		style: "percent",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, be(e, i), "Formatted percentage", `Cannot format a percentage for locale "${r}".`);
}
function we(e, t = 2, n = "en-US") {
	let r = he(n), i = ge(t, "formatScientific");
	return e === null ? "" : xe(r, {
		notation: "scientific",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, ve(_e(e)), "Formatted number", `Cannot format a number for locale "${r}".`);
}
function Te(e, t = "USD", n = 2, r = "en-US") {
	let i = he(r);
	de.test(t) || pe(`Currency "${t}" must be a three-letter uppercase code such as "USD".`);
	let a = ge(n, "formatCurrency");
	return e === null ? "" : xe(i, {
		style: "currency",
		currency: t,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, ye(e, a), "Formatted currency", `Currency code "${t}" is not accepted by Intl.`);
}
// src/local/collection-functions.ts
function Ee() {
	throw new ce("expression-number", "The result is not a finite number.");
}
function De(e) {
	if (!Number.isFinite(e)) throw new ce("expression-value", "Numeric array members must be finite numbers.");
	return e;
}
function Oe(e) {
	let t = 0;
	for (let n of e) t += De(n);
	return Number.isFinite(t) || Ee(), t;
}
function ke(e) {
	if (e.length === 0) return null;
	let t = Oe(e) / e.length;
	return Number.isFinite(t) || Ee(), t;
}
function Ae(e) {
	if (e.length === 0) return null;
	let t = De(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = De(e[n]);
		r < t && (t = r);
	}
	return t;
}
function je(e) {
	if (e.length === 0) return null;
	let t = De(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = De(e[n]);
		r > t && (t = r);
	}
	return t;
}
// src/local/data-functions.ts
function Me(e) {
	throw new ce("expression-domain", e);
}
function Ne(e) {
	return me(e.trim(), "trim result");
}
function Pe(e) {
	return me(e.toLowerCase(), "lower result");
}
function Fe(e) {
	return me(e.toUpperCase(), "upper result");
}
function Ie(e, t) {
	return e.startsWith(t);
}
function Le(e, t) {
	return e.endsWith(t);
}
function Re(e, t, n) {
	t.length === 0 && Me("replace search text must not be empty.");
	let r = n.length - t.length;
	if (r > 0) {
		let n = 0, i = 0;
		for (;;) {
			let r = e.indexOf(t, i);
			if (r < 0) break;
			n += 1, i = r + t.length;
		}
		if (e.length + n * r > 1e5) throw new ce("expression-budget", `replace result would exceed the ${h}-character limit.`);
	}
	let i = "", a = 0;
	for (;;) {
		let r = e.indexOf(t, a);
		if (r < 0) break;
		i += e.slice(a, r), i += n, a = r + t.length;
	}
	return i += e.slice(a), me(i, "replace result");
}
function ze(e, t) {
	return e < 0 ? Math.max(t + e, 0) : Math.min(e, t);
}
function Be(e, t, n) {
	Number.isInteger(t) || Me("slice start must be an integer."), n !== void 0 && !Number.isInteger(n) && Me("slice end must be an integer.");
	let r = Array.from(e), i = r.length, a = ze(t, i), o = n === void 0 ? i : ze(n, i);
	return o <= a ? "" : me(r.slice(a, o).join(""), "slice result");
}
var Ve = /* @__PURE__ */ new Map([
	["days", 864e5],
	["hours", 36e5],
	["minutes", 6e4],
	["seconds", 1e3],
	["milliseconds", 1]
]), He = "days, hours, minutes, seconds or milliseconds";
function Ue(e) {
	let t = ae(e);
	if (t === null) throw new ce("expression-domain", `Date "${e}" must be a valid YYYY-MM-DD calendar date in years 0001-9999.`);
	return t;
}
function We(e, t) {
	let n = Ue(e), r = Ue(t);
	return n === r ? 0 : n < r ? -1 : 1;
}
function Ge(e, t, n = "days") {
	let r = Ve.get(n);
	return r === void 0 && Me(`dateDiff unit must be ${He}.`), (Ue(e) - Ue(t)) / r;
}
// src/local/expression.ts
var b = class extends Error {
	offset;
	code;
	constructor(e, t, n = 0) {
		super(t), this.name = "LocalExpressionError", this.code = e, this.offset = n;
	}
}, Ke = /* @__PURE__ */ "abs.sqrt.floor.ceil.round.min.max.pow.sin.cos.tan.asin.acos.atan.exp.log.len.contains.clamp.sum.average.minOf.maxOf.formatNumber.formatPercent.formatScientific.formatCurrency.trim.lower.upper.startsWith.endsWith.replace.slice.dateCompare.dateDiff".split("."), qe = new Set(Ke), Je = /* @__PURE__ */ new Map([["pi", Math.PI], ["e", Math.E]]), Ye = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]), Xe = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]), Ze = /* @__PURE__ */ new Set([
	...Ke,
	"x",
	"y",
	"pi",
	"e",
	"true",
	"false",
	"null",
	...Ye
]), Qe = 4e3, $e = 2e3, et = 100, tt = 200, nt = 1e4, rt = 250, it = h, at = h, ot = 500;
function st(e) {
	if (e.length > 1e4) return {
		code: "expression-budget",
		...y("local.budget.value.array", { limit: f }),
		message: `Array exceeds the ${f}-item limit.`
	};
	let t = null, n = 0;
	for (let r of e) if (typeof r == "string") {
		if (t === "number") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (t = "string", r.length > 1e5) return {
			code: "expression-budget",
			...y("local.budget.value.array-member", { limit: h }),
			message: `Array member exceeds the ${h}-character limit.`
		};
		if (n += r.length, n > 1e5) return {
			code: "expression-budget",
			...y("local.budget.value.array-contents", { limit: m }),
			message: `Array contents exceed the ${m}-character limit.`
		};
	} else if (typeof r == "number") {
		if (t === "string") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (t = "number", !Number.isFinite(r)) return {
			code: "expression-value",
			key: "error.array.finite",
			message: "Array members must be finite numbers."
		};
	} else return {
		code: "expression-value",
		key: "error.array.members",
		message: "Array members must be strings or finite numbers."
	};
	return null;
}
function ct(e) {
	if (typeof e == "string") return e.length > 1e5 ? y("local.budget.value.string", { limit: h }) : null;
	if (Array.isArray(e)) {
		let t = st(e);
		return t ? y(t.key, t.params) : null;
	}
	return null;
}
function lt(e) {
	let t = ct(e);
	return t ? ie(t) : null;
}
var ut = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/, dt = /[A-Za-z_]/, ft = /[A-Za-z0-9_]/;
function pt(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r >= "0" && r <= "9" || r === "." && /[0-9]/.test(e[n + 1] ?? "")) {
			let r = ut.exec(e.slice(n));
			if (!r) throw new b("expression-syntax", "Invalid number.", n);
			let i = r[0], a = Number(i);
			if (!Number.isFinite(a)) throw new b("expression-number", `Number must be finite: ${i}.`, n);
			t.push({
				kind: "number",
				value: i,
				start: n,
				number: a
			}), n += i.length;
			continue;
		}
		if (r === "\"" || r === "'") {
			let i = n, a = r, o = "", s = n + 1, c = !1;
			for (; s < e.length;) {
				let t = e[s];
				if (t === a) {
					c = !0, s += 1;
					break;
				}
				if (t === "\n" || t === "\r") throw new b("expression-string", "String literals cannot span lines.", i);
				if (t === "\\") {
					let t = e[s + 1];
					if (t === void 0) break;
					switch (t) {
						case "\\":
							o += "\\";
							break;
						case "'":
							o += "'";
							break;
						case "\"":
							o += "\"";
							break;
						case "n":
							o += "\n";
							break;
						case "t":
							o += "	";
							break;
						default: throw new b("expression-string", `Unsupported escape \\${t}.`, s);
					}
					s += 2;
				} else o += t, s += 1;
			}
			if (!c) throw new b("expression-string", "Unterminated string literal.", i);
			if (o.length > it) throw new b("expression-budget", "String literal exceeds the length limit.", i);
			t.push({
				kind: "string",
				value: o,
				start: i
			}), n = s;
			continue;
		}
		if (dt.test(r)) {
			let r = n + 1;
			for (; r < e.length && ft.test(e[r]);) r += 1;
			t.push({
				kind: "ident",
				value: e.slice(n, r),
				start: n
			}), n = r;
			continue;
		}
		let i = e.slice(n, n + 2);
		if (e.startsWith("!==", n) || e.startsWith("===", n)) throw new b("expression-syntax", `Unsupported operator ${e.slice(n, n + 3)}.`, n);
		if (i === "==" || i === "!=" || i === "<=" || i === ">=" || i === "&&" || i === "||") t.push({
			kind: "punct",
			value: i,
			start: n
		}), n += 2;
		else if ("+-*/%()!<>?:,[]".includes(r)) t.push({
			kind: "punct",
			value: r,
			start: n
		}), n += 1;
		else throw r === "=" ? new b("expression-assignment", "Assignments are not supported.", n) : r === "." ? new b("expression-property", "Property access is not supported.", n) : r === "&" || r === "|" ? new b("expression-syntax", `Use ${r}${r} for logical operations.`, n) : new b("expression-syntax", `Unrecognized character "${r}".`, n);
	}
	return t.push({
		kind: "eof",
		value: "",
		start: e.length
	}), t;
}
var mt = {
	abs: [1, 1],
	sqrt: [1, 1],
	floor: [1, 1],
	ceil: [1, 1],
	round: [1, 1],
	min: [1, 2 ** 53 - 1],
	max: [1, 2 ** 53 - 1],
	pow: [2, 2],
	sin: [1, 1],
	cos: [1, 1],
	tan: [1, 1],
	asin: [1, 1],
	acos: [1, 1],
	atan: [1, 1],
	exp: [1, 1],
	log: [1, 1],
	len: [1, 1],
	contains: [2, 2],
	clamp: [3, 3],
	sum: [1, 1],
	average: [1, 1],
	minOf: [1, 1],
	maxOf: [1, 1],
	formatNumber: [1, 4],
	formatPercent: [1, 3],
	formatScientific: [1, 3],
	formatCurrency: [1, 4],
	trim: [1, 1],
	lower: [1, 1],
	upper: [1, 1],
	startsWith: [2, 2],
	endsWith: [2, 2],
	replace: [3, 3],
	slice: [2, 3],
	dateCompare: [2, 2],
	dateDiff: [2, 3]
};
function ht(e) {
	let t = 0, n = [{
		node: e,
		depth: 1
	}];
	for (; n.length > 0;) {
		let { node: e, depth: r } = n.pop();
		switch (r > t && (t = r), e.kind) {
			case "unary":
				n.push({
					node: e.operand,
					depth: r + 1
				});
				break;
			case "binary":
				n.push({
					node: e.left,
					depth: r + 1
				}), n.push({
					node: e.right,
					depth: r + 1
				});
				break;
			case "conditional":
				n.push({
					node: e.test,
					depth: r + 1
				}), n.push({
					node: e.consequent,
					depth: r + 1
				}), n.push({
					node: e.alternate,
					depth: r + 1
				});
				break;
			case "call":
				for (let t of e.args) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "array":
				for (let t of e.elements) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "index": n.push({
				node: e.target,
				depth: r + 1
			}), n.push({
				node: e.index,
				depth: r + 1
			});
		}
	}
	return t;
}
var gt = class {
	tokens;
	position = 0;
	nodeCount = 0;
	dependencyNames = [];
	dependencySet = /* @__PURE__ */ new Set();
	constructor(e) {
		this.tokens = pt(e);
	}
	get dependencies() {
		return this.dependencyNames;
	}
	parse() {
		if (this.peek().kind === "eof") throw new b("expression-empty", "Expression is empty.", 0);
		let e = this.parseConditional(0), t = this.peek();
		if (t.kind !== "eof") throw new b("expression-syntax", `Unexpected content "${t.value}".`, t.start);
		if (ht(e) > tt) throw new b("expression-budget", "Expression is nested too deeply.", e.start);
		return e;
	}
	peek() {
		return this.tokens[this.position];
	}
	next() {
		let e = this.tokens[this.position];
		return this.position += 1, e;
	}
	isPunct(e) {
		let t = this.peek();
		return t.kind === "punct" && t.value === e;
	}
	expect(e) {
		let t = this.peek();
		if (t.kind !== "punct" || t.value !== e) throw new b("expression-syntax", `Missing "${e}".`, t.start);
		return this.next();
	}
	node(e, t, n) {
		if (this.nodeCount += 1, this.nodeCount > $e) throw new b("expression-budget", "Expression is too complex.", n);
		if (t > et) throw new b("expression-budget", "Expression is nested too deeply.", n);
		return e;
	}
	parseConditional(e) {
		let t = this.parseOr(e);
		if (!this.isPunct("?")) return t;
		let n = t.start;
		this.next();
		let r = this.parseConditional(e + 1);
		this.expect(":");
		let i = this.parseConditional(e + 1);
		return this.node({
			kind: "conditional",
			test: t,
			consequent: r,
			alternate: i,
			start: n
		}, e, n);
	}
	parseOr(e) {
		let t = this.parseAnd(e);
		for (; this.isPunct("||");) {
			let n = t.start;
			this.next();
			let r = this.parseAnd(e);
			t = this.node({
				kind: "binary",
				operator: "||",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAnd(e) {
		let t = this.parseEquality(e);
		for (; this.isPunct("&&");) {
			let n = t.start;
			this.next();
			let r = this.parseEquality(e);
			t = this.node({
				kind: "binary",
				operator: "&&",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseEquality(e) {
		let t = this.parseRelational(e);
		for (; this.isPunct("==") || this.isPunct("!=");) {
			let n = t.start, r = this.next().value, i = this.parseRelational(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseRelational(e) {
		let t = this.parseAdditive(e);
		for (; this.isPunct("<") || this.isPunct("<=") || this.isPunct(">") || this.isPunct(">=");) {
			let n = t.start, r = this.next().value, i = this.parseAdditive(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAdditive(e) {
		let t = this.parseMultiplicative(e);
		for (; this.isPunct("+") || this.isPunct("-");) {
			let n = t.start, r = this.next().value, i = this.parseMultiplicative(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseMultiplicative(e) {
		let t = this.parseUnary(e);
		for (; this.isPunct("*") || this.isPunct("/") || this.isPunct("%");) {
			let n = t.start, r = this.next().value, i = this.parseUnary(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseUnary(e) {
		let t = this.peek();
		if (t.kind === "punct" && (t.value === "-" || t.value === "+" || t.value === "!")) {
			this.next();
			let n = this.parseUnary(e + 1);
			return this.node({
				kind: "unary",
				operator: t.value,
				operand: n,
				start: t.start
			}, e, t.start);
		}
		return this.parsePrimary(e);
	}
	parsePrimary(e) {
		let t = this.parseAtom(e);
		for (; this.isPunct("[");) {
			let n = t.start;
			this.next();
			let r = this.parseConditional(e + 1);
			this.expect("]"), t = this.node({
				kind: "index",
				target: t,
				index: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAtom(e) {
		let t = this.peek();
		if (t.kind === "number") return this.next(), this.node({
			kind: "literal",
			value: t.number,
			start: t.start
		}, e, t.start);
		if (t.kind === "string") return this.next(), this.node({
			kind: "literal",
			value: t.value,
			start: t.start
		}, e, t.start);
		if (t.kind === "ident") {
			this.next();
			let n = t.value;
			if (this.isPunct("(")) {
				if (!qe.has(n)) throw new b("expression-unknown-function", `Unknown function "${n}".`, t.start);
				this.next();
				let r = [];
				if (!this.isPunct(")")) for (r.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), r.push(this.parseConditional(e + 1));
				this.expect(")");
				let [i, a] = mt[n];
				if (r.length < i || r.length > a) throw new b("expression-arity", `Function ${n} expects ${i === a ? `${i} ${i === 1 ? "argument" : "arguments"}` : i === 1 ? "at least one argument" : `${i}–${a} arguments`}.`, t.start);
				return this.node({
					kind: "call",
					name: n,
					args: r,
					start: t.start
				}, e, t.start);
			}
			if (n === "true" || n === "false") return this.node({
				kind: "literal",
				value: n === "true",
				start: t.start
			}, e, t.start);
			if (n === "null") return this.node({
				kind: "literal",
				value: null,
				start: t.start
			}, e, t.start);
			let r = Je.get(n);
			if (r !== void 0) return this.node({
				kind: "literal",
				value: r,
				start: t.start
			}, e, t.start);
			if (Ye.has(n)) throw new b("expression-forbidden-name", `Name "${n}" is not allowed.`, t.start);
			if (qe.has(n)) throw new b("expression-syntax", `Function ${n} must be called with parentheses.`, t.start);
			return this.dependencySet.has(n) || (this.dependencySet.add(n), this.dependencyNames.push(n)), this.node({
				kind: "reference",
				name: n,
				start: t.start
			}, e, t.start);
		}
		if (t.kind === "punct" && t.value === "(") {
			this.next();
			let t = this.parseConditional(e + 1);
			return this.expect(")"), t;
		}
		if (t.kind === "punct" && t.value === "[") {
			this.next();
			let n = [];
			if (!this.isPunct("]")) for (n.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), n.push(this.parseConditional(e + 1));
			return this.expect("]"), this.node({
				kind: "array",
				elements: n,
				start: t.start
			}, e, t.start);
		}
		throw new b("expression-syntax", "Expected an expression.", t.start);
	}
};
function x(e) {
	switch (e) {
		case "string": return "string";
		case "number": return "number";
		case "boolean": return "boolean";
		case "null": return "null";
		case "array": return "array";
		case "number-array": return "number array";
	}
}
function _t(e) {
	return e === null ? "null" : Array.isArray(e) ? "array" : typeof e == "boolean" ? "boolean" : typeof e == "number" ? "number" : "string";
}
function S(e, t) {
	throw new b("expression-type", e, t);
}
function C(e, t, n, r) {
	e !== t && S(`${r}, got ${x(e)}.`, n);
}
function vt(e, t) {
	return e === t ? e : e === "null" ? t : t === "null" ? e : null;
}
function w(e, t) {
	switch (e.kind) {
		case "literal": return _t(e.value);
		case "reference": {
			if (typeof t != "object" || !t || !Object.prototype.hasOwnProperty.call(t, e.name)) throw new b("expression-unknown-name", `Variable "${e.name}" is not declared.`, e.start);
			let n = t[e.name];
			if (typeof n != "string" || !Xe.has(n)) throw new b("expression-value", `Variable "${e.name}" has an invalid type.`, e.start);
			return n;
		}
		case "unary": {
			let n = w(e.operand, t);
			return e.operator === "!" ? (C(n, "boolean", e.start, "Logical not requires a boolean"), "boolean") : (C(n, "number", e.start, `Unary ${e.operator} requires a number`), "number");
		}
		case "binary": {
			let n = w(e.left, t), r = w(e.right, t);
			switch (e.operator) {
				case "+": return n === "number" && r === "number" ? "number" : n === "string" && r === "string" ? "string" : S(`Operator "+" requires two numbers or two strings, got ${x(n)} and ${x(r)}.`, e.start);
				case "-":
				case "*":
				case "/":
				case "%": return C(n, "number", e.start, `Operator "${e.operator}" requires a number`), C(r, "number", e.start, `Operator "${e.operator}" requires a number`), "number";
				case "<":
				case "<=":
				case ">":
				case ">=": return n === "number" && r === "number" || n === "string" && r === "string" ? "boolean" : S(`Comparison operator "${e.operator}" requires two numbers or two strings, got ${x(n)} and ${x(r)}.`, e.start);
				case "==":
				case "!=": return n !== r && n !== "null" && r !== "null" ? S(`Equality comparison requires matching types, got ${x(n)} and ${x(r)}.`, e.start) : "boolean";
				case "&&":
				case "||": return C(n, "boolean", e.start, "Logical operators require booleans"), C(r, "boolean", e.start, "Logical operators require booleans"), "boolean";
			}
			break;
		}
		case "array": {
			if (e.elements.length === 0) return "number-array";
			let n = null;
			for (let r of e.elements) {
				let e = w(r, t);
				if (e !== "string" && e !== "number") return S(`Array literals require string or number elements, got ${x(e)}.`, r.start);
				if (n === null) n = e;
				else if (n !== e) return S(`Array literals require elements of one type, got ${x(n)} and ${x(e)}.`, r.start);
			}
			return n === "string" ? "array" : "number-array";
		}
		case "index": {
			let n = w(e.target, t);
			return C(w(e.index, t), "number", e.start, "Array index must be a number"), n === "array" ? "string" : n === "number-array" ? "number" : S(`Index access requires an array, got ${x(n)}.`, e.start);
		}
		case "conditional": {
			C(w(e.test, t), "boolean", e.start, "Conditional test must be a boolean");
			let n = w(e.consequent, t), r = w(e.alternate, t);
			if (n === "array" && e.alternate.kind === "array" && e.alternate.elements.length === 0 || r === "array" && e.consequent.kind === "array" && e.consequent.elements.length === 0) return "array";
			let i = vt(n, r);
			return i === null ? S(`Conditional branches must have matching types or one null, got ${x(n)} and ${x(r)}.`, e.start) : i;
		}
		case "call": {
			let n = e.args.map((e) => w(e, t));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": return C(n[0], "number", e.start, `Function ${e.name} requires a number`), "number";
				case "min":
				case "max":
				case "pow":
				case "clamp":
					for (let t of n) C(t, "number", e.start, `Function ${e.name} requires a number`);
					return "number";
				case "len": return n[0] !== "string" && n[0] !== "array" && n[0] !== "number-array" && S(`Function len requires a string or array, got ${x(n[0])}.`, e.start), "number";
				case "contains":
					if (n[0] === "number-array") return C(n[1], "number", e.start, "Function contains requires a numeric member"), "boolean";
					if (n[0] === "string" || n[0] === "array") return C(n[1], "string", e.start, "Function contains requires a string member"), "boolean";
					S(`Function contains requires a string or array, got ${x(n[0])}.`, e.start);
					break;
				case "sum":
				case "average":
				case "minOf":
				case "maxOf": return C(n[0], "number-array", e.start, `Function ${e.name} requires a numeric array`), "number";
				case "formatNumber":
				case "formatPercent":
				case "formatScientific": return n[0] !== "number" && n[0] !== "null" && S(`Function ${e.name} requires a number or null, got ${x(n[0])}.`, e.start), n[1] !== void 0 && C(n[1], "number", e.start, `Function ${e.name} requires numeric fraction digits`), n[2] !== void 0 && C(n[2], "string", e.start, `Function ${e.name} requires a string locale`), e.name === "formatNumber" && n[3] !== void 0 && C(n[3], "boolean", e.start, "Function formatNumber requires a boolean grouping flag"), "string";
				case "formatCurrency": return n[0] !== "number" && n[0] !== "null" && S(`Function formatCurrency requires a number or null, got ${x(n[0])}.`, e.start), n[1] !== void 0 && C(n[1], "string", e.start, "Function formatCurrency requires a string currency code"), n[2] !== void 0 && C(n[2], "number", e.start, "Function formatCurrency requires numeric fraction digits"), n[3] !== void 0 && C(n[3], "string", e.start, "Function formatCurrency requires a string locale"), "string";
				case "trim":
				case "lower":
				case "upper": return C(n[0], "string", e.start, `Function ${e.name} requires a string`), "string";
				case "startsWith":
				case "endsWith": return C(n[0], "string", e.start, `Function ${e.name} requires a string`), C(n[1], "string", e.start, `Function ${e.name} requires a string search value`), "boolean";
				case "replace": return C(n[0], "string", e.start, "Function replace requires a string"), C(n[1], "string", e.start, "Function replace requires a string search value"), C(n[2], "string", e.start, "Function replace requires a string replacement"), "string";
				case "slice": return C(n[0], "string", e.start, "Function slice requires a string"), C(n[1], "number", e.start, "Function slice requires a numeric start index"), n[2] !== void 0 && C(n[2], "number", e.start, "Function slice requires a numeric end index"), "string";
				case "dateCompare": return C(n[0], "string", e.start, "Function dateCompare requires a date string"), C(n[1], "string", e.start, "Function dateCompare requires a date string"), "number";
				case "dateDiff": return C(n[0], "string", e.start, "Function dateDiff requires a date string"), C(n[1], "string", e.start, "Function dateDiff requires a date string"), n[2] !== void 0 && C(n[2], "string", e.start, "Function dateDiff requires a string unit"), "number";
			}
			break;
		}
	}
	throw new b("expression-type", "Unsupported expression.", 0);
}
function T(e, t, n = "expression-eval") {
	throw new b(n, e, t);
}
function yt(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) throw new b("expression-value", "Expression environment must be an object.", 0);
}
function bt(e, t, n) {
	if (e === null) return null;
	if (typeof e == "string") {
		let r = lt(e);
		if (r) throw new b("expression-budget", `Variable "${t}": ${r}`, n);
		return e;
	}
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new b("expression-value", `Variable "${t}" must be a finite number.`, n);
		return e;
	}
	if (Array.isArray(e)) {
		let r = st(e);
		if (r) throw new b(r.code, `Variable "${t}": ${r.message}`, n);
		return e;
	}
	throw new b("expression-value", `Variable "${t}" has an invalid value type.`, n);
}
function xt(e, t, n) {
	return yt(e), Object.prototype.hasOwnProperty.call(e, t) || T(`Variable "${t}" is not declared.`, n, "expression-unknown-name"), bt(e[t], t, n);
}
function E(e, t, n = "Expected a number") {
	return typeof e == "number" && Number.isFinite(e) || T(`${n}.`, t, "expression-type"), e;
}
function St(e, t, n = "Expected a boolean") {
	return typeof e != "boolean" && T(`${n}.`, t, "expression-type"), e;
}
function D(e, t, n = "Expected a string") {
	return typeof e != "string" && T(`${n}.`, t, "expression-type"), e;
}
function Ct(e, t, n) {
	Array.isArray(e) || T(`${n}.`, t, "expression-type");
	for (let r of e) typeof r == "number" && Number.isFinite(r) || T(`${n}.`, t, "expression-type");
	return e;
}
function wt(e, t) {
	let n = st(e);
	return n && T(n.message, t, n.code), e;
}
function O(e, t) {
	try {
		return t();
	} catch (t) {
		throw t instanceof ce ? new b(t.code, t.message, e) : t;
	}
}
function Tt(e, t) {
	return Number.isNaN(e) && T("The result is undefined.", t, "expression-domain"), Number.isFinite(e) || T("The result is not a finite number.", t, "expression-number"), e;
}
function Et(e, t) {
	let n = Array.from(e), r = Array.from(t), i = Math.min(n.length, r.length);
	for (let e = 0; e < i; e += 1) {
		let t = n[e].codePointAt(0), i = r[e].codePointAt(0);
		if (t !== i) return t < i ? -1 : 1;
	}
	return n.length === r.length ? 0 : n.length < r.length ? -1 : 1;
}
function Dt(e, t) {
	if (e === t) return !0;
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return !1;
		for (let n = 0; n < e.length; n += 1) if (e[n] !== t[n]) return !1;
		return !0;
	}
	return !1;
}
function Ot(e, t) {
	return k(e, t, { steps: 0 }, 1);
}
function k(e, t, n, r) {
	switch (n.steps += 1, n.steps > nt && T("Expression evaluation exceeded the step limit.", e.start, "expression-budget"), r > rt && T("Expression evaluation is nested too deeply.", e.start, "expression-budget"), e.kind) {
		case "literal": return e.value;
		case "reference": return xt(t, e.name, e.start);
		case "unary": {
			let i = k(e.operand, t, n, r + 1);
			if (e.operator === "!") return !St(i, e.start, "Logical not requires a boolean");
			let a = E(i, e.start, `Unary ${e.operator} requires a number`);
			return Tt(e.operator === "-" ? -a : a, e.start);
		}
		case "binary": {
			if (e.operator === "&&" || e.operator === "||") {
				let i = St(k(e.left, t, n, r + 1), e.start, "Logical operators require booleans");
				return e.operator === "&&" && !i ? !1 : e.operator === "||" && i ? !0 : St(k(e.right, t, n, r + 1), e.start, "Logical operators require booleans");
			}
			let i = k(e.left, t, n, r + 1), a = k(e.right, t, n, r + 1);
			switch (e.operator) {
				case "+":
					if (typeof i == "number" && typeof a == "number") return Tt(i + a, e.start);
					if (typeof i == "string" && typeof a == "string") {
						let t = i + a;
						return t.length > it && T("String result exceeds the length limit.", e.start, "expression-budget"), t;
					}
					T("Operator \"+\" requires two numbers or two strings.", e.start, "expression-type");
				case "-":
				case "*":
				case "/":
				case "%": {
					let t = E(i, e.start, `Operator "${e.operator}" requires a number`), n = E(a, e.start, `Operator "${e.operator}" requires a number`);
					return (e.operator === "/" || e.operator === "%") && n === 0 && T("Division by zero.", e.start, "expression-divide-by-zero"), Tt(e.operator === "-" ? t - n : e.operator === "*" ? t * n : e.operator === "/" ? t / n : t % n, e.start);
				}
				case "==":
				case "!=": {
					let t = _t(i), n = _t(a);
					t !== n && t !== "null" && n !== "null" && T("Equality comparison requires matching types.", e.start, "expression-type");
					let r = Dt(i, a);
					return e.operator === "==" ? r : !r;
				}
				case "<":
				case "<=":
				case ">":
				case ">=": {
					let t;
					return typeof i == "number" && typeof a == "number" ? t = i === a ? 0 : i < a ? -1 : 1 : typeof i == "string" && typeof a == "string" ? t = Et(i, a) : T(`Comparison operator "${e.operator}" requires two numbers or two strings.`, e.start, "expression-type"), e.operator === "<" ? t < 0 : e.operator === "<=" ? t <= 0 : e.operator === ">" ? t > 0 : t >= 0;
				}
			}
			break;
		}
		case "conditional": return k(St(k(e.test, t, n, r + 1), e.start, "Conditional test must be a boolean") ? e.consequent : e.alternate, t, n, r + 1);
		case "array": {
			let i = [];
			for (let a of e.elements) i.push(k(a, t, n, r + 1));
			return wt(i, e.start);
		}
		case "index": {
			let i = k(e.target, t, n, r + 1), a = E(k(e.index, t, n, r + 1), e.start, "Array index must be a number");
			return Number.isSafeInteger(a) || T("Array index must be a finite integer.", e.start, "expression-index"), Array.isArray(i) || T("Index access requires an array.", e.start, "expression-type"), a < 0 || a >= i.length ? null : i[a];
		}
		case "call": {
			let i = e.args.map((e) => k(e, t, n, r + 1));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": {
					let t = E(i[0], e.start, `Function ${e.name} requires a number`);
					e.name === "sqrt" && t < 0 && T("sqrt requires a non-negative argument.", e.start, "expression-domain"), e.name === "log" && t <= 0 && T("log requires a positive argument.", e.start, "expression-domain"), (e.name === "asin" || e.name === "acos") && (t < -1 || t > 1) && T(`${e.name} requires an argument between -1 and 1.`, e.start, "expression-domain");
					let n;
					switch (e.name) {
						case "abs":
							n = Math.abs(t);
							break;
						case "sqrt":
							n = Math.sqrt(t);
							break;
						case "floor":
							n = Math.floor(t);
							break;
						case "ceil":
							n = Math.ceil(t);
							break;
						case "round":
							n = Math.round(t);
							break;
						case "sin":
							n = Math.sin(t);
							break;
						case "cos":
							n = Math.cos(t);
							break;
						case "tan":
							n = Math.tan(t);
							break;
						case "asin":
							n = Math.asin(t);
							break;
						case "acos":
							n = Math.acos(t);
							break;
						case "atan":
							n = Math.atan(t);
							break;
						case "exp":
							n = Math.exp(t);
							break;
						default: n = Math.log(t);
					}
					return Tt(n, e.start);
				}
				case "min":
				case "max": {
					let t = E(i[0], e.start, `Function ${e.name} requires a number`);
					for (let n = 1; n < i.length; n += 1) {
						let r = E(i[n], e.start, `Function ${e.name} requires a number`);
						t = e.name === "min" ? Math.min(t, r) : Math.max(t, r);
					}
					return Tt(t, e.start);
				}
				case "pow": return Tt(E(i[0], e.start, "Function pow requires a number") ** +E(i[1], e.start, "Function pow requires a number"), e.start);
				case "clamp": {
					let t = E(i[0], e.start, "Function clamp requires a number"), n = E(i[1], e.start, "Function clamp requires a number"), r = E(i[2], e.start, "Function clamp requires a number");
					return n > r && T("clamp lower bound cannot exceed upper bound.", e.start, "expression-domain"), Tt(Math.min(r, Math.max(n, t)), e.start);
				}
				case "len": {
					let t = i[0];
					if (typeof t == "string") return oe(t);
					if (Array.isArray(t)) return t.length;
					T("Function len requires a string or array.", e.start, "expression-type");
				}
				case "contains": {
					let t = i[0], n = i[1];
					if (typeof t == "string") return t.includes(D(n, e.start, "Function contains requires a string member"));
					if (Array.isArray(t)) {
						if (typeof n == "string") {
							for (let n of t) typeof n != "string" && T("Function contains requires a string member for a string array.", e.start, "expression-type");
							return t.includes(n);
						}
						if (typeof n == "number" && Number.isFinite(n)) {
							for (let n of t) typeof n != "number" && T("Function contains requires a numeric member for a numeric array.", e.start, "expression-type");
							return t.includes(n);
						}
						T("Function contains requires a string or numeric member.", e.start, "expression-type");
					}
					T("Function contains requires a string or array.", e.start, "expression-type");
				}
				case "sum": {
					let t = Ct(i[0], e.start, "Function sum requires a numeric array");
					return O(e.start, () => Oe(t));
				}
				case "average": {
					let t = Ct(i[0], e.start, "Function average requires a numeric array");
					return O(e.start, () => ke(t));
				}
				case "minOf": {
					let t = Ct(i[0], e.start, "Function minOf requires a numeric array");
					return O(e.start, () => Ae(t));
				}
				case "maxOf": {
					let t = Ct(i[0], e.start, "Function maxOf requires a numeric array");
					return O(e.start, () => je(t));
				}
				case "formatNumber": {
					let t = i[0] === null ? null : E(i[0], e.start, "Function formatNumber requires a number or null"), n = i[1] === void 0 ? 2 : E(i[1], e.start, "Function formatNumber requires numeric fraction digits"), r = i[2] === void 0 ? "en-US" : D(i[2], e.start, "Function formatNumber requires a string locale"), a = i[3] === void 0 || St(i[3], e.start, "Function formatNumber requires a boolean grouping flag");
					return O(e.start, () => Se(t, n, r, a));
				}
				case "formatPercent": {
					let t = i[0] === null ? null : E(i[0], e.start, "Function formatPercent requires a number or null"), n = i[1] === void 0 ? 0 : E(i[1], e.start, "Function formatPercent requires numeric fraction digits"), r = i[2] === void 0 ? "en-US" : D(i[2], e.start, "Function formatPercent requires a string locale");
					return O(e.start, () => Ce(t, n, r));
				}
				case "formatScientific": {
					let t = i[0] === null ? null : E(i[0], e.start, "Function formatScientific requires a number or null"), n = i[1] === void 0 ? 2 : E(i[1], e.start, "Function formatScientific requires numeric fraction digits"), r = i[2] === void 0 ? "en-US" : D(i[2], e.start, "Function formatScientific requires a string locale");
					return O(e.start, () => we(t, n, r));
				}
				case "formatCurrency": {
					let t = i[0] === null ? null : E(i[0], e.start, "Function formatCurrency requires a number or null"), n = i[1] === void 0 ? "USD" : D(i[1], e.start, "Function formatCurrency requires a string currency code"), r = i[2] === void 0 ? 2 : E(i[2], e.start, "Function formatCurrency requires numeric fraction digits"), a = i[3] === void 0 ? "en-US" : D(i[3], e.start, "Function formatCurrency requires a string locale");
					return O(e.start, () => Te(t, n, r, a));
				}
				case "trim": return O(e.start, () => Ne(D(i[0], e.start, "Function trim requires a string")));
				case "lower": return O(e.start, () => Pe(D(i[0], e.start, "Function lower requires a string")));
				case "upper": return O(e.start, () => Fe(D(i[0], e.start, "Function upper requires a string")));
				case "startsWith": return O(e.start, () => Ie(D(i[0], e.start, "Function startsWith requires a string"), D(i[1], e.start, "Function startsWith requires a string search value")));
				case "endsWith": return O(e.start, () => Le(D(i[0], e.start, "Function endsWith requires a string"), D(i[1], e.start, "Function endsWith requires a string search value")));
				case "replace": {
					let t = D(i[0], e.start, "Function replace requires a string"), n = D(i[1], e.start, "Function replace requires a string search value"), r = D(i[2], e.start, "Function replace requires a string replacement");
					return O(e.start, () => Re(t, n, r));
				}
				case "slice": {
					let t = D(i[0], e.start, "Function slice requires a string"), n = E(i[1], e.start, "Function slice requires a numeric start index"), r = i[2] === void 0 ? void 0 : E(i[2], e.start, "Function slice requires a numeric end index");
					return O(e.start, () => Be(t, n, r));
				}
				case "dateCompare": {
					let t = D(i[0], e.start, "Function dateCompare requires a date string"), n = D(i[1], e.start, "Function dateCompare requires a date string");
					return O(e.start, () => We(t, n));
				}
				case "dateDiff": {
					let t = D(i[0], e.start, "Function dateDiff requires a date string"), n = D(i[1], e.start, "Function dateDiff requires a date string"), r = i[2] === void 0 ? "days" : D(i[2], e.start, "Function dateDiff requires a string unit");
					return O(e.start, () => Ge(t, n, r));
				}
			}
			break;
		}
	}
	throw new b("expression-eval", "Unsupported expression.", 0);
}
var kt = /* @__PURE__ */ new Map();
function At(e) {
	if (typeof e != "string") throw new b("expression-syntax", "Expression must be a string.", 0);
	if (e.length > Qe) throw new b("expression-budget", `Expression exceeds the ${Qe}-character limit.`, 0);
	let t = kt.get(e);
	if (t) return t;
	let n = new gt(e), r = n.parse(), i = [...n.dependencies], a = Object.freeze({
		source: e,
		dependencies: i,
		evaluate(e) {
			return Ot(r, e);
		},
		inferType(e) {
			return w(r, e);
		}
	});
	if (kt.size >= ot) {
		let e = kt.keys().next().value;
		e !== void 0 && kt.delete(e);
	}
	return kt.set(e, a), a;
}
function jt(e) {
	if (e.length > at) throw new b("expression-budget", "Interpolation template exceeds the length limit.", 0);
	let t = [], n = 0;
	for (;;) {
		let r = e.indexOf("{{", n);
		if (r < 0) {
			n < e.length && t.push({
				kind: "text",
				value: e.slice(n)
			});
			break;
		}
		r > n && t.push({
			kind: "text",
			value: e.slice(n, r)
		});
		let i = r + 2, a = "", o = !1;
		for (; i < e.length;) {
			let t = e[i];
			if (a !== "") {
				if (t === "\\") {
					i += 2;
					continue;
				}
				t === a && (a = ""), i += 1;
			} else if (t === "\"" || t === "'") a = t, i += 1;
			else {
				if (t === "{" && e[i + 1] === "{") throw new b("expression-interpolation", "Interpolations cannot be nested.", i);
				if (t === "}" && e[i + 1] === "}") {
					o = !0;
					break;
				}
				i += 1;
			}
		}
		if (!o) throw new b("expression-interpolation", "Interpolation is missing }}.", r);
		let s = e.slice(r + 2, i);
		if (s.trim() === "") throw new b("expression-empty", "Interpolation expression is empty.", r + 2);
		t.push({
			kind: "expression",
			source: s,
			start: r + 2
		}), n = i + 2;
	}
	return t;
}
function Mt(e) {
	try {
		return At(e.source);
	} catch (t) {
		throw t instanceof b ? new b(t.code, t.message, e.start + t.offset) : t;
	}
}
function Nt(e, t, n) {
	try {
		return e.evaluate(t);
	} catch (e) {
		throw e instanceof b ? new b(e.code, e.message, n + e.offset) : e;
	}
}
function Pt(e, t) {
	if (e === null) return "";
	if (typeof e == "string") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new b("expression-value", "Cannot display a non-finite number.", t);
		return String(e);
	}
	if (typeof e == "boolean") return e ? "true" : "false";
	throw Array.isArray(e) ? new b("expression-type", "Cannot insert an array as text; convert it with a function such as len first.", t) : new b("expression-type", "Cannot display this value as text.", t);
}
function Ft(e, t) {
	let n = [], r = 0;
	for (let i of e) {
		let e;
		if (e = i.kind === "text" ? i.value : Pt(Nt(Mt(i), t, i.start), i.start), r += e.length, r > it) throw new b("expression-budget", "Interpolation result exceeds the length limit.", 0);
		n.push(e);
	}
	return n.join("");
}
function It(e, t) {
	if (typeof e != "string") throw new b("expression-interpolation", "Interpolation template must be a string.", 0);
	if (e.length > at) throw new b("expression-budget", `Interpolation template exceeds the ${at}-character limit.`, 0);
	return e.includes("{{") ? Ft(jt(e), t) : e;
}
function Lt(e) {
	if (typeof e != "string") throw new b("expression-interpolation", "Interpolation template must be a string.", 0);
	let t = /* @__PURE__ */ new Set();
	for (let n of jt(e)) if (n.kind === "expression") for (let e of Mt(n).dependencies) t.add(e);
	return [...t];
}
// src/local/component-kernel.ts
function Rt(e, t, n) {
	if (!e) return;
	let r = e, i = e.options ?? [], a = e.constraints ?? (r.min !== void 0 || r.max !== void 0 || r.step !== void 0 ? {
		...r.min === void 0 ? {} : { min: { literal: r.min } },
		...r.max === void 0 ? {} : { max: { literal: r.max } },
		...r.step === void 0 ? {} : { step: { literal: r.step } }
	} : void 0), o = e.family ?? (e.kind === "number" ? "number" : e.kind === "boolean" ? "boolean" : e.kind === "array" ? "multi-select" : i.length ? "choice" : "text");
	return {
		...e,
		family: o,
		bind: e.bind ?? "bind",
		initial: e.initial ?? "initial",
		initialRule: e.initialRule ?? n ?? (t === "value" ? e.kind === "boolean" ? "false" : e.kind === "number" ? "nearest-zero" : "empty" : "nearest-zero"),
		...a ? { constraints: a } : {}
	};
}
function zt(e) {
	let t = e.bindings?.value, n = e.initialRule;
	return Rt(t ?? e.binding, "value", n);
}
function Bt(e) {
	if (e.bindings) {
		let t = [];
		for (let [n, r] of Object.entries(e.bindings)) {
			if (n === "value") continue;
			let e = Rt(r, n);
			e && t.push({
				...e,
				slot: n
			});
		}
		return t;
	}
	return (e.slots ?? []).map((e) => ({
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule ?? "nearest-zero",
		exclusive: e.exclusive,
		slot: e.name
	}));
}
function Vt(e) {
	return e.slotRelations ? e.slotRelations : [];
}
function Ht(e) {
	return e.structure ? e.structure : {
		rule: e.childRule ?? (e.form === "leaf" ? "none" : e.form === "inline" ? "inline" : "any"),
		label: e.label ?? "none",
		...e.parent ? { parents: e.parent } : {}
	};
}
function Ut(e) {
	return e.rules ?? [];
}
function Wt(e, t) {
	for (let n of Ut(e)) if (n.kind === t) return n;
}
function Gt(e, t) {
	return Ut(e).filter((e) => e.kind === t);
}
function Kt(e) {
	return e.legacyHost === !0;
}
function qt(e, t) {
	if (t === e.bind) return e.options, {
		kind: "string",
		static: !0
	};
	switch (e.kind) {
		case "number": return {
			kind: "number",
			static: !0
		};
		case "boolean": return {
			kind: "boolean",
			static: !0
		};
		default: return {
			kind: "string",
			static: !0
		};
	}
}
function Jt(e, t) {
	let n = { ...e.props }, r = t?.bindings ?? e.bindings, i = r?.value ?? e.binding, a = r ? Object.entries(r).filter(([e]) => e !== "value").map(([, e]) => e) : (e.slots ?? []).map((e) => ({
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule ?? "nearest-zero"
	}));
	for (let e of i ? [i] : []) Object.hasOwn(n, e.bind) || (n[e.bind] = qt(e, e.bind)), Object.hasOwn(n, e.initial) || (n[e.initial] = qt(e, e.initial)), Object.hasOwn(n, "disabled") || (n.disabled = {
		kind: "boolean",
		dynamic: !0,
		default: !1
	});
	for (let e of a) Object.hasOwn(n, e.bind) || (n[e.bind] = qt(e, e.bind)), Object.hasOwn(n, e.initial) || (n[e.initial] = qt(e, e.initial));
	return {
		...e,
		props: n,
		...t?.structure ?? e.structure ? { structure: t?.structure ?? e.structure } : {},
		...t?.rules ?? e.rules ? { rules: t?.rules ?? e.rules } : {},
		...r ? { bindings: r } : {},
		...t?.slotRelations ?? e.slotRelations ? { slotRelations: t?.slotRelations ?? e.slotRelations } : {},
		...t?.legacyHost === !0 || e.legacyHost === !0 ? { legacyHost: !0 } : {}
	};
}
function A(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "number" ? r.value : void 0;
	let i = e.props[n]?.default;
	return typeof i == "number" ? i : void 0;
}
function Yt(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "string" ? r.value : void 0;
	let i = e.props[n]?.default;
	return typeof i == "string" ? i : void 0;
}
function Xt(e, t, n) {
	return n === void 0 ? t : e[n]?.offset ?? t;
}
function Zt(e, t, n) {
	let r = [], i = e.name, a = i, o = (e, t, n, i, a) => {
		r.push({
			code: e,
			message: t,
			start: n,
			key: i,
			...a ? { params: a } : {}
		});
	};
	for (let r of Ut(e)) switch (r.kind) {
		case "numeric-range": {
			let s = A(e, t, r.min), c = A(e, t, r.max);
			s !== void 0 && c !== void 0 && (r.order === "increasing" ? !(s < c) : s > c) && o("local.constraint", r.order === "increasing" ? `${i} ${r.min ?? "min"} must be less than ${r.max ?? "max"}.` : `Component <${i}> min cannot exceed max.`, Xt(t, n.start, r.min), r.order === "increasing" ? "local.constraint.plot-range" : "local.constraint.number-min-max", r.order === "increasing" ? void 0 : { component: a });
			let l = A(e, t, r.step);
			l === void 0 || l > 0 && Number.isFinite(l) || o("local.constraint", `Component <${i}> step must be greater than 0.`, Xt(t, n.start, r.step), "local.constraint.number-step", { component: a });
			let u = r.integer;
			if (u !== void 0) {
				let r = A(e, t, u);
				r !== void 0 && !Number.isInteger(r) && o("local.constraint", `Attribute ${u} must be a whole number.`, Xt(t, n.start, u), "local.constraint.integer", {
					name: u,
					component: a
				});
			}
			if (r.positiveInteger !== void 0) {
				let i = A(e, t, r.positiveInteger);
				i !== void 0 && (!Number.isInteger(i) || i <= 0) && o("local.constraint", `Attribute ${r.positiveInteger} must be a positive whole number.`, Xt(t, n.start, r.positiveInteger), "local.constraint.positive-integer", {
					name: r.positiveInteger,
					component: a
				});
			}
			break;
		}
		case "text-length": {
			let i = A(e, t, r.min) ?? 0, a = A(e, t, r.max);
			a !== void 0 && a < i && o("local.constraint", "max-length cannot be less than min-length.", Xt(t, n.start, r.max), "local.constraint.length-order");
			break;
		}
		case "date-bounds": {
			let i = Yt(e, t, r.min), a = Yt(e, t, r.max);
			i !== void 0 && !$t(i) && o("local.attribute.type", `Date lower bound ${i} is not a valid YYYY-MM-DD.`, Xt(t, n.start, r.min), "local.attribute.type.date-lower", { value: i }), a !== void 0 && !$t(a) && o("local.attribute.type", `Date upper bound ${a} is not a valid YYYY-MM-DD.`, Xt(t, n.start, r.max), "local.attribute.type.date-upper", { value: a }), i && a && i > a && o("local.constraint", "Date min cannot be later than max.", Xt(t, n.start, r.min), "local.constraint.date-order");
			break;
		}
		case "nonempty": {
			let e = t[r.attribute];
			if (!e || e.dynamic) break;
			(typeof e.value == "string" ? e.value : String(e.raw ?? "")).trim() || o("local.constraint", `Attribute ${r.attribute} of <${i}> cannot be empty.`, e.offset, `local.constraint.${i}-${r.attribute}`, {
				name: r.attribute,
				component: a
			});
			break;
		}
		case "progress-bounds": {
			let n = A(e, t, r.max) ?? r.defaultMax, i = t[r.value];
			i && !i.dynamic && typeof i.value == "number" && (i.value < 0 || i.value > n) && o("local.constraint", `progress value must be between 0 and ${n}, got ${i.value}.`, i.offset, "local.constraint.progress-range", {
				max: n,
				value: i.value
			});
			break;
		}
		case "timer-duration": {
			let i = A(e, t, r.attribute) ?? r.default;
			(!Number.isInteger(i) || i <= 0) && o("local.constraint", "timer duration must be a positive whole number of seconds.", Xt(t, n.start, r.attribute), "local.constraint.timer-duration");
			break;
		}
		case "option-count": {
			let a = A(e, t, r.max);
			a !== void 0 && (!Number.isInteger(a) || a < 0) && o("local.constraint", `${i} ${r.max} must be a nonnegative whole number.`, Xt(t, n.start, r.max), `local.constraint.${i}`);
			break;
		}
		case "selection-requires":
			if (Object.hasOwn(t, r.key)) break;
			for (let e of r.attributes) {
				let n = t[e];
				n && o("local.selection.key", `<${i}> ${e} requires a key attribute naming the selection column.`, n.offset, "local.selection.key.required", {
					component: a,
					name: e
				});
			}
	}
	return r;
}
var Qt = /^(\d{4})-(\d{2})-(\d{2})$/;
function $t(e) {
	if (e === "") return !0;
	let t = Qt.exec(e);
	if (!t) return !1;
	let n = Number(t[1]), r = Number(t[2]), i = Number(t[3]);
	return n < 1 || r < 1 || r > 12 || i < 1 ? !1 : i <= [
		31,
		n % 4 == 0 && n % 100 != 0 || n % 400 == 0 ? 29 : 28,
		31,
		30,
		31,
		30,
		31,
		31,
		30,
		31,
		30,
		31
	][r - 1];
}
function en(e, t, n) {
	if (n === void 0) return;
	if ("literal" in n) return n.literal;
	let r = t[n.prop];
	if (r) return r.dynamic ? void 0 : typeof r.value == "number" ? r.value : void 0;
	let i = e.props[n.prop]?.default;
	return typeof i == "number" ? i : void 0;
}
function tn(e, t, n) {
	let r = t.constraints;
	if (!r) return { step: 1 };
	let i = en(e, n, r.min), a = en(e, n, r.max), o = en(e, n, r.step) ?? 1, s = (e) => {
		if (e === void 0 || !("prop" in e)) return;
		let t = n[e.prop];
		return t?.dynamic ? (t.expression ?? "").trim() : void 0;
	}, c = s(r.min), l = s(r.max);
	return {
		...i === void 0 ? {} : { min: i },
		...a === void 0 ? {} : { max: a },
		step: o > 0 ? o : 1,
		...c === void 0 ? {} : { dynamicMin: c },
		...l === void 0 ? {} : { dynamicMax: l }
	};
}
function nn(e, t, n) {
	return en(e, n, t.maxItems);
}
function rn(e, t, n) {
	let r = n === "min" ? e.dynamicMin : e.dynamicMax, i = n === "min" ? t.dynamicMin : t.dynamicMax;
	return r !== void 0 || i !== void 0 ? r === i : e[n] === t[n];
}
function an(e) {
	return `[${e.dynamicMin === void 0 ? e.min === void 0 ? "-∞" : String(e.min) : `{{ ${e.dynamicMin} }}`}, ${e.dynamicMax === void 0 ? e.max === void 0 ? "∞" : String(e.max) : `{{ ${e.dynamicMax} }}`}] / ${e.step}`;
}
function on(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= 1e-9 * Math.max(1, Math.abs(r));
}
function sn(e, t, n) {
	let r = e ?? 0, i = e === void 0 ? -Infinity : Math.ceil((e - r) / n), a = t === void 0 ? Infinity : Math.floor((t - r) / n);
	if (i > a) return null;
	let o = -r / n, s = null;
	for (let e of [Math.floor(o), Math.ceil(o)]) {
		let t = Math.min(a, Math.max(i, e));
		if (!Number.isFinite(t)) continue;
		if (s === null) {
			s = t;
			continue;
		}
		let o = r + t * n, c = r + s * n;
		(Math.abs(o) < Math.abs(c) || Math.abs(o) === Math.abs(c) && o < c) && (s = t);
	}
	if (s === null) return null;
	let c = r + s * n;
	return e !== void 0 && c < e || t !== void 0 && c > t ? null : c;
}
function cn(e, t, n) {
	switch (e) {
		case "empty": return { value: "" };
		case "false": return { value: !1 };
		case "min": return { value: t?.min ?? 0 };
		case "nearest-zero": {
			let e = t ?? { step: 1 }, n = sn(e.min, e.max, e.step);
			return n === null ? { error: "no-step" } : { value: n };
		}
		case "duration": return { value: t?.max ?? 60 };
		case "first-option":
		case "first-tab":
		case "first-step":
		case "first-node": return { value: n[0] ?? "" };
		case "checked": return { value: [] };
		case "empty-array": return { value: [] };
		case "max-step": {
			let e = t ?? { step: 1 }, n = e.min ?? 0, r = (e.max ?? n) - n, i = n + Math.max(0, Math.floor(r / e.step + 1e-9)) * e.step;
			return { value: Math.min(e.max ?? i, Math.max(e.min ?? i, i)) };
		}
		case "none": return { value: "" };
		default: return { error: "cannot-derive" };
	}
}
function ln(e) {
	switch (e) {
		case "choice":
		case "multi-select": return "options";
		case "tabs": return "tabs";
		case "steps": return "steps";
		case "selection": return "selection";
		case "diagram": return "diagram-nodes";
		case "checklist": return "checklist";
		default: return;
	}
}
function un(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) r !== void 0 && (t[n] = r);
	return t;
}
function dn(e) {
	let t = [];
	for (let n of Ut(e)) switch (n.kind) {
		case "value-date":
			t.push(un({
				kind: "date",
				min: n.min,
				max: n.max,
				required: n.required
			}));
			break;
		case "value-length":
			t.push(un({
				kind: "length",
				min: n.min,
				max: n.max
			})), (n.email !== void 0 || n.emailType !== void 0) && t.push(un({
				kind: "email",
				type: n.email ?? "type",
				value: n.emailType ?? "email"
			}));
			break;
		case "value-email":
			t.push(un({
				kind: "email",
				type: n.type ?? "type",
				value: n.value ?? "email"
			}));
			break;
		case "value-required": t.push({
			kind: "required",
			required: n.required
		});
	}
	return t;
}
function fn(e) {
	if (!e || typeof e != "object") return;
	let t = e.kernel;
	if (t && typeof t == "object") return t;
}
var pn = /^[A-Za-z_][A-Za-z0-9_-]*$/;
function mn(e) {
	return pn.test(e);
}
function hn(e, t, n) {
	let r = [];
	for (let i of e) {
		let e = i.target;
		e ? e.startsWith("#") || /\s/.test(e) ? r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" must be a bare heading slug or anchor id without "#" or whitespace.`,
			start: i.offset,
			key: "local.jump.bad-target",
			params: { target: e }
		}) : !t.has(e) && !n.has(e) && r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" does not resolve to a heading or explicit anchor in this document.`,
			start: i.offset,
			key: "local.jump.unresolved",
			params: { target: e }
		}) : r.push({
			code: "local.jump.target",
			message: "<jump> target cannot be empty.",
			start: i.offset,
			key: "local.jump.empty"
		});
	}
	return r;
}
Object.freeze({
	arrayLength: f,
	dataTableColumns: 20,
	plotCurves: 16,
	plotPoints: p
});
// src/local/node-walk.ts
function* gn(e, t = !1) {
	let n = [{
		nodes: e,
		index: 0
	}];
	for (; n.length;) {
		let e = n[n.length - 1];
		if (e.index === e.nodes.length) {
			n.pop(), t && e.owner && (yield e.owner);
			continue;
		}
		let r = e.nodes[e.index++];
		t || (yield r), r.children?.length ? n.push({
			nodes: r.children,
			index: 0,
			owner: r
		}) : t && (yield r);
	}
}
// src/local/computations.ts
function _n(e, t, n, r = "local.expression") {
	t instanceof b ? e(`${r}.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0)) : e(`${r}.invalid`, `Expression error: ${t instanceof Error ? t.message : String(t)}`, n);
}
function vn(e) {
	return e instanceof b ? e : new b("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function yn(e, t) {
	let n = new Set(e), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let t of e) r.set(t, 0);
	for (let a of e) for (let e of t(a)) {
		if (!n.has(e)) continue;
		r.set(a, (r.get(a) ?? 0) + 1);
		let t = i.get(e);
		t ? t.push(a) : i.set(e, [a]);
	}
	let a = [];
	for (let t of e) (r.get(t) ?? 0) === 0 && a.push(t);
	let o = [];
	for (let e = 0; e < a.length; e += 1) {
		let t = a[e];
		o.push(t);
		for (let e of i.get(t) ?? []) {
			let t = (r.get(e) ?? 0) - 1;
			r.set(e, t), t === 0 && a.push(e);
		}
	}
	let s = new Set(o);
	return {
		order: o,
		cyclic: e.filter((e) => !s.has(e))
	};
}
function bn(e) {
	let t = Object.keys(e), n = new Set(t);
	return yn(t, (t) => {
		let r = e[t];
		return r ? r.dependencies.filter((e) => n.has(e)) : [];
	});
}
function xn(e, t, n, r = /* @__PURE__ */ new Set(), i) {
	let a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = [], l = /* @__PURE__ */ new Set();
	for (let t of e) s.has(t.name) || (s.set(t.name, t), c.push(t.name));
	let u = new Set(c);
	for (let e of c) {
		let t = s.get(e), r;
		try {
			r = i?.expression(t.source) ?? At(t.source);
		} catch (r) {
			_n(n, r, t.expressionOffset), l.add(e);
			continue;
		}
		a.set(e, r), o.set(e, [...r.dependencies]);
	}
	for (let e of c) if (!l.has(e)) {
		for (let r of o.get(e) ?? []) if (!(u.has(r) || Object.hasOwn(t, r))) {
			n("local.computation.unknown", `Reference to undeclared parameter ${r} in computation "${e}".`, s.get(e).expressionOffset + Math.max(0, s.get(e).source.indexOf(r))), l.add(e);
			break;
		}
	}
	let d = /* @__PURE__ */ new Set();
	for (let e of c) {
		if (l.has(e)) continue;
		let i = s.get(e);
		if (i.kind === "const") for (let a of o.get(e) ?? []) {
			let o = u.has(a) ? s.get(a).kind : null;
			Object.hasOwn(t, a) ? (n("local.computation.const", `Constant "${e}" cannot depend on ${r.has(a) ? "external data" : "control parameter"} "${a}".`, i.expressionOffset + Math.max(0, i.source.indexOf(a))), d.add(e)) : o === "computed" && (n("local.computation.const", `Constant "${e}" cannot depend on computed value "${a}".`, i.expressionOffset + Math.max(0, i.source.indexOf(a))), d.add(e));
		}
	}
	let { order: f, cyclic: p } = yn(c, (e) => o.get(e) ?? []);
	if (p.length > 0) {
		let e = new Set(p), t = [], r = /* @__PURE__ */ new Map(), i = p[0];
		for (; !r.has(i);) {
			r.set(i, t.length), t.push(i);
			let n = (o.get(i) ?? []).find((t) => e.has(t));
			if (n === void 0) break;
			i = n;
		}
		let a = r.has(i) ? t.slice(r.get(i)) : [p[0]], c = a.slice(0, 12).join(" → ") + (a.length > 12 ? " → …" : ` → ${a[0]}`);
		for (let e of a.slice(0, 100)) {
			let t = s.get(e);
			n("local.computation.cycle", `Computation "${e}" is part of a dependency cycle: ${c}.`, t.range.start, t.range.end);
		}
		for (let e of p) l.add(e);
	}
	for (let e of f) if (!l.has(e) && !(s.get(e).kind !== "const" || d.has(e)) && (o.get(e) ?? []).some((e) => u.has(e) ? s.get(e).kind === "const" && d.has(e) : !1)) {
		let t = s.get(e);
		n("local.computation.const", `Constant "${e}" indirectly depends on a value that is not a constant.`, t.expressionOffset), d.add(e);
	}
	let m = {}, ee = { ...t };
	for (let e of f) {
		if (l.has(e)) continue;
		let t = s.get(e);
		if ((o.get(e) ?? []).some((e) => l.has(e))) {
			l.add(e);
			continue;
		}
		let r = a.get(e);
		try {
			let t = i ? i.infer(r, ee) : r.inferType(ee);
			m[e] = t, ee[e] = t;
		} catch (r) {
			_n(n, r, t.expressionOffset), l.add(e);
		}
	}
	let h = {}, g = {};
	for (let e of f) {
		if (l.has(e) || s.get(e).kind !== "const" || d.has(e)) continue;
		let t = s.get(e), r = a.get(e);
		try {
			let i = r.evaluate(g), a = lt(i);
			if (a) {
				n("local.computation.budget", `Constant "${e}": ${a}`, t.expressionOffset), l.add(e);
				continue;
			}
			h[e] = Array.isArray(i) ? i.slice() : i, g[e] = h[e];
		} catch (r) {
			let i = vn(r);
			n("local.computation.expression", `Constant "${e}" cannot be evaluated: ${i.message}`, t.expressionOffset + (Number.isFinite(i.offset) ? i.offset : 0)), l.add(e);
		}
	}
	let _ = {};
	for (let e of c) {
		let t = s.get(e);
		if (l.has(e) || m[e] === void 0) continue;
		let n = {
			name: e,
			kind: t.kind,
			source: t.source,
			dependencies: [...o.get(e) ?? []],
			type: m[e],
			nodeId: t.nodeId,
			range: { ...t.range }
		};
		t.kind === "const" && Object.hasOwn(h, e) && (n.value = h[e]), _[e] = n;
	}
	return {
		computations: _,
		kinds: m,
		order: f.filter((e) => !l.has(e)),
		expressions: a,
		constValues: h
	};
}
function Sn(e, t, n, r, i, a = /* @__PURE__ */ new Map()) {
	let o = {}, s = /* @__PURE__ */ new Map(), c = {};
	for (let [e, t] of Object.entries(r)) c[e] = t;
	for (let [e, t] of a) Object.defineProperty(c, e, {
		enumerable: !0,
		configurable: !0,
		get() {
			throw t;
		}
	});
	for (let [e, t] of Object.entries(i)) o[e] = t, c[e] = t;
	for (let r of t) {
		let t = e[r];
		if (!t || t.kind === "const") continue;
		let i = n.get(r);
		if (i) try {
			let e = i.evaluate(c), t = lt(e);
			if (t) throw new b("expression-budget", t, 0);
			o[r] = e, c[r] = e;
		} catch (e) {
			let t = vn(e);
			s.set(r, t), Object.defineProperty(c, r, {
				enumerable: !0,
				configurable: !0,
				get() {
					throw t;
				}
			});
		}
	}
	return {
		values: o,
		errors: s
	};
}
// node_modules/parse5/dist/common/unicode.js
var Cn = /* @__PURE__ */ new Set([
	65534,
	65535,
	131070,
	131071,
	196606,
	196607,
	262142,
	262143,
	327678,
	327679,
	393214,
	393215,
	458750,
	458751,
	524286,
	524287,
	589822,
	589823,
	655358,
	655359,
	720894,
	720895,
	786430,
	786431,
	851966,
	851967,
	917502,
	917503,
	983038,
	983039,
	1048574,
	1048575,
	1114110,
	1114111
]), j;
(function(e) {
	e[e.EOF = -1] = "EOF", e[e.NULL = 0] = "NULL", e[e.TABULATION = 9] = "TABULATION", e[e.CARRIAGE_RETURN = 13] = "CARRIAGE_RETURN", e[e.LINE_FEED = 10] = "LINE_FEED", e[e.FORM_FEED = 12] = "FORM_FEED", e[e.SPACE = 32] = "SPACE", e[e.EXCLAMATION_MARK = 33] = "EXCLAMATION_MARK", e[e.QUOTATION_MARK = 34] = "QUOTATION_MARK", e[e.AMPERSAND = 38] = "AMPERSAND", e[e.APOSTROPHE = 39] = "APOSTROPHE", e[e.HYPHEN_MINUS = 45] = "HYPHEN_MINUS", e[e.SOLIDUS = 47] = "SOLIDUS", e[e.DIGIT_0 = 48] = "DIGIT_0", e[e.DIGIT_9 = 57] = "DIGIT_9", e[e.SEMICOLON = 59] = "SEMICOLON", e[e.LESS_THAN_SIGN = 60] = "LESS_THAN_SIGN", e[e.EQUALS_SIGN = 61] = "EQUALS_SIGN", e[e.GREATER_THAN_SIGN = 62] = "GREATER_THAN_SIGN", e[e.QUESTION_MARK = 63] = "QUESTION_MARK", e[e.LATIN_CAPITAL_A = 65] = "LATIN_CAPITAL_A", e[e.LATIN_CAPITAL_Z = 90] = "LATIN_CAPITAL_Z", e[e.RIGHT_SQUARE_BRACKET = 93] = "RIGHT_SQUARE_BRACKET", e[e.GRAVE_ACCENT = 96] = "GRAVE_ACCENT", e[e.LATIN_SMALL_A = 97] = "LATIN_SMALL_A", e[e.LATIN_SMALL_Z = 122] = "LATIN_SMALL_Z";
})(j ||= {});
var M = {
	DASH_DASH: "--",
	CDATA_START: "[CDATA[",
	DOCTYPE: "doctype",
	SCRIPT: "script",
	PUBLIC: "public",
	SYSTEM: "system"
};
function wn(e) {
	return e >= 55296 && e <= 57343;
}
function Tn(e) {
	return e >= 56320 && e <= 57343;
}
function En(e, t) {
	return (e - 55296) * 1024 + 9216 + t;
}
function Dn(e) {
	return e !== 32 && e !== 10 && e !== 13 && e !== 9 && e !== 12 && e >= 1 && e <= 31 || e >= 127 && e <= 159;
}
function On(e) {
	return e >= 64976 && e <= 65007 || Cn.has(e);
}
// node_modules/parse5/dist/common/error-codes.js
var N;
(function(e) {
	e.controlCharacterInInputStream = "control-character-in-input-stream", e.noncharacterInInputStream = "noncharacter-in-input-stream", e.surrogateInInputStream = "surrogate-in-input-stream", e.nonVoidHtmlElementStartTagWithTrailingSolidus = "non-void-html-element-start-tag-with-trailing-solidus", e.endTagWithAttributes = "end-tag-with-attributes", e.endTagWithTrailingSolidus = "end-tag-with-trailing-solidus", e.unexpectedSolidusInTag = "unexpected-solidus-in-tag", e.unexpectedNullCharacter = "unexpected-null-character", e.unexpectedQuestionMarkInsteadOfTagName = "unexpected-question-mark-instead-of-tag-name", e.invalidFirstCharacterOfTagName = "invalid-first-character-of-tag-name", e.unexpectedEqualsSignBeforeAttributeName = "unexpected-equals-sign-before-attribute-name", e.missingEndTagName = "missing-end-tag-name", e.unexpectedCharacterInAttributeName = "unexpected-character-in-attribute-name", e.unknownNamedCharacterReference = "unknown-named-character-reference", e.missingSemicolonAfterCharacterReference = "missing-semicolon-after-character-reference", e.unexpectedCharacterAfterDoctypeSystemIdentifier = "unexpected-character-after-doctype-system-identifier", e.unexpectedCharacterInUnquotedAttributeValue = "unexpected-character-in-unquoted-attribute-value", e.eofBeforeTagName = "eof-before-tag-name", e.eofInTag = "eof-in-tag", e.missingAttributeValue = "missing-attribute-value", e.missingWhitespaceBetweenAttributes = "missing-whitespace-between-attributes", e.missingWhitespaceAfterDoctypePublicKeyword = "missing-whitespace-after-doctype-public-keyword", e.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers = "missing-whitespace-between-doctype-public-and-system-identifiers", e.missingWhitespaceAfterDoctypeSystemKeyword = "missing-whitespace-after-doctype-system-keyword", e.missingQuoteBeforeDoctypePublicIdentifier = "missing-quote-before-doctype-public-identifier", e.missingQuoteBeforeDoctypeSystemIdentifier = "missing-quote-before-doctype-system-identifier", e.missingDoctypePublicIdentifier = "missing-doctype-public-identifier", e.missingDoctypeSystemIdentifier = "missing-doctype-system-identifier", e.abruptDoctypePublicIdentifier = "abrupt-doctype-public-identifier", e.abruptDoctypeSystemIdentifier = "abrupt-doctype-system-identifier", e.cdataInHtmlContent = "cdata-in-html-content", e.incorrectlyOpenedComment = "incorrectly-opened-comment", e.eofInScriptHtmlCommentLikeText = "eof-in-script-html-comment-like-text", e.eofInDoctype = "eof-in-doctype", e.nestedComment = "nested-comment", e.abruptClosingOfEmptyComment = "abrupt-closing-of-empty-comment", e.eofInComment = "eof-in-comment", e.incorrectlyClosedComment = "incorrectly-closed-comment", e.eofInCdata = "eof-in-cdata", e.absenceOfDigitsInNumericCharacterReference = "absence-of-digits-in-numeric-character-reference", e.nullCharacterReference = "null-character-reference", e.surrogateCharacterReference = "surrogate-character-reference", e.characterReferenceOutsideUnicodeRange = "character-reference-outside-unicode-range", e.controlCharacterReference = "control-character-reference", e.noncharacterCharacterReference = "noncharacter-character-reference", e.missingWhitespaceBeforeDoctypeName = "missing-whitespace-before-doctype-name", e.missingDoctypeName = "missing-doctype-name", e.invalidCharacterSequenceAfterDoctypeName = "invalid-character-sequence-after-doctype-name", e.duplicateAttribute = "duplicate-attribute", e.nonConformingDoctype = "non-conforming-doctype", e.missingDoctype = "missing-doctype", e.misplacedDoctype = "misplaced-doctype", e.endTagWithoutMatchingOpenElement = "end-tag-without-matching-open-element", e.closingOfElementWithOpenChildElements = "closing-of-element-with-open-child-elements", e.disallowedContentInNoscriptInHead = "disallowed-content-in-noscript-in-head", e.openElementsLeftAfterEof = "open-elements-left-after-eof", e.abandonedHeadElementChild = "abandoned-head-element-child", e.misplacedStartTagForHeadElement = "misplaced-start-tag-for-head-element", e.nestedNoscriptInHead = "nested-noscript-in-head", e.eofInElementThatCanContainOnlyText = "eof-in-element-that-can-contain-only-text";
})(N ||= {});
// node_modules/parse5/dist/tokenizer/preprocessor.js
var kn = 65536, An = class {
	constructor(e) {
		this.handler = e, this.html = "", this.pos = -1, this.lastGapPos = -2, this.gapStack = [], this.skipNextNewLine = !1, this.lastChunkWritten = !1, this.endOfChunkHit = !1, this.bufferWaterline = kn, this.isEol = !1, this.lineStartPos = 0, this.droppedBufferSize = 0, this.line = 1, this.lastErrOffset = -1;
	}
	get col() {
		return this.pos - this.lineStartPos + Number(this.lastGapPos !== this.pos);
	}
	get offset() {
		return this.droppedBufferSize + this.pos;
	}
	getError(e, t) {
		let { line: n, col: r, offset: i } = this, a = r + t, o = i + t;
		return {
			code: e,
			startLine: n,
			endLine: n,
			startCol: a,
			endCol: a,
			startOffset: o,
			endOffset: o
		};
	}
	_err(e) {
		this.handler.onParseError && this.lastErrOffset !== this.offset && (this.lastErrOffset = this.offset, this.handler.onParseError(this.getError(e, 0)));
	}
	_addGap() {
		this.gapStack.push(this.lastGapPos), this.lastGapPos = this.pos;
	}
	_processSurrogate(e) {
		if (this.pos !== this.html.length - 1) {
			let t = this.html.charCodeAt(this.pos + 1);
			if (Tn(t)) return this.pos++, this._addGap(), En(e, t);
		} else if (!this.lastChunkWritten) return this.endOfChunkHit = !0, j.EOF;
		return this._err(N.surrogateInInputStream), e;
	}
	willDropParsedChunk() {
		return this.pos > this.bufferWaterline;
	}
	dropParsedChunk() {
		this.willDropParsedChunk() && (this.html = this.html.substring(this.pos), this.lineStartPos -= this.pos, this.droppedBufferSize += this.pos, this.pos = 0, this.lastGapPos = -2, this.gapStack.length = 0);
	}
	write(e, t) {
		this.html.length > 0 ? this.html += e : this.html = e, this.endOfChunkHit = !1, this.lastChunkWritten = t;
	}
	insertHtmlAtCurrentPos(e) {
		this.html = this.html.substring(0, this.pos + 1) + e + this.html.substring(this.pos + 1), this.endOfChunkHit = !1;
	}
	startsWith(e, t) {
		if (this.pos + e.length > this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, !1;
		if (t) return this.html.startsWith(e, this.pos);
		for (let t = 0; t < e.length; t++) if ((this.html.charCodeAt(this.pos + t) | 32) !== e.charCodeAt(t)) return !1;
		return !0;
	}
	peek(e) {
		let t = this.pos + e;
		if (t >= this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, j.EOF;
		let n = this.html.charCodeAt(t);
		return n === j.CARRIAGE_RETURN ? j.LINE_FEED : n;
	}
	advance() {
		if (this.pos++, this.isEol && (this.isEol = !1, this.line++, this.lineStartPos = this.pos), this.pos >= this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, j.EOF;
		let e = this.html.charCodeAt(this.pos);
		return e === j.CARRIAGE_RETURN ? (this.isEol = !0, this.skipNextNewLine = !0, j.LINE_FEED) : e === j.LINE_FEED && (this.isEol = !0, this.skipNextNewLine) ? (this.line--, this.skipNextNewLine = !1, this._addGap(), this.advance()) : (this.skipNextNewLine = !1, wn(e) && (e = this._processSurrogate(e)), this.handler.onParseError === null || e > 31 && e < 127 || e === j.LINE_FEED || e === j.CARRIAGE_RETURN || e > 159 && e < 64976 || this._checkForProblematicCharacters(e), e);
	}
	_checkForProblematicCharacters(e) {
		Dn(e) ? this._err(N.controlCharacterInInputStream) : On(e) && this._err(N.noncharacterInInputStream);
	}
	retreat(e) {
		for (this.pos -= e; this.pos < this.lastGapPos;) this.lastGapPos = this.gapStack.pop(), this.pos--;
		this.isEol = !1;
	}
}, P;
(function(e) {
	e[e.CHARACTER = 0] = "CHARACTER", e[e.NULL_CHARACTER = 1] = "NULL_CHARACTER", e[e.WHITESPACE_CHARACTER = 2] = "WHITESPACE_CHARACTER", e[e.START_TAG = 3] = "START_TAG", e[e.END_TAG = 4] = "END_TAG", e[e.COMMENT = 5] = "COMMENT", e[e.DOCTYPE = 6] = "DOCTYPE", e[e.EOF = 7] = "EOF", e[e.HIBERNATION = 8] = "HIBERNATION";
})(P ||= {});
function jn(e, t) {
	for (let n = e.attrs.length - 1; n >= 0; n--) if (e.attrs[n].name === t) return e.attrs[n].value;
	return null;
}
// node_modules/entities/dist/decode-codepoint.js
var Mn = [
	8364,
	0,
	8218,
	402,
	8222,
	8230,
	8224,
	8225,
	710,
	8240,
	352,
	8249,
	338,
	0,
	381,
	0,
	0,
	8216,
	8217,
	8220,
	8221,
	8226,
	8211,
	8212,
	732,
	8482,
	353,
	8250,
	339,
	0,
	382,
	376
];
function Nn(e) {
	return e === 0 || e >= 55296 && e <= 57343 || e > 1114111;
}
function Pn(e) {
	return Nn(e) ? 65533 : e >= 128 && e <= 159 && Mn[e - 128] || e;
}
function Fn(e) {
	return Nn(e) ? 65533 : e;
}
// node_modules/entities/dist/internal/decode-shared.js
var F = /* #__PURE__ */ (() => {
	let e = /* @__PURE__ */ new Uint8Array(127), t = 0;
	for (let n = 33; n <= 126; n++) n !== 34 && n !== 36 && n !== 92 && (e[n] = t++);
	return e;
})();
function In(e, t, n, r, i, a) {
	let o = e.length, s = a * 90, c = 0, l = () => {
		let t = F[e.charCodeAt(c++)];
		return t < a ? t : t * 91 - s + F[e.charCodeAt(c++)];
	}, u = n - r, d = n + i, f = new Int32Array(d);
	f.fill(-1, r, a), f.fill(-1, a + u, d);
	let p = new Int32Array(d), m = new Int32Array(d);
	function ee(t, n) {
		let r = 0, i = n, a = n + t;
		for (; i < a;) {
			let t = F[e.charCodeAt(c++)];
			if (t < 89) r += t, f[i++] = r;
			else if (t === 89) {
				let t = F[e.charCodeAt(c++)] + 2;
				for (; t--;) f[i++] = ++r;
			} else {
				let t = F[e.charCodeAt(c++)];
				r += 89 + (t < 90 ? t * 91 + F[e.charCodeAt(c++)] : F[e.charCodeAt(c++)] * 8281 + F[e.charCodeAt(c++)] * 91 + F[e.charCodeAt(c++)]), f[i++] = r;
			}
		}
	}
	ee(r, 0), ee(u, a);
	let h = new Int32Array(i * 2), g = 0, _ = 0;
	function te(e, t) {
		for (let n = 0; n < e; n++) {
			let e = t + n, r = l(), i = l();
			h[_ * 2] = r, h[_ * 2 + 1] = i, _ += 1, p[e] = g;
			let a = (f[r] < 0 ? m[r] : 1) + (f[i] < 0 ? m[i] : 1);
			m[e] = a, g += a;
		}
	}
	te(i - a + r, a + u), te(a - r, r);
	let v = new Uint16Array(g), y = 0;
	for (let e = 0; e < _; e++) for (let t = 0; t < 2; t++) {
		let n = h[e * 2 + t], r = f[n];
		if (r < 0) {
			let e = p[n], t = e + m[n];
			for (; e < t;) v[y++] = v[e++];
		} else v[y++] = r;
	}
	let ne = new Uint16Array(t), re = 0;
	for (; c < o;) {
		let t = F[e.charCodeAt(c++)];
		t >= a && (t = t * 91 - s + F[e.charCodeAt(c++)]);
		let n = f[t];
		if (n < 0) {
			let e = p[t], n = e + m[t];
			for (; e < n;) ne[re++] = v[e++];
		} else ne[re++] = n;
	}
	return ne;
}
// node_modules/entities/dist/generated/decode-data-html.js
var Ln = /* #__PURE__ */ In("!}.&u%}'&}*'~!6*)%&,~!J~!J~%L~y<~!R,~~%Lu~~#GD~~#|)1#%}^%}2%+#.##%##%}&%##%'#%##&%#%#'%#&#%#&#'#%%#&#%##%#)%''%&%#%#'%#%%#%%}%%%#%#&(23#%%#&-%0%('1#(##%#'##+%'*.:1}#%#6-+(%'%%#%%%}#L'2351&('%}&/N'(0(/*-%(%%}#'+&T%7.2}#&%&#%#36/5##%&%%#&#%%#))2%%##%&&'0~!#*+&'%1~!%).'3q?&%'1~!.##%6(~!+%%%(Gw'rT~!E#<nA%#jZ~!H%(~!42##~!*31&~!G%U~#)5~#`3~!J~!Z~%]~%Y~%C~!q~!u~#kz~%#~!6'~!D~!U~!?~#T~!c%~!G#'~%7|~!G~!J~!G&~#pb~(Df}#%}*&}#%##%##%##&#-}&'#'&%#.++}%mI,#,@&(}*%}*'%&##&#%##%}&0}#.},U},%}+%}&%}#%##&}B%(}(%}+%)})%##%#&}&%##%&}<%}>%#%&}*%}(%}9%}/%})%}*%}*%}?&}&%}3%}&*#%})%#%#)}#&#-#+*%E%%'%'#%}#*V##&##I}#&&##%&%#&&Qf%%))w/0+&%#(#.%-''''++++7}>%4'',##1,#%#&%##&#'##&#*#9)%&%}#*}%,#+P(%A&%#'&##wSD',9E00#y#@}(+}&%&>~!#~!X}#*}(&&}(&}(,%}%&#+&}#&}I%#%}%)#(},'%#*}4%%#%}(''}#/##(##),%-##%%)#&}(.}&%#&}%%}*&#%},&&}&%}#%*'#%})%}D&}&%}-&}6&#&}-,%}#%})-(~+`~,=?~I9'9%~!,#%})%})%}@%}?%}(~!?~#<~#pP~#BG~#=1#%K+~#?#~%;)~#A~#mF1~#A'~'X%'~#lR~#N~'N~#r~#m#-~#i'?%#'%~#B%##%,%#~#_%#0%~#]732~,w~2+#:&#%&'0%&>%}#>##F+)#%&&#(+_}4&}-%}(&}@&}O7Fdf0@+/v4}&WU##&/0#&'('B#%}.%}'+#%}#%%&#&%#%##+#&#)#6#'#.},%}c%},%#%##%&#&%#&~#>'*-.%##%##%}#%%}%'~#)D1}#%*&~#_%%'(~#S2%'.}#~#=##*'*-%}&'%'##&&~'E%.#&~#M4}%%##&'%#~#O1##%&#'+~#<B%##%%'%+~#;#@%}#&%#&&%#(~#H1}'%'##&&~#?A}&'~#D#%32}'&&&&~#[}'(#%}'~#;C})&}%%#%~#=&%,3}%'(#%%~#^'#&&)#%'~#Y%-~#d-%'~#^%%&#&&&}#~#b~2t*&'~&(~&@~0%~e~3}%*''0})&}+~!9##-}#%-hD*)1fC#%/&/fB#40~!+#)*4~!+~!K'&:~!/*7~!.#~!H~!L':~%x&~!H#~!*~%1~!I#~!+A~#p'~!F~~#-#~,,(~.Z~!V~%;'B'mq-W~!N~%I%#&&#&}#%},%%}'%}+X#%}#&}(%}'%}<%}#%}%%'}'%}:~![)9@~%>~#UA%-%##&~!C%~!-.9:~!1~!-^2/:a~!y,D*J#-5)/4~%23,~#G~!L1~!0X3`~!2+~!!0-~&E~!W~!o,>Y&]~%cZx_&~#O*9#A#'#+I'%#)~!0B*-5A+-((F&*M#)(-7-5+'-3a5Vi~!Y~!?+[)%3),ERHm~!+:D,VG.+)?fB%%*(%)'(#&80%1'8`K8?`+'Z#&O&'H5#*9)A%%5&3))0%39+.*7#()&&*=4@**L)<'_&*+..;(#*+)./&0#3)%')-8(4ixD(&.}%,('aI:,)%,k2231T)I'#/-W7,/'Q#.'Y24+h')37</31&83##&0#),H(?'&?/1##%#&&#%''-%&&&#(&''&#.-'%#%%(,')*'&#&#'##%(%(#%('#&##%%%%('%#%#%%#%#&%##h>w+v<ayvyvcg.uuhKr}g/v|g>u9i[~>g5uI~=RvdwEg;v/g;uk!!TTSx]@RT!U!#!@VBRUU!'UTe-d0c`e&gSdicedFcrdTaqb.kYcAohdYd@a3e+d}dMdtd.aJ#bqcK`dle/e.e'dwdPdodddjbEb}ogd^ofdpduc6j?l%d{drdqc)d7bacOdQ%T#Y)X.sR[yH>6Vyv3[xwLu>vo'!*.[yBacahoj>6Rew3[xqdZa#!a&#^(X-[yG>6Vyu3[xvg3sEr|g.u/Ri9db0T#^(Xa)!-[y;>6Vylg4wKs{JwNZt3@3r=c4Z([xlg;wKt!cpq's@v7A'*a(a+!-a#[y<3Dt?3Dt'>6Vym3[xmg9rxsNJwLZt4~?r?db1T#`-!(Xa,!0[yS>6Vz%NuQs.g4wKtnJwNZtS@3r>c4Z([y%g;wKtrdga8!a(!#&T*Y-Xa#!a0<or[yc3Dtq>6Vz43[y3JwNZtf@3s!Ju}!%Dti:pm3c_%X#tjB5pkd6q!r]u?voC'*-a.a2!0a&a+[yI3DtI3Ds~3DtH>6Vyw3[xx;:s#~<5pKJwNZtE@3r~d`a)!a2T#a.(!+U.X1[yT3Dt`3Dtv>6Vz&3[y&g9rxwzcxstPu.<rAJwLZtT~?r@dZa%!a.&^*Za(/Reu[ya>6Vz23[y1g3sEr}wkg{NuQRg{ci(U#5@b`~,cg#U(2WnH5wugcRh7dX#T(Y,a'Ta!!a,[yZ<]mj>6Vz,3[y+Pv#5ReZKu+=,%!H}7ABwkaS?Rh:BcW(X#<]mrj:ubv/ARekdg%!(!a.*Ta(Y.X1!#sP>Rl*Dt6[y>>6Vyo3Wf*jOvuumvuRgRJuq*!:9<B@bX~3jVv&v@s@5Re[d/rQt{uAvo&a&a*)a2!,0Wf!3Dt0=Bs'>6Re}3[xy~<5s%JwJZt1~Gs)c;&!#2sJkNuXvzq7rxu,Re8dka4!a8(aEZ+a@Y.X1Xa)[yd=Bs(3DtP>6Vz53[y4cX#X&Re:avRe9~<5s&JwJZtQ~Gs*i^rzvdRg+Jv{%!2sbB@bX}kdga,!Za?&^*T1/!a'Dt+[y6>6Vyf3Wf%g/u;s4hGu6?Rh-JvZ,!c%#&RoX54Rivj7uyvf8RgTKvZB%*!2sGh<vu5Rgq<=C::9bb~#dZ#T&Ta6Y.X*Dt>[y93Wf)coZ(T,6VyifluvRgC@95@B@bX~/hFu34cC#T,k/unq8w8Q5RkUklwQuzunq8w8Q5Rk8d/rJu?v8w9)-&!a0a;a&aIWejg3sEr/h1s<DtDJvyZqY5aws3Jvy!&Wei~Hr1:au5@Bag>23E~5c:Z&bX};kKv?w&unuVu5Rjc;>bs)#~@:Rh.=ay<a]C;b`}Vd6s/t{uAvoaxa()!a,a7%-a#a2Dt,[yF2Wo[>6Vyt3[xuNuPRi&NuPwpi#RoWh?vf8Ri%Jv]!%Ri:KvxD!.'2WeAjZu`q9rxu,Re7woeAg-unLq(qA_/*2Wg_g3u5q^9:4E}/jTrxrzv=Wkkd~0UX#^^Xa-a1a5T&a=U1a'*aEa]!a*aPaA-adok[y54Rn>;:p3~Dp5g9rpsFNvZqjg3uJp4~<5p0Pw;5qlJwNZt*@3p1Pw:5p/Ou!5p2JvG'!6Vye=<qnJvh_[xhg3v,Rh3kOwOw-sDuev/Re^dha[a%!%!a+#Ta7)-5TaCaO!aka!a)sf[yb2>Rl!9ARiq5E}Qg=ucRkBE|oJrJ_@Wk~@Wk{JrJ_@Wk|@WkyJrJ_@Wk}@WkzJvO_[y2g-vMRmiKuYC!)&>Ri;>Ri<@3RkNc](X#@9Rk=g5vuRmhKvDB!+'=]meg3u4Rmgd)#Y'Vz3CARmfd`a+!%T'!+#Ta1Ta6TaM-sTDt9[yA9sYd'%Y#s[[xpj:ueunaXRgEjRq,v-vuqdd2'`#6Rev<32@5>:2<E}5xIo9a*X#Y(;5RePJvD_g>vyRgNj8w)v8<wggs:RgXiZt|vjx,hSq3ah!-(~@:Ro/Ou!5RhWj^v(pyw8unRhUdx-UY#^Ua.a3a70!)%UX1TaDa)'omRiRRhE[y:3Dsz=Br,>6Vyj3[xkg6ruwjcqsrPw;5r*Ku]D'Zt-@3r(~?r.i[vwv]dU1a--U#`a4(g/vsRhPOu!5RhLj:rmu9Wo!~@:wdh@g/vsRiTjXuvvNr}:RhBj^v(pyw8unRn]dz1UYa'a+^Y(!aETZalaRY.Ta?a4[yDJw1!#qLsW>6Vyrfzq-pLflpwRe|Js>%!Dt@3Dt&Jvy_[xs~HrnjMuwpsw'RecKu+D#'!t<~Grl~?rjg5u-x,gwp{ah!-(~@:Rg~Ou!5Rh'jXuvvNr}:Rh#cW#X/c;&!#2sLi[v7u7RgpJv)(!iLrxu,Re6j7v@s@5Se[e7d`aW!Za(a`T.a#!a3!&aDa-!9)Dt_=6s+3[x~~DR|h~DS6avhGun5RkZj3w)v-]mkKunB!&*]kb97R|i<ARk<c:Z(6Vy}Juh'!wziMRoS:F|vkLuauJv5vtvQRh1d='T+Y#VyO~DR|jcF#T'7R|g97R|kJv3'!ay<Rj,Jvh&!:ReXcsa6*a+#a#_aIRf9aLRf?c,Z&Rf5Rf7c.Z&Rf;Rf>cQ#%T'p-Rf8Rf=ct#%'(*!,p,Rf4p+Rf6Rf:Rf<d~'Ua%U*^UYa(!a,-!#a4YaTalaEX0a8a<Weo3Dt/3Dsx=Br93Wen~Dr;~<5p<JwNZt2@3p=Pw:5p;Ou!5r3c7&!#:p>3Ds}KvGB)_6Vyk2sM=<r7x'eovA(!hFu1ARf}cV#X&@r5j6rvwQa^Rf3c=Za'wkghJv__g;unRggA53B9=b^}%j6uduo5Jq;!(hIv%2Re`Ou4ARe_e%a#^^^Xa&!a*a2!&a6YaP!*ad!#a:aE/5Rn?[y@>6Vyp;:pE~DrY~<5pBJwNZt8@3pCh=rt3rWPw:5pAJup_[xoNuPpF9c!#'45pD5ARn)d8#X'X*3@rU72s]h>v<<sSjJpqvewOJq/(!hNw'5ReBk0s2u3w/w'5ReE5@Jq.!a+JQ!&WeU23d(#Y&RjG5]jBk!u7w&u0udARjEe#+^^^Ub#!a2/a`Z(agT1!a-a;|@TaG!aS[yV=Re~fow'RguNuPRe?bz#'>RoUWeL>:Cbb|?JwPZtVg6ruRmzJvD'!6Vz(g/vmRh~Jvy_[y(g9voRgyx*cy(#2>Ri2B9b]~9kIw9u7rluJu3Rg]dI#a%UY'@=p%CAx.gQZ&RhwwygtRm{x5g_Z'+ABqR9Woa=Bp&dV#^*Xa'!&@o{g4v]Rk;Jv{!%Rk[wkkiA5RkiwwfUB=x,fUuqC&*!>RfTg8v0RfV~ARfSd;rJsAuAv9wR'ae+/aO!a@aza/a#[yQ@Wg!2Wemg3sEr0JvB_g>uvReWg2v+Re=KupB_+[y!2AbY~-~Hr2AJwD!(h<~El>h<~El?Kun@+_:9b`}Kg-v/Ri3g;vtwyk_9]k_d=&T#*U.6qh@Ab`|K9:H|CJv[!&3Dtex'fDwC%!Rf[9WlMd[(^X,!a%Z06Vz!@WgBg=v~Rgvg,QRe@awd,#Y+jTv|Q~EfWj]uNr|~FRfXdy#Y&^Ua%!aO.!(a)Ua;=!a@aKap!a-,a!Ta]a[rSa]p?[y82sK=Bq~;:p:~<5p8Pw:5p7d'#Y'Wf(;RnRi[u4w&RgJJvG'!6Vyh=<r#ijuuv/sIKuYD'ZtG@3p9~Gr&d2#`(g<vtRgFj`u5w&rqpxRf2CJuY!+:wfnTOu!5Rg}jNs1ucv&RfwJvA!&3@q|BDcC#T,k/unq8w8Q5RkTklwQuzunq8w8Q5Rk9dga#!a'!a=#a0!:+Tb*b@aO.a4!aba8aFJv^}?!VyR~Dr<g;u%Rn.~<5p[x'e`wNZtR@3p]Pw:5pZhNvjBp.woe_g5u-r4JwF!%DtO3:ooc7&!#:p^3DtpLuGw(!+%)Dtk6Vz#2sd=<r8d'#Y([y#<x3gJt`w@!)%}MRiowzikRij=]ilxAf3,U(#B2Rf#g0v-Rm[ck{`U#]giKv3>)!&6Ri154s,KuGB_%@r68r:dJ|t`#X(9<E|u2@H|rx3gJu?w'!+'1Nu7Reg4=H~+9<wxgY95Rm]xLggZ-`(X}U2:Ri4h<uOawRmsJv__5@bb{jbV~3dka#a'a]!,#a+U=a>b6a3b%!/aKa/)!arwve^VyJ;:pR~DpTg3uJpS~<5pOPw;5qmPw:5pNOu!5pQJvG'!6Vyx=<qoJvA!{~Jup!%@qk7Rn/KvyD!}''[xz;>wkh'?Rh,x8gyt`w5D!&),(SgyccRgztJ@3pPB5p#d'(Y#<]mmifubw&RgoJvE&!82s^JvF&!8Rf,ADb]~;x=h'rNu]vK!,%'*0RnORh)4Rh*AqQg-vaRnNg;wHwkh'ba~4cE#Ta*x3gctyw@'!+%RnFRnD<4Rn@hFvK5RnCxWg[#`&a0Ua()`1Rm75Rg[c]%X#qi8Rg^NvdRj>BwzgZauwji7Rm6A4wgg]d1#&(*,.0a#Rm;Rm<Rm=Rm>Rm?Rm@RmARmBe%#^^^Xaea?aC/b+(,!a+a#!a/!>a&Ta<aKbD!2wphBRnk[yPw}hE|.=Br-3Dtm>6Vy~g6urRf.x,hPrNav!%'RnqRo%Ro#Nu;q[Pw;5r+JwNZtM@3r)d'#Y'Weh;xChL#`&RnmRnoKu}>%(!Rne~Bs-;2wjcussJv+'!aYSO}6@B<5?ba~8LrNvj!.%*ROwungw~ng~:9;Ri^>wtnig;wHRnixDh@|(UZ.x1h@|)!#:2<H|*xHn]#-UX'3Ro)z=iT}6ARns=Bwsn_wpnaRncw]aR(#UXa&Ua*a/=]iPd'#Y&Ro'WnXf{QRm2hNvj]nZd`'T~&1`{|`#9b]{}c:'!#Wl{>@=be}]?cl{{U#:5Abb}Jds#^YaF!a*b4a#a3aPa>&Tb!bH!*a_!Eau?/a&RjY<]gj>6Vz*;:pe~DrZg,QRj1JwNZtX@wihspcJvZ&!VyX9WmOJu|!|N2WmHJvh&!]ht~Bpbcn&T(!#RmQ<s7Nu;padH#X'`+WmJ@>RmKCARhnKup=!)&Wf+:RhqNuPpf9c!#'45pd5AwghpARn(Ls@w!%,)!RmP@Wfe<E|IJva!&WmNg8vsRmLd`*.`#Y'Xa!axRn*]hrA8Rhug5s@rXg8u!RmMd8#X'X*3@rV72smdI*#UY&RmICARho~GsgxVgd)Ta'U-Y&Xa!T#RnEWnA@Wffg1uDRi0hFvK5RnBxGnG&#`%owp)@wsf+bX}Ze-*1!a*^^^Ua|!#a.aq&Ya2!a>.a6!a:aO`aJDtL[y`@Wg#>6Vz12@wzoYRoZNuPRi!NuPRhzg=ucRi,@=b`{Yg=ucRi-ACJvB!&Sh[ebSh]ebi`wUuFRm4Jw2_[y0JvB!.<Ju(!&SoG}6Shd}6<Ju(!&SoH}6She}6Kur@._g5vHRieJvx!{L2G{Kx6gd'T#?Rh82Wi5cZ#X(g1w)Rm5dW-Y(Ta#!a)!#aYa=wnfE=su2>>bU{0j9udv:<svj8uQv-7RgHdE%#^'sq9sp=>Bb_{TJv`!&g/r|snj6v(us5d,#Y(56H}[978H}]Jw5!&g1rushJvB!+j;v{u5?zDhd}6}bj;v{u5?zDhe}6}ce*#`(^^^a[aea!=!a6a*aoXb1a.!aAbL!b>,b'aL!aV@Wf|2Wlg3[y/JwNZt^@3piPw:5pgJunZou3@rsJva&!Vy_g<v~Rm#JvG'!6Vz0=<r{Ju{%!:pj@WfsiXuJu3Rm:JvZ&!WfA~Bph@c4Z&Dtwax5rubx(#:awRk1@d,#Y&RfjRfid1#,Y(@Wfp2Wlrg5s@ryKu[@!,'=]ig9wlk?Rk>g5u-rqJvy'!@9RkQcH(T#=>Ri~@<wkj(Wj(KuZB*!&<7rw@9RkRcH(T#=>Ri}@<wkj)Wj)dg(Ta2Xa9X#`-!a*CARhg@@=I}d9x;c~#X%so=<sj>2@@=aybb}XjWv0Q~EfEj3vLv;<d,#Y(56H}`978H}_dgaPaFa'a/!#a3Y0a_a;a|!1(a7-[yE3[xt;:pJNvZrrg3uJrvJwNZt=@3pIh=rt3rxPw:5pGOu!5rpJvG'!6Vys=<rz@c4Z&Dt(ax5rtJvZ!&~BpH@wsfNg-vaRlNci*U#=<wei<F}a5@Jq.!a*JQ!%@qZ23d(#Y&RjH5]jCk!u7w&u0udARjFd/prq=tyvpaEa(a:.!a1aZ(@@=I}:9wpd%=<sX55w_h}@@=I{t=ay<aU@@=I}T=ay<2@@=I})?C9:9au@9Cb]}DP~=x-fAZ(2Wl1=ay<aU@@=I}>5@d##Y+jTv|vV~EfFj]uNpn~FRfGdgaK!Z2&!a8a-Tb({E!acTbM*!a(DtY[yYd'%Y#sl[y*hHvh>Re5x2c{Z}.j4uCvcawRiMd+#X+_x&d!},<5RkX;2Hzw@x,gavfB-!{CcF&T#Roe;RodwWbBg5urRgaKvHC*_6Vz+<4opieuew&Rmq@d]&Y)X,T#X0Rh}<BqP=4qS9:ReMg/ujReNJw0!/<Jui%!bd{kawwnemRelAxUa?a3#*.&UX(Ya+a/RhvRnQ<o}9Wmtd-#Y&RgSRmw9;Rmxay=Rmyg-vaRmuxEhSrNu,v-voC!%(aR.a(a7+1Ro1>Ro5CE{A9b]{@;5x#eO{:g;urRi+KrNA!%(Ro3>Ro79;Ri_Ku@>{;&!x%gX|{KunA_+g5QRj/g3u5Rj#g>uERj%wio/xRhS&!,!#^1U}wba{8>>@=be}qC@:D5ba{7Ku+A&!}x?ba}t>>@=be}se(aA^^^Uat!b0#{pa+awUazbGa#aLb9bgaWac'a5TbS=Br!d1#`%scp_Jvl!#rT>Re0JvX&!VyN=H{Fcm#U&:pY=ReaJv2&!]h0=]nUJvG'!6Vy|=<r%JrM_=]h2@Wlud'#)U'Wf'b]{i=]h/Jvh!&~BpWg=v]RnMx+ny#'Nu;pVwjnu=]nwxJnx,T#`&Reqwjnt=]nvieu9vrRjLLuYwP(#+!th@wih5pX~Gr'g5v/Rh4KunA'!-CARnP@wwiN:Rm_9x'cvw>!|l=<saKvAA!0&3@q}>w^e1bp#&Re2Re3BDx7gH#T|f5H|eKuZ>!%(:qNAH{]Jv6!+3B2B9=b^{X<5<B92:E{ZLvhwA(a;a%!igQuyRmad+#Y}m@3Rh5d8#X'X*:AqUAHzmaxwbh<aXRnVcF}RT#Nw&cj#U(BWnug/vsRntdka)(a3+.Zb7aYYan1!bVa@Xa}[y^@b[{G=H{+hFu73Rj&Pv#5ReQcK%T#sig1v{Rj'Ku+D#'!t]~Grm~?rkKuMB!01d5#`'Vy.ta3Dtu~Hroc8#'{^45s85AwZbP&!#Rn!wghxWn#KvEA!)&2RlA2RlBx:h|#(T,=]j09Wobz>x]z/@awRoTd+#Y(az]hFhCrm4d,#Y+jTv|Q~EfMj]uNr|~FRfOdCa!Xa9_X#@<plJvf!%b`{(9;Rgwc;.!#2x7cw#T|UDb]|T5Ju={(!=@E{&Jv)&!Ab`{'awJvf!~*>>@=be{#KuY>!+&4Ezyi[ugv&RjIdea+T)#UXa&T-T&a!Rh9auRmW=]kLg5vuRn+g3u4Rn-Ow6ARn,hHus5xNk?#UX(U~)/g8v0RkD~AwkkF?Ri.OuNBwkkA?Ri/d|a2`a*^UYa.!aBTZaTa'Xa;!(!2!-a#b2[yC>6Vyq3[xr2Wi?g1rusVh%s?DtF~<5rbJs;%!DtBfswKtCj[uvuSsEu3RgVx3o:u+wN'*Zt;@3rd~Grh~?rfg8w)Lq)qE&-a%!>bI|`jWv0vV~EfCjTv|vV~Ef@j]uNpn~FRfBcK#T']gWNu7x,k7q4ai(0!hHv8<RhmkMu9vrsBuev/RhlCJvB!,g<v{wchh~@:Rhji[vrv{wchi~@:RhkdS&a5UY#Ta!RgPwwiI5BwciI~@:Rh`x'iJvj'!5]iJPu8Bwch]~@:Rhach)U#h3rp]gLh@t|Ax,hTq3ah!-(~@:Ro0Ou!5RhXj^v(pyw8unRhVd|)`,^UYas!a?/a2Z'a^Ta{Tb7Ta(a#!a,Wf&9sZ3DtAadamov=Bqt3[xig8vsRm~>waiL2b`{QJv*_Ouv2qgj<v]v2BqfdR'X*X#Y-@3qr~Gqv~?p6hHv-]glPup5Lq+q?_%*b_{qF{n9b^{rOu4ARhpKvCD!+&~Bqp:5Dbb}nwoiKl&unuTuBv]v+ueunaXRf0=Jvh!0nKufu8v1w&w7q%w&uHrz:Rgnj5w,uxDJq/(!hNw'5ReCk0s2u3w/w'5ReFd>Za&!*UaA=<wkgsRnSJv^!%Refifw3vyRgOKu_B'!,<]gkiiu:w&Rh<=C@a^<B57@2F{[<B5@aW:=3away9A5aW=<B=C@a^<B57@2F{Ie-#`(^^^bCara.b8aza6!/bZ,!adTbnTbOb+aFaS!aAT9@Wf~2Wli3Dtl2@d,#Y&RfnRfmJwJZtN~GqyJva&!VyMg<v~Rm%iXuJu3Rm9Jv[_=]ih9wlkDRkCd1#`(@Wg>2Wls3cH#T(@<Rj*=>Ri|b~'#23s9h<~El.d'#Y&Dtxi^rzvdRl#d*#U%(o|B2s`hJwSaxRmDKv4B&!1:Rmdd5#`'Vx}to~Hq{x'f1v3(!BA5ba|bJv_&!Wfug1v]ReIdO+U/Y#&G}-8wze=Rh{g1v]ReHg/uQRf/by#)ibQwERl/cH#T(@<Rj+=>Ri{cNu+vlax-!(#a0qa9<Rii2;;bU{H;x<i=&X#Rk`<4wwi=C9H~8xAI(Y#<azRi@45wXI<B9;5bb~7dL(X#Xa(+!aL6Vy{g5QqOau:5au2@ay547EzbxOcU(UX-T#Ta#:Cbb|A?wjh/b_|SOw6ARgtihr}u7Rhy<d1#T)X1@@=I|~=ay<2@@=aybb}Sj3vLv;<d,#Y(56H}A978H}@dGpvs@uAu`vcw9*!aFa+ai%(b!aXa8.a?a[ozWey=sU2@G}Nch&U#Rf_WexKu+D#'!t:~Gr`~?r^j]uNr|~FRg*j^psurwJt|RmcKv)@&!)7Rkv~Br[@wxfO:Rl3co#U'6Rezj_q#vIuavjRltwzeyh@vr5JqD0!>aY?C9:9au@9Cb]}9cl#U*5;5<H||jbuus1ucv&Rfvg1v~d/pppzqFr^a--a~!aMat1(hFv;Wiz@@=Izoj5uuv-7Rix~Cw`fk2WlVcZ#X,k)u3vWs@u2]ktg;wEx'fBq(_2Wg/jTv|vV~EfoJv]!15x'hzqG!(P~EfU~CRl_j6v(us5x4i-#T(2WmZ?C2F|d>Kq<aj1!*jTqIsBv=Wl`~Cw`fi2WlWj`v0u*~>RlR=c>Z,k#u3vWs@u2]kr<c1Z+jTqIsBv=Wla~Cw`fm2WlXdmb3!a{(arZa`bkTa%TbQTa-a9+c'!aM!/[yL=Bqug.w'RifhFvyDRj.g>vgwyk^9]k^Jv3_@WfbAARkhJw2_[x|JvB_wkoIRoKwkoJRoLd'(Y#<]gm=<9<H|yd'%_X#skDtb3awwqkgNulRkgdB#^',9:p'hJwSaxRmEBwVb8@4=H|qLu+w50&!)@3qs~?pU>Awwn;;Rn=c:Z'ARn<=<qwKvC@!/&~BqqJv6!&]eVb^z^xRge'/a%+^`#Sge}6<4Rn3=]n0Pw2>Rn8Jw0!&>Rn:>Rn6cY#a7+!a&=<wkaNw~h3z_c5Z{=wjh#=]nLKv^D!&)Vyz=bW|swYb<WetcG#T(2wxa@qVx@gD#Y&b^|V5JwG&!5bb|pg/w&RgD@x=kHs=uAvn!a%%/'+RmSRh694Ro`g-vaRmRhHv-]mlxCcS#`&ba~.5cD#Ta)P~=d,#Y(56H{>978H{Dd_#{2^Y%_+qbbb{6g3sERhsbU{?dfa.,`a(Xa<!aiX#(55RiG54RiHcI#T'WiU3RiVNvdwtfcRlKNvdd,#Y&RlHRlExQgf.1*^T'X#Sgf}6Wn4=]hfPrk>Rn7Jw0!&>Rn5>Rn9Lunw?&a2!,5<oq@@wqfdRlJj5Q~=d,#Y(~ARfcOuN]fdDKw;ay(}i!547E}j?cI#T(@5bV}iCbV}hdv(^^Tb?a40,b##Tbo!a*bR!a<b|a/!aKai!aU[yK=]o^g:v>ReGJwPZtK<7Rh+h<~El,Pv#5ReR@awwxjCg,ulRjDJv6&!]j!z?aQeeg>w=Sh<eeJw;!&axEzOg,Qosc!#*:wkeJ]eJ>x'h-u(!%Ro.w~h.zPdNZ(X,Ya![x{;9ReY;wkgxRiF:x?ap#Y&RmUg<s2Rkod]+UY0TZ'!a&A9sw<=bczLNvuw{gqzNhJwSaxRmCKuLay!#&s_Rf-55b^{uJvZa!!c%#(55Ri654wmiu5RiuawLu,vp!+}^%b_}Y9;wkgxba}o>A9:=b^}zKuh=a''!3awRk3c*'!#aHRk6c+Z&Rk5Rk4Jv)&!awRjSawd9*`#0?C2@EzMj8u<uJ5RmbjQrquJu3x,k>uq@_+=ayb^|W~ARkEOuN]k@7dhzV^X/X&a-#zRzSb`zXcJzTT#2WkVKvDBzW!%FzY9;5bbzWjQrquJu3Jw3%!b`zU=ayb^zQd:#X(T-a!6Vyywxh}=b]{Jg=u1RiAdGp~qHtzv!w(wA+a+a;<!aJaYai'anasb(=azRmV:Cbb{MLq2vb!%')RjuRjrRjtRjqx3jnqCw3!%')Rk(Rk+Rk&Rk)Lq2vb!%')Rj{RjxRjzRjwLq2vb!%')RjsRjpRjfRjex3jcqCw3!%')Rk'Rk*RjkRjl9<CbbzfOu4ARhxLq2vb!%')RjyRjvRjhRjgx=joq*uKvb!%')+-Rk.Rk%Rj~Rk-Rk#Rj}x=jdq*uKvb!%')+-Rk,Rk!Rj|RjmRjjRjidAq&qKs@uAv8Aa.'*-a@a&0!aM@a5[y73Dsy3Ds|3Dt):wxgI2sHJwJZt.~Gqxwsf0ikrzt}Rl0Jvy_[xj~HqzKv_A|D!&WfP8axRoVcf,U#k(v]v+ueunaXRf1Ju}'!g8u#Ri=jQw!sCunLprq>!,')~<5qeGzq9F{W=c##%s5au:5aU3CBE|;d4#X(D!a&6Vygx(b;#(=]ed?C2F{N<capoq2r[a&!aPa9,'Pw;5s:@@=I|,55w_h|@@=IzcP~=x'fCqB_2Wl2>aU@@=I|1OuNBc1Z+jTqIsBv=Wlc~Cw`fl2WlZ~AcTa%!Z+jTqIsBv=Wlb~Cw`fh2WlYk+uNqJsBv=WlSg,u3dca3#UXaMYa)TaB-=cM|7T#<bI}l5@B932:aV2G{BOuNBJq:|M!5Ezt=<B=C@a^<B57@2F{v>cB{/T#=ay<bI{3Jv6!a.6BKq0ah&+!5E}HP~Ef{978BaU@@=Iza<7d#.Y#978BaU@@=IzH~AJq0!(@@=IzG978BaU@@=IzFe,aU*Y&^^^bvJb,b:bFad!a,c2Ta>aL.bo6!a#CbTa'T#Re{2Wlh2@G{yg6t~Ro_NvdRfticuRQRllJv3&!x&c|zs@Jw3!%RflwpfkRlpKuL;%(!Re<@G|C2GzdhIvuBwgjAg-u0RjAKQB%!(GzZ@G|5NuuRl7d='T+Y#Vy[g<v~Rm!==G|>JvA!)@wma=]m1ifuaw&RmnLs@vT'!|/+[y,g:v>ReTJw1!#qX=x!eC{bLu+wT&)ZtZauq_~Graci&U#F|89:r_Lupvq!.)&2RlG8RfaC=x!eF{_h?rpWlmd&'!#X|&]k::xJey#`'T|+<E|&2@H|%dE#(^,g;u.RiEg6vjRiC9xCkA{O|zY#g=ucRmXKs0@!&*@G|m@awRknJuh!,3d(}gY}eJvj!%Rm):Jw3!%Rm+Rm-Ls0w(&!a(a#@b[|6cZ#X'7RkxWgAOu4ARn'dH'U#Y*Vz-Wm'CARm}d]*#a%^a*T'aK!a<9bV{PC=p*Jw4!&SgxcbB5r]idw(wBRmF7xFkt#&`(Rm/Rm8E|!JuY_9:Rl5=wrgr2:bbxd@xXfB(a*#T+!.X0X1Ta/a'T&RlDRfL>RlyARl9b[z[>RfZ:RlL:RfRwlg/ARl;9;RlxKv,A/!%7s69<74=BA5ba{-8Bde#`a<XaKYa1,a'P~=wxfB2bZ}}?C972@@=I}r8@55B9;5bb}G978B2@@=aybb}3j3vLv;<Jw3&!>Rfk=ayb^}4~Ad1#`*@@=aybb{w2@>==<bbz]dx+UY#^UaF!a9!bB'Ya1.!ajXa#%olRhD[y=3Dt#Ov5BrHKuMB%!(Rf^Wep~HrJwkiQjKr|~FRg)Ku+D#'!t5~GrF~?rDdV)UY,Z/_7RkuG{<~BrBg,rlsO:235B@bX}|d?a1!#`(6Vyn5@d##Y+jTv|vV~EfIj]uNpn~FRfH7Lq2vb1!a9-978BaU@@=Iz9978BbU}#~AJq0!(@@=Iz8978BaU@@=Iz7~AJQ|}!978BbU}!JvkaK!AdUa21-U#`a+(g/vsRn~Ou!5RPj:rmu9WhOjXuvvNr}:RhAj^v(pyw8unRn[kPr}p|u7vwv]RiSBd;pppzq@qHQa?(b.!a.a`@.|xa(hFv;Wiyj5uuv-7Riw~Cw`fg2WlU978BbU|wOuNBJqG!(P~EfD~CRlQcZ#X,k)u3vWs@u2]ksg;wEx'f@q1_2Wg.j]uNpn~FRfqJv]!15x'h{qG!(@@=IzK~CRl^j6v(us5x4i,#T(2WmY?C2F{1>Kq<aj1!*jTqIsBv=Wld~Cw`fj2Wl[j`v0u*~>RlT=c>Z,k#u3vWs@u2]kq<c1Z+jTqIsBv=Wle~Cw`fn2Wl]dn1#c(a(b^a2!b/bAT(bj!aDa7bu,a_a{c0!2T0g:v>ReD2@G{42@G{5~DpM~<5rc=Bx6i>{RT#RnI@zCx]y]z:2Jv[!zr5Awyk]9]k]dD(Y+X#6Vz.g=wKtgwhaCwgmTWj2Lu,w%_+/[y-B;b^xeg3u3Rj-2@bX{*KrJ<!+'@Wg(g?QRlC@Jv`!%b[zIwsfII}8JQ_@w|kW|=Jv(%!AqcOuNBJvEzh!bYzjLs@wP#(0!oy@>RkdJwMZtc3Dtd@BcG#T'9bWxg2@2Fznd*#Y+;2x'c}w<zizixNgwa#Z'U+!/!a'!a+w~g~z6wcn{Rn}wcnzRn|5Rh%=]nJg5vuRmvNvdRlvcprJu}w*az*a#!%.a.'Bot9qT]kj@Wg'ay2Gzv@Jv`!%b[zEwsfHI}1;ck#Ux`<Cbbx_Lu+w!a&0*!wko*wwo,So,}6Juqxf!E}PigQuyRm`d3(`#8>Rn%:A5B;bZ~%KvhCa!a2!x>k7#Uxb@b{#xaRk7Jw0!)>wwhlShl}6>wwhmShm}6CJvB!.x'hhvj{!!5Bwkhhbaz}x'hivjz~!5Bwkhibaz|xEhTrNu,v-vpD!a%&/)a3a.,%Ro2t[CE{)@3re9b]{%wjo09:rgc:Z&Ro6=<riifuaw&RmoKrNA!%(Ro4>Ro89;Ri`dSaL'UYzxZb)7Rka3xRhT&!,!#^1U}vbaz{>>@=be}yC@:D5bazzKu+A&!}{?ba}y>>@=be}wxBh[t`u~vJvr!%a!a()a,a0a4RoC=]o;Ju(!%RoGRhdwjh`=]oAg>w#Ro?g5vuRo=NvdRl|Ku]C.!&;RoEJvB!%RoORoMBx'h[v+_?w~h`}~5?w~hd~!xKh]oiptu-utv.vp!#%&a30a@a'a+(a/aOp(o~p!RoDJu(!%RoHRhewjha=]oBNvdRl}g>w#Ro@g5vuRo>c[#X']o<CauRoRAd-#Y':RkpauRoQKu]C.!&;RoFJvB!%RoNRoPBx'h]v+_?w~ha}t5?w~he}ue!/UbhYacXaW^Tc&a;b:a-c/#b&aja1(!cL+!bKbt!bmcRc9aIc?8[yW3Dtt94Rg`Jv}!&SiRMzBhEebShEMNuPRe>x7gL#TzuwjirRipc<Z&>on;>z=h-MSh.Mwqczx'a7vj&!>Re4@=ResJt__NuPRi*NuPRi)j]uNr|~FRfzKrJ>_+@Wfy@Wf]2WocKrJ<!+'@Wg%g/QRl@@Jv`!&awRl<wsfFIzgLu(w*!.*&ShBMwvhIRhI9;RhNx1hK'!#Sn]Mx1hK~0!#:2<H~7cNu+w7D*'1ZtW>Rn1~?rOc:Z&Rn2=<rQ<7wjh&=BSnLMc]#X(6Vz)w[b=a!U#9wzgMc3#&(RgMRitRis<x,gKt`ax!&+SioM=BSilMc3#&(RgKRinRimKurB,!&SiQMzBhDebShDM6BJQ!(P~Efx978B2@@=I}WLrJw!!,a*&@G}O@9wkibRid@@x'fKwC!&SlDMSfLMjUv~Q~EfKKv3@a+!(hFv-]mpx/hYZ(C5RiWz<o/MwkhY?So/M@x,gbvfB*&!SgEM:SoeeehFu3:Rgbda(,^TZa)X/7Sg[eb:2RgI~BrMC@wgkc:wwkcRerx3h(uUvK!&*,SnOM4Sh*MArRg;wHRh(x=h;rJvPwI!a4',a'0@Wg&=BSh/Mg>w=Rh=g3w*wwgGRgGcW(X#;Sg}M2Gzk@Jv`!&awRl=wsfGIz`dKZ*T'Y-:RhR7RhQg5u-p`j6v(us5d,#Y+~Awkia?RicOuNBwkibba}Ld6p~tyu_vbAa'a+!a/'a3aEa8a!>Sh,ebJv{!&Sh@ebSaReb9;SgwebNuPRi(NvdRl)NuPRi'hHu^<Rm^Jvv_@Wl(g;u1Si/ebKu'B&!*Sh?eb@Wl'z@aPeb95Si.ebcpputyvjB)!,&a+0a%ShAMWeK@G}C@WfJ9;RhMwvhH9w{ia}ix,hJvRA1(!zAn[MRhHx1hJ~*!#hFv(BSn[MBJQ!(@@=I~'978B2@@=I}2db.Ua<'X}+T#a0XaG2G}E;wkg|wuh!Rh!x,hZu,@)!&So0MVy)C5RiXACJvB!&5RiY5RiZg8w)cG}*T#2@bU}=KsA>(!a.3wkhZba~(x,h^u(A!&(SoCMRhb5Bz=h[eb?w~hb~6x,h_u(A!&(SoDMRhc5Bz=h]eb?w~hc~6e)aA1T#T,^^^c-bMb&blcPaP(a/!0!bA=b5c@a(!bfbrc#2afwmhARnjwchORnp2Wlf3DtsNvdRl-2@wpa<]m0bx(#:awRk2@Jw3!%RfhwpfgRlnKQB%!(G{V@G|'NuuRl6d='T+Y#VyUg<v~Rl~==G|<Jv+'!aYShC}6@B<5?ba~8@Jw3'!g2QRljhLrpWlOd+#Y'g.w'rIg>w*wgj@g-u0Rj@Lu+wT&)ZtUauq]~GrGci&U#F|39:rELrNvj!.%*RhCwunfw~nf~:9;Ri]>wtnhg;wHRnhx3hDs@v~!/+'@Wfr@9RkSNu&Rlo=@<5GzoKs0@_+@Wl+@awRkmJuh!-3d(}pY#qWJvj!%Rm(:Jw3!%Rm,Rm*de&!1U-U#`)Re;@G|.@9Ri82@wjfvRlq=@<5GzpLvOvr!).&2RlF8Rf`C=x!eE{.Jw3_g2QRlkhLrpWlPde(!#U{s,UXa*Ta'[y'g:v>ReS;x0PZ&RnlRnn~HrKJw1}f!=x!eB|2w]aP(#Xa&a*Ta.Ua2a7=]iOd'#Y&Ro&WnWg;u.RiDg6vjRiBNvdRlzhNvj]nYJuW_2Wm3x)kFze{9d])!a.!,Y01!#&aC!a3RndC=ox~BrC@2b^{pg,rlse7x'ksuq!%Rm.E{xidw(wBRmGx9o+)X#wwo-So-}69:Rl4@xSf@a#XZ'X)X,Ta(/ARl8b[xc>RfY:RlI:RfQwlg.ARl:9;Rlwdn'#^XafaQa1X1TaHTa)@b[{zcZ#X'7RkwWg@Ou4ARn&x)kG#{,g7u/RkGdH'U#Y*Vz'Wm&CARm|bx#(A]gUbUzJj9Q~=d,#Y(56H}l978H{U7d,0#U*2>ABb_xZ978BbU{e~AJQ{g!978BbU{hxMh?ad{oUYZ.x1h?{l!#:2<H{mx3n[t{vl!,&a%3Ro(z=iS}6ARnr=Bwsn^wvn`Rnbd`*T}B0!#^X'BG{c9b]{a>>@=be}F?JvS!&BG{d7BG}(Bde#`a1X,Ya@!a'P~=wxf@2bZ}I56B2@@=aybb}08@55B9;5bb}<j3vLv;<Jw3&!>Rfg=ayb^}&OuNBKuLA!)a!P~=x#fD{f2@>==<bbzl?C972@@=Ix^d6rSu,v7w*C(0a)a6#B+a%!sQ[y?3Dt%3[xn~<5rLOu!5p@Ku+D#'!t7~GrP~?rNKvlaya7'!h+v-5qMg=t|cd,U#5AAaa5Abb{S@52B5@a[@52B5Gx[iXueu;d<#`a(!/549C;ag>23ExY5@Dah89b^~689Jv)!~2b[~1Lv'w(%*!a#bX|aPrmawRe]keu7uhv-q6rxu,q`xTo]/a5aU!bNaDXbi!b-!ao!b<bwA!#5@B932:aV2G|:d-)Y#hJrL>RhG<7@C5<H|_=Cau:5aj5@B932:bJ|ng>vIbs)#?C2F|9jPv0w.vISh-MKvUaz(.!9ABbb|[5;5<H|Eg>unwfh;9:4E|YjQsBt|vjx'hYq3!(?C2F|J:2<BaY?C2F|GOu!5x,g|p{ah!-(?C2F|c9:4E|OjXuvvNr}:Rh&i[w*t|cd+U#jJvsu)vsSn~Mkfrmu9p}u7vwv]So!McW#Xa!ax5@A5aY:5;5<H|>kJv~vYrquJu3x4ib#T)2@SmZM?C2F|Bj:rmu9@xPhI(a*a#U#`a3-5Abb|L~@:RhK9:4E|0@52B5G|#C::aY?C2F|-:2<BaY?C2F|.5Jvk!a)javYrquJu3x4ia#T)2@SmYM?C2F|HAxPhH(!a#U#`a*-5Abb|4~@:RhJ9:4E|R@52B5G|F:2<BaY?C2F|Sc^#Xa2j=Qq5CJvB!-g<v{z;hhM?C2F|Zi[vrv{z;hiM?C2F|XKsA>!a)-g<v{z;h[eb?C2F|]i[vrv{z;h]eb?C2F|^iZu.vix,hZq3ah!.(?C2F|QOu!5ShXM:2<BaY?C2F|P", 13494, 2713, 49, 25, 61), Rn = /* #__PURE__ */ new Uint16Array([
	512,
	26465,
	29036,
	7,
	0,
	2,
	4,
	116,
	24638,
	116,
	24636,
	8693,
	29807,
	24610,
	621,
	1,
	0,
	0,
	3,
	112,
	24614,
	111,
	115,
	24615
]), I;
(function(e) {
	e[e.VALUE_LENGTH = 49152] = "VALUE_LENGTH", e[e.FLAG13 = 8192] = "FLAG13", e[e.BRANCH_LENGTH = 8064] = "BRANCH_LENGTH", e[e.JUMP_TABLE = 127] = "JUMP_TABLE", e[e.VALUE_MASK = 8191] = "VALUE_MASK";
})(I ||= {});
// node_modules/entities/dist/decode.js
var L;
(function(e) {
	e[e.AMP = 38] = "AMP", e[e.NUM = 35] = "NUM", e[e.SEMI = 59] = "SEMI", e[e.EQUALS = 61] = "EQUALS", e[e.ZERO = 48] = "ZERO", e[e.NINE = 57] = "NINE", e[e.LOWER_A = 97] = "LOWER_A", e[e.LOWER_X = 120] = "LOWER_X";
})(L ||= {});
var zn = 32;
function Bn(e) {
	return e - L.ZERO >>> 0 <= 9;
}
function Vn(e) {
	return (e | zn) - L.LOWER_A >>> 0 <= 5;
}
function Hn(e) {
	return (e | zn) - L.LOWER_A >>> 0 <= 25;
}
function Un(e) {
	return e === L.EQUALS || Hn(e) || Bn(e);
}
var R;
(function(e) {
	e[e.EntityStart = 0] = "EntityStart", e[e.NumericStart = 1] = "NumericStart", e[e.NumericDecimal = 2] = "NumericDecimal", e[e.NumericHex = 3] = "NumericHex", e[e.NamedEntity = 4] = "NamedEntity";
})(R ||= {});
var Wn;
(function(e) {
	e[e.Legacy = 0] = "Legacy", e[e.Strict = 1] = "Strict", e[e.Attribute = 2] = "Attribute";
})(Wn ||= {});
var Gn = class {
	decodeTree;
	emitCodePoint;
	errors;
	state = R.EntityStart;
	consumed = 1;
	result = 0;
	treeIndex = 0;
	excess = 1;
	decodeMode = Wn.Strict;
	runConsumed = 0;
	constructor(e, t, n) {
		this.decodeTree = e, this.emitCodePoint = t, this.errors = n;
	}
	startEntity(e) {
		this.decodeMode = e, this.state = R.EntityStart, this.result = 0, this.treeIndex = 0, this.excess = 1, this.consumed = 1, this.runConsumed = 0;
	}
	write(e, t) {
		switch (this.state) {
			case R.EntityStart: return e.charCodeAt(t) === L.NUM ? (this.state = R.NumericStart, this.consumed += 1, this.stateNumericStart(e, t + 1)) : (this.state = R.NamedEntity, this.stateNamedEntity(e, t));
			case R.NumericStart: return this.stateNumericStart(e, t);
			case R.NumericDecimal: return this.stateNumericDecimal(e, t);
			case R.NumericHex: return this.stateNumericHex(e, t);
			default: return this.stateNamedEntity(e, t);
		}
	}
	stateNumericStart(e, t) {
		return t >= e.length ? -1 : (e.charCodeAt(t) | zn) === L.LOWER_X ? (this.state = R.NumericHex, this.consumed += 1, this.stateNumericHex(e, t + 1)) : (this.state = R.NumericDecimal, this.stateNumericDecimal(e, t));
	}
	stateNumericHex(e, t) {
		let n = e.length, { result: r } = this, { consumed: i } = this;
		for (; t < n;) {
			let n = e.charCodeAt(t);
			if (Bn(n) || Vn(n)) {
				let e = n <= L.NINE ? n - L.ZERO : (n | zn) - L.LOWER_A + 10;
				r = r * 16 + e, i += 1, t += 1;
			} else return this.result = r, this.consumed = i, this.emitNumericEntity(n, 3);
		}
		return this.result = r, this.consumed = i, -1;
	}
	stateNumericDecimal(e, t) {
		let n = e.length, { result: r } = this, { consumed: i } = this;
		for (; t < n;) {
			let n = e.charCodeAt(t) - L.ZERO;
			if (n >>> 0 > 9) return this.result = r, this.consumed = i, this.emitNumericEntity(n + L.ZERO, 2);
			r = r * 10 + n, i += 1, t += 1;
		}
		return this.result = r, this.consumed = i, -1;
	}
	emitNumericEntity(e, t) {
		if (this.consumed <= t) return this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
		if (e === L.SEMI) this.consumed += 1;
		else if (this.decodeMode === Wn.Strict) return 0;
		return this.emitCodePoint((this.decodeTree === Rn ? Fn : Pn)(this.result), this.consumed), this.errors && (e !== L.SEMI && this.errors.missingSemicolonAfterCharacterReference(), this.errors.validateNumericCharacterReference(this.result)), this.consumed;
	}
	flushAndEmitLegacyOrReject(e, t, n, r) {
		return this.consumed = e, this.excess = t, this.result === 0 || this.decodeMode === Wn.Attribute && (r === 0 || t > 1 || Un(n)) ? 0 : this.emitNotTerminatedNamedEntity();
	}
	stateNamedEntity(e, t) {
		let { decodeTree: n } = this, r = e.length, i = this.decodeMode === Wn.Strict, { treeIndex: a } = this, { excess: o } = this, { consumed: s } = this, c = n[a];
		for (; t < r;) {
			for (; (c & (I.VALUE_LENGTH | I.FLAG13)) === 0 && (c & I.JUMP_TABLE) !== 0;) {
				let i = e.charCodeAt(t), l = c & I.JUMP_TABLE, u = (c & I.BRANCH_LENGTH) >> 7;
				if (u === 0) {
					if (i !== l) return this.flushAndEmitLegacyOrReject(s, o, i, 0);
					a += 1;
				} else {
					let e = i - l;
					if (e >>> 0 >= u) return this.flushAndEmitLegacyOrReject(s, o, i, 0);
					let t = n[a + 1 + e];
					if (t === 0) return this.flushAndEmitLegacyOrReject(s, o, i, 0);
					a = a + u + t & 65535;
				}
				if (c = n[a], t += 1, o += 1, t >= r) break;
			}
			if (t >= r) break;
			if ((c & (I.VALUE_LENGTH | I.FLAG13)) === I.FLAG13) {
				let i = (c & I.BRANCH_LENGTH) >> 7, { runConsumed: l } = this;
				if (l === 0) {
					let n = e.charCodeAt(t);
					if (n !== (c & I.JUMP_TABLE)) return this.flushAndEmitLegacyOrReject(s, o, n, 0);
					t += 1, o += 1, l = 1;
				}
				for (; l < i;) {
					if (t >= r) return this.treeIndex = a, this.excess = o, this.consumed = s, this.runConsumed = l, -1;
					let i = l - 1, c = n[a + 1 + (i >> 1)] >> ((i & 1) << 3) & 255, u = e.charCodeAt(t);
					if (u !== c) return this.runConsumed = 0, this.flushAndEmitLegacyOrReject(s, o, u, 0);
					t += 1, o += 1, l += 1;
				}
				this.runConsumed = 0, a += 1 + (i >> 1), c = n[a];
				continue;
			}
			let l = c >>> 14, u = e.charCodeAt(t);
			if (l !== 0) {
				if (!i && (c & I.FLAG13) === 0 && (this.result = a, s += o - 1, o = 1), u === L.SEMI) return this.emitNamedEntityData(a, l, s + o);
				if (l === 1) return this.flushAndEmitLegacyOrReject(s, o, u, l);
			}
			let d = Kn(n, c, a + (l || 1), u);
			if (d < 0) return this.flushAndEmitLegacyOrReject(s, o, u, l);
			a = d, c = n[a], t += 1, o += 1;
		}
		return !i && c >>> 14 && (c & I.FLAG13) === 0 && (this.result = a, s += o - 1, o = 1), this.treeIndex = a, this.excess = o, this.consumed = s, -1;
	}
	emitNotTerminatedNamedEntity() {
		let { result: e, decodeTree: t } = this, n = t[e] >>> 14;
		return this.emitNamedEntityData(e, n, this.consumed), this.errors?.missingSemicolonAfterCharacterReference(), this.consumed;
	}
	emitNamedEntityData(e, t, n) {
		let { decodeTree: r } = this;
		return this.emitCodePoint(t === 1 ? r[e] & I.VALUE_MASK : r[e + 1], n), t === 3 && this.emitCodePoint(r[e + 2], n), n;
	}
	end() {
		switch (this.state) {
			case R.NamedEntity: return this.result !== 0 && (this.decodeMode !== Wn.Attribute || this.result === this.treeIndex) ? this.emitNotTerminatedNamedEntity() : 0;
			case R.NumericDecimal: return this.emitNumericEntity(0, 2);
			case R.NumericHex: return this.emitNumericEntity(0, 3);
			case R.NumericStart: return this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
			default: return 0;
		}
	}
};
function Kn(e, t, n, r) {
	let i = (t & I.BRANCH_LENGTH) >> 7, a = t & I.JUMP_TABLE;
	if (a) {
		if (i === 0) return r === a ? n : -1;
		let t = r - a;
		if (t >>> 0 >= i) return -1;
		let o = e[n + t];
		return o === 0 ? -1 : n + i + o - 1 & 65535;
	}
	if (i === 0) return -1;
	let o = i + 1 >> 1, s = n + o + i;
	for (let t = 0; t < i; t++) {
		let i = e[n + (t >> 1)] >> ((t & 1) << 3) & 255;
		if (i === r) return s + e[n + o + t] & 65535;
		if (i > r) return -1;
	}
	return -1;
}
// node_modules/parse5/dist/common/html.js
var z;
(function(e) {
	e.HTML = "http://www.w3.org/1999/xhtml", e.MATHML = "http://www.w3.org/1998/Math/MathML", e.SVG = "http://www.w3.org/2000/svg", e.XLINK = "http://www.w3.org/1999/xlink", e.XML = "http://www.w3.org/XML/1998/namespace", e.XMLNS = "http://www.w3.org/2000/xmlns/";
})(z ||= {});
var qn;
(function(e) {
	e.TYPE = "type", e.ACTION = "action", e.ENCODING = "encoding", e.PROMPT = "prompt", e.NAME = "name", e.COLOR = "color", e.FACE = "face", e.SIZE = "size";
})(qn ||= {});
var B;
(function(e) {
	e.NO_QUIRKS = "no-quirks", e.QUIRKS = "quirks", e.LIMITED_QUIRKS = "limited-quirks";
})(B ||= {});
var V;
(function(e) {
	e.A = "a", e.ADDRESS = "address", e.ANNOTATION_XML = "annotation-xml", e.APPLET = "applet", e.AREA = "area", e.ARTICLE = "article", e.ASIDE = "aside", e.B = "b", e.BASE = "base", e.BASEFONT = "basefont", e.BGSOUND = "bgsound", e.BIG = "big", e.BLOCKQUOTE = "blockquote", e.BODY = "body", e.BR = "br", e.BUTTON = "button", e.CAPTION = "caption", e.CENTER = "center", e.CODE = "code", e.COL = "col", e.COLGROUP = "colgroup", e.DD = "dd", e.DESC = "desc", e.DETAILS = "details", e.DIALOG = "dialog", e.DIR = "dir", e.DIV = "div", e.DL = "dl", e.DT = "dt", e.EM = "em", e.EMBED = "embed", e.FIELDSET = "fieldset", e.FIGCAPTION = "figcaption", e.FIGURE = "figure", e.FONT = "font", e.FOOTER = "footer", e.FOREIGN_OBJECT = "foreignObject", e.FORM = "form", e.FRAME = "frame", e.FRAMESET = "frameset", e.H1 = "h1", e.H2 = "h2", e.H3 = "h3", e.H4 = "h4", e.H5 = "h5", e.H6 = "h6", e.HEAD = "head", e.HEADER = "header", e.HGROUP = "hgroup", e.HR = "hr", e.HTML = "html", e.I = "i", e.IMG = "img", e.IMAGE = "image", e.INPUT = "input", e.IFRAME = "iframe", e.KEYGEN = "keygen", e.LABEL = "label", e.LI = "li", e.LINK = "link", e.LISTING = "listing", e.MAIN = "main", e.MALIGNMARK = "malignmark", e.MARQUEE = "marquee", e.MATH = "math", e.MENU = "menu", e.META = "meta", e.MGLYPH = "mglyph", e.MI = "mi", e.MO = "mo", e.MN = "mn", e.MS = "ms", e.MTEXT = "mtext", e.NAV = "nav", e.NOBR = "nobr", e.NOFRAMES = "noframes", e.NOEMBED = "noembed", e.NOSCRIPT = "noscript", e.OBJECT = "object", e.OL = "ol", e.OPTGROUP = "optgroup", e.OPTION = "option", e.P = "p", e.PARAM = "param", e.PLAINTEXT = "plaintext", e.PRE = "pre", e.RB = "rb", e.RP = "rp", e.RT = "rt", e.RTC = "rtc", e.RUBY = "ruby", e.S = "s", e.SCRIPT = "script", e.SEARCH = "search", e.SECTION = "section", e.SELECT = "select", e.SOURCE = "source", e.SMALL = "small", e.SPAN = "span", e.STRIKE = "strike", e.STRONG = "strong", e.STYLE = "style", e.SUB = "sub", e.SUMMARY = "summary", e.SUP = "sup", e.TABLE = "table", e.TBODY = "tbody", e.TEMPLATE = "template", e.TEXTAREA = "textarea", e.TFOOT = "tfoot", e.TD = "td", e.TH = "th", e.THEAD = "thead", e.TITLE = "title", e.TR = "tr", e.TRACK = "track", e.TT = "tt", e.U = "u", e.UL = "ul", e.SVG = "svg", e.VAR = "var", e.WBR = "wbr", e.XMP = "xmp";
})(V ||= {});
var H;
(function(e) {
	e[e.UNKNOWN = 0] = "UNKNOWN", e[e.A = 1] = "A", e[e.ADDRESS = 2] = "ADDRESS", e[e.ANNOTATION_XML = 3] = "ANNOTATION_XML", e[e.APPLET = 4] = "APPLET", e[e.AREA = 5] = "AREA", e[e.ARTICLE = 6] = "ARTICLE", e[e.ASIDE = 7] = "ASIDE", e[e.B = 8] = "B", e[e.BASE = 9] = "BASE", e[e.BASEFONT = 10] = "BASEFONT", e[e.BGSOUND = 11] = "BGSOUND", e[e.BIG = 12] = "BIG", e[e.BLOCKQUOTE = 13] = "BLOCKQUOTE", e[e.BODY = 14] = "BODY", e[e.BR = 15] = "BR", e[e.BUTTON = 16] = "BUTTON", e[e.CAPTION = 17] = "CAPTION", e[e.CENTER = 18] = "CENTER", e[e.CODE = 19] = "CODE", e[e.COL = 20] = "COL", e[e.COLGROUP = 21] = "COLGROUP", e[e.DD = 22] = "DD", e[e.DESC = 23] = "DESC", e[e.DETAILS = 24] = "DETAILS", e[e.DIALOG = 25] = "DIALOG", e[e.DIR = 26] = "DIR", e[e.DIV = 27] = "DIV", e[e.DL = 28] = "DL", e[e.DT = 29] = "DT", e[e.EM = 30] = "EM", e[e.EMBED = 31] = "EMBED", e[e.FIELDSET = 32] = "FIELDSET", e[e.FIGCAPTION = 33] = "FIGCAPTION", e[e.FIGURE = 34] = "FIGURE", e[e.FONT = 35] = "FONT", e[e.FOOTER = 36] = "FOOTER", e[e.FOREIGN_OBJECT = 37] = "FOREIGN_OBJECT", e[e.FORM = 38] = "FORM", e[e.FRAME = 39] = "FRAME", e[e.FRAMESET = 40] = "FRAMESET", e[e.H1 = 41] = "H1", e[e.H2 = 42] = "H2", e[e.H3 = 43] = "H3", e[e.H4 = 44] = "H4", e[e.H5 = 45] = "H5", e[e.H6 = 46] = "H6", e[e.HEAD = 47] = "HEAD", e[e.HEADER = 48] = "HEADER", e[e.HGROUP = 49] = "HGROUP", e[e.HR = 50] = "HR", e[e.HTML = 51] = "HTML", e[e.I = 52] = "I", e[e.IMG = 53] = "IMG", e[e.IMAGE = 54] = "IMAGE", e[e.INPUT = 55] = "INPUT", e[e.IFRAME = 56] = "IFRAME", e[e.KEYGEN = 57] = "KEYGEN", e[e.LABEL = 58] = "LABEL", e[e.LI = 59] = "LI", e[e.LINK = 60] = "LINK", e[e.LISTING = 61] = "LISTING", e[e.MAIN = 62] = "MAIN", e[e.MALIGNMARK = 63] = "MALIGNMARK", e[e.MARQUEE = 64] = "MARQUEE", e[e.MATH = 65] = "MATH", e[e.MENU = 66] = "MENU", e[e.META = 67] = "META", e[e.MGLYPH = 68] = "MGLYPH", e[e.MI = 69] = "MI", e[e.MO = 70] = "MO", e[e.MN = 71] = "MN", e[e.MS = 72] = "MS", e[e.MTEXT = 73] = "MTEXT", e[e.NAV = 74] = "NAV", e[e.NOBR = 75] = "NOBR", e[e.NOFRAMES = 76] = "NOFRAMES", e[e.NOEMBED = 77] = "NOEMBED", e[e.NOSCRIPT = 78] = "NOSCRIPT", e[e.OBJECT = 79] = "OBJECT", e[e.OL = 80] = "OL", e[e.OPTGROUP = 81] = "OPTGROUP", e[e.OPTION = 82] = "OPTION", e[e.P = 83] = "P", e[e.PARAM = 84] = "PARAM", e[e.PLAINTEXT = 85] = "PLAINTEXT", e[e.PRE = 86] = "PRE", e[e.RB = 87] = "RB", e[e.RP = 88] = "RP", e[e.RT = 89] = "RT", e[e.RTC = 90] = "RTC", e[e.RUBY = 91] = "RUBY", e[e.S = 92] = "S", e[e.SCRIPT = 93] = "SCRIPT", e[e.SEARCH = 94] = "SEARCH", e[e.SECTION = 95] = "SECTION", e[e.SELECT = 96] = "SELECT", e[e.SOURCE = 97] = "SOURCE", e[e.SMALL = 98] = "SMALL", e[e.SPAN = 99] = "SPAN", e[e.STRIKE = 100] = "STRIKE", e[e.STRONG = 101] = "STRONG", e[e.STYLE = 102] = "STYLE", e[e.SUB = 103] = "SUB", e[e.SUMMARY = 104] = "SUMMARY", e[e.SUP = 105] = "SUP", e[e.TABLE = 106] = "TABLE", e[e.TBODY = 107] = "TBODY", e[e.TEMPLATE = 108] = "TEMPLATE", e[e.TEXTAREA = 109] = "TEXTAREA", e[e.TFOOT = 110] = "TFOOT", e[e.TD = 111] = "TD", e[e.TH = 112] = "TH", e[e.THEAD = 113] = "THEAD", e[e.TITLE = 114] = "TITLE", e[e.TR = 115] = "TR", e[e.TRACK = 116] = "TRACK", e[e.TT = 117] = "TT", e[e.U = 118] = "U", e[e.UL = 119] = "UL", e[e.SVG = 120] = "SVG", e[e.VAR = 121] = "VAR", e[e.WBR = 122] = "WBR", e[e.XMP = 123] = "XMP";
})(H ||= {});
var Jn = /* @__PURE__ */ new Map([
	[V.A, H.A],
	[V.ADDRESS, H.ADDRESS],
	[V.ANNOTATION_XML, H.ANNOTATION_XML],
	[V.APPLET, H.APPLET],
	[V.AREA, H.AREA],
	[V.ARTICLE, H.ARTICLE],
	[V.ASIDE, H.ASIDE],
	[V.B, H.B],
	[V.BASE, H.BASE],
	[V.BASEFONT, H.BASEFONT],
	[V.BGSOUND, H.BGSOUND],
	[V.BIG, H.BIG],
	[V.BLOCKQUOTE, H.BLOCKQUOTE],
	[V.BODY, H.BODY],
	[V.BR, H.BR],
	[V.BUTTON, H.BUTTON],
	[V.CAPTION, H.CAPTION],
	[V.CENTER, H.CENTER],
	[V.CODE, H.CODE],
	[V.COL, H.COL],
	[V.COLGROUP, H.COLGROUP],
	[V.DD, H.DD],
	[V.DESC, H.DESC],
	[V.DETAILS, H.DETAILS],
	[V.DIALOG, H.DIALOG],
	[V.DIR, H.DIR],
	[V.DIV, H.DIV],
	[V.DL, H.DL],
	[V.DT, H.DT],
	[V.EM, H.EM],
	[V.EMBED, H.EMBED],
	[V.FIELDSET, H.FIELDSET],
	[V.FIGCAPTION, H.FIGCAPTION],
	[V.FIGURE, H.FIGURE],
	[V.FONT, H.FONT],
	[V.FOOTER, H.FOOTER],
	[V.FOREIGN_OBJECT, H.FOREIGN_OBJECT],
	[V.FORM, H.FORM],
	[V.FRAME, H.FRAME],
	[V.FRAMESET, H.FRAMESET],
	[V.H1, H.H1],
	[V.H2, H.H2],
	[V.H3, H.H3],
	[V.H4, H.H4],
	[V.H5, H.H5],
	[V.H6, H.H6],
	[V.HEAD, H.HEAD],
	[V.HEADER, H.HEADER],
	[V.HGROUP, H.HGROUP],
	[V.HR, H.HR],
	[V.HTML, H.HTML],
	[V.I, H.I],
	[V.IMG, H.IMG],
	[V.IMAGE, H.IMAGE],
	[V.INPUT, H.INPUT],
	[V.IFRAME, H.IFRAME],
	[V.KEYGEN, H.KEYGEN],
	[V.LABEL, H.LABEL],
	[V.LI, H.LI],
	[V.LINK, H.LINK],
	[V.LISTING, H.LISTING],
	[V.MAIN, H.MAIN],
	[V.MALIGNMARK, H.MALIGNMARK],
	[V.MARQUEE, H.MARQUEE],
	[V.MATH, H.MATH],
	[V.MENU, H.MENU],
	[V.META, H.META],
	[V.MGLYPH, H.MGLYPH],
	[V.MI, H.MI],
	[V.MO, H.MO],
	[V.MN, H.MN],
	[V.MS, H.MS],
	[V.MTEXT, H.MTEXT],
	[V.NAV, H.NAV],
	[V.NOBR, H.NOBR],
	[V.NOFRAMES, H.NOFRAMES],
	[V.NOEMBED, H.NOEMBED],
	[V.NOSCRIPT, H.NOSCRIPT],
	[V.OBJECT, H.OBJECT],
	[V.OL, H.OL],
	[V.OPTGROUP, H.OPTGROUP],
	[V.OPTION, H.OPTION],
	[V.P, H.P],
	[V.PARAM, H.PARAM],
	[V.PLAINTEXT, H.PLAINTEXT],
	[V.PRE, H.PRE],
	[V.RB, H.RB],
	[V.RP, H.RP],
	[V.RT, H.RT],
	[V.RTC, H.RTC],
	[V.RUBY, H.RUBY],
	[V.S, H.S],
	[V.SCRIPT, H.SCRIPT],
	[V.SEARCH, H.SEARCH],
	[V.SECTION, H.SECTION],
	[V.SELECT, H.SELECT],
	[V.SOURCE, H.SOURCE],
	[V.SMALL, H.SMALL],
	[V.SPAN, H.SPAN],
	[V.STRIKE, H.STRIKE],
	[V.STRONG, H.STRONG],
	[V.STYLE, H.STYLE],
	[V.SUB, H.SUB],
	[V.SUMMARY, H.SUMMARY],
	[V.SUP, H.SUP],
	[V.TABLE, H.TABLE],
	[V.TBODY, H.TBODY],
	[V.TEMPLATE, H.TEMPLATE],
	[V.TEXTAREA, H.TEXTAREA],
	[V.TFOOT, H.TFOOT],
	[V.TD, H.TD],
	[V.TH, H.TH],
	[V.THEAD, H.THEAD],
	[V.TITLE, H.TITLE],
	[V.TR, H.TR],
	[V.TRACK, H.TRACK],
	[V.TT, H.TT],
	[V.U, H.U],
	[V.UL, H.UL],
	[V.SVG, H.SVG],
	[V.VAR, H.VAR],
	[V.WBR, H.WBR],
	[V.XMP, H.XMP]
]);
function Yn(e) {
	return Jn.get(e) ?? H.UNKNOWN;
}
var U = H, Xn = {
	[z.HTML]: /* @__PURE__ */ new Set([
		U.ADDRESS,
		U.APPLET,
		U.AREA,
		U.ARTICLE,
		U.ASIDE,
		U.BASE,
		U.BASEFONT,
		U.BGSOUND,
		U.BLOCKQUOTE,
		U.BODY,
		U.BR,
		U.BUTTON,
		U.CAPTION,
		U.CENTER,
		U.COL,
		U.COLGROUP,
		U.DD,
		U.DETAILS,
		U.DIR,
		U.DIV,
		U.DL,
		U.DT,
		U.EMBED,
		U.FIELDSET,
		U.FIGCAPTION,
		U.FIGURE,
		U.FOOTER,
		U.FORM,
		U.FRAME,
		U.FRAMESET,
		U.H1,
		U.H2,
		U.H3,
		U.H4,
		U.H5,
		U.H6,
		U.HEAD,
		U.HEADER,
		U.HGROUP,
		U.HR,
		U.HTML,
		U.IFRAME,
		U.IMG,
		U.INPUT,
		U.LI,
		U.LINK,
		U.LISTING,
		U.MAIN,
		U.MARQUEE,
		U.MENU,
		U.META,
		U.NAV,
		U.NOEMBED,
		U.NOFRAMES,
		U.NOSCRIPT,
		U.OBJECT,
		U.OL,
		U.P,
		U.PARAM,
		U.PLAINTEXT,
		U.PRE,
		U.SCRIPT,
		U.SECTION,
		U.SELECT,
		U.SOURCE,
		U.STYLE,
		U.SUMMARY,
		U.TABLE,
		U.TBODY,
		U.TD,
		U.TEMPLATE,
		U.TEXTAREA,
		U.TFOOT,
		U.TH,
		U.THEAD,
		U.TITLE,
		U.TR,
		U.TRACK,
		U.UL,
		U.WBR,
		U.XMP
	]),
	[z.MATHML]: /* @__PURE__ */ new Set([
		U.MI,
		U.MO,
		U.MN,
		U.MS,
		U.MTEXT,
		U.ANNOTATION_XML
	]),
	[z.SVG]: /* @__PURE__ */ new Set([
		U.TITLE,
		U.FOREIGN_OBJECT,
		U.DESC
	]),
	[z.XLINK]: /* @__PURE__ */ new Set(),
	[z.XML]: /* @__PURE__ */ new Set(),
	[z.XMLNS]: /* @__PURE__ */ new Set()
}, Zn = /* @__PURE__ */ new Set([
	U.H1,
	U.H2,
	U.H3,
	U.H4,
	U.H5,
	U.H6
]), Qn = /* @__PURE__ */ new Set([
	V.STYLE,
	V.SCRIPT,
	V.XMP,
	V.IFRAME,
	V.NOEMBED,
	V.NOFRAMES,
	V.PLAINTEXT
]);
function $n(e, t) {
	return Qn.has(e) || t && e === V.NOSCRIPT;
}
// node_modules/parse5/dist/tokenizer/index.js
var W;
(function(e) {
	e[e.DATA = 0] = "DATA", e[e.RCDATA = 1] = "RCDATA", e[e.RAWTEXT = 2] = "RAWTEXT", e[e.SCRIPT_DATA = 3] = "SCRIPT_DATA", e[e.PLAINTEXT = 4] = "PLAINTEXT", e[e.TAG_OPEN = 5] = "TAG_OPEN", e[e.END_TAG_OPEN = 6] = "END_TAG_OPEN", e[e.TAG_NAME = 7] = "TAG_NAME", e[e.RCDATA_LESS_THAN_SIGN = 8] = "RCDATA_LESS_THAN_SIGN", e[e.RCDATA_END_TAG_OPEN = 9] = "RCDATA_END_TAG_OPEN", e[e.RCDATA_END_TAG_NAME = 10] = "RCDATA_END_TAG_NAME", e[e.RAWTEXT_LESS_THAN_SIGN = 11] = "RAWTEXT_LESS_THAN_SIGN", e[e.RAWTEXT_END_TAG_OPEN = 12] = "RAWTEXT_END_TAG_OPEN", e[e.RAWTEXT_END_TAG_NAME = 13] = "RAWTEXT_END_TAG_NAME", e[e.SCRIPT_DATA_LESS_THAN_SIGN = 14] = "SCRIPT_DATA_LESS_THAN_SIGN", e[e.SCRIPT_DATA_END_TAG_OPEN = 15] = "SCRIPT_DATA_END_TAG_OPEN", e[e.SCRIPT_DATA_END_TAG_NAME = 16] = "SCRIPT_DATA_END_TAG_NAME", e[e.SCRIPT_DATA_ESCAPE_START = 17] = "SCRIPT_DATA_ESCAPE_START", e[e.SCRIPT_DATA_ESCAPE_START_DASH = 18] = "SCRIPT_DATA_ESCAPE_START_DASH", e[e.SCRIPT_DATA_ESCAPED = 19] = "SCRIPT_DATA_ESCAPED", e[e.SCRIPT_DATA_ESCAPED_DASH = 20] = "SCRIPT_DATA_ESCAPED_DASH", e[e.SCRIPT_DATA_ESCAPED_DASH_DASH = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_OPEN = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_NAME = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_START = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START", e[e.SCRIPT_DATA_DOUBLE_ESCAPED = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_END = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END", e[e.BEFORE_ATTRIBUTE_NAME = 31] = "BEFORE_ATTRIBUTE_NAME", e[e.ATTRIBUTE_NAME = 32] = "ATTRIBUTE_NAME", e[e.AFTER_ATTRIBUTE_NAME = 33] = "AFTER_ATTRIBUTE_NAME", e[e.BEFORE_ATTRIBUTE_VALUE = 34] = "BEFORE_ATTRIBUTE_VALUE", e[e.ATTRIBUTE_VALUE_DOUBLE_QUOTED = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED", e[e.ATTRIBUTE_VALUE_SINGLE_QUOTED = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED", e[e.ATTRIBUTE_VALUE_UNQUOTED = 37] = "ATTRIBUTE_VALUE_UNQUOTED", e[e.AFTER_ATTRIBUTE_VALUE_QUOTED = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED", e[e.SELF_CLOSING_START_TAG = 39] = "SELF_CLOSING_START_TAG", e[e.BOGUS_COMMENT = 40] = "BOGUS_COMMENT", e[e.MARKUP_DECLARATION_OPEN = 41] = "MARKUP_DECLARATION_OPEN", e[e.COMMENT_START = 42] = "COMMENT_START", e[e.COMMENT_START_DASH = 43] = "COMMENT_START_DASH", e[e.COMMENT = 44] = "COMMENT", e[e.COMMENT_LESS_THAN_SIGN = 45] = "COMMENT_LESS_THAN_SIGN", e[e.COMMENT_LESS_THAN_SIGN_BANG = 46] = "COMMENT_LESS_THAN_SIGN_BANG", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH", e[e.COMMENT_END_DASH = 49] = "COMMENT_END_DASH", e[e.COMMENT_END = 50] = "COMMENT_END", e[e.COMMENT_END_BANG = 51] = "COMMENT_END_BANG", e[e.DOCTYPE = 52] = "DOCTYPE", e[e.BEFORE_DOCTYPE_NAME = 53] = "BEFORE_DOCTYPE_NAME", e[e.DOCTYPE_NAME = 54] = "DOCTYPE_NAME", e[e.AFTER_DOCTYPE_NAME = 55] = "AFTER_DOCTYPE_NAME", e[e.AFTER_DOCTYPE_PUBLIC_KEYWORD = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD", e[e.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER", e[e.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_PUBLIC_IDENTIFIER = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER", e[e.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS", e[e.AFTER_DOCTYPE_SYSTEM_KEYWORD = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD", e[e.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER", e[e.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_SYSTEM_IDENTIFIER = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER", e[e.BOGUS_DOCTYPE = 67] = "BOGUS_DOCTYPE", e[e.CDATA_SECTION = 68] = "CDATA_SECTION", e[e.CDATA_SECTION_BRACKET = 69] = "CDATA_SECTION_BRACKET", e[e.CDATA_SECTION_END = 70] = "CDATA_SECTION_END", e[e.CHARACTER_REFERENCE = 71] = "CHARACTER_REFERENCE", e[e.AMBIGUOUS_AMPERSAND = 72] = "AMBIGUOUS_AMPERSAND";
})(W ||= {});
var G = {
	DATA: W.DATA,
	RCDATA: W.RCDATA,
	RAWTEXT: W.RAWTEXT,
	SCRIPT_DATA: W.SCRIPT_DATA,
	PLAINTEXT: W.PLAINTEXT,
	CDATA_SECTION: W.CDATA_SECTION
};
function er(e) {
	return e >= j.DIGIT_0 && e <= j.DIGIT_9;
}
function tr(e) {
	return e >= j.LATIN_CAPITAL_A && e <= j.LATIN_CAPITAL_Z;
}
function nr(e) {
	return e >= j.LATIN_SMALL_A && e <= j.LATIN_SMALL_Z;
}
function rr(e) {
	return nr(e) || tr(e);
}
function ir(e) {
	return rr(e) || er(e);
}
function ar(e) {
	return e + 32;
}
function or(e) {
	return e === j.SPACE || e === j.LINE_FEED || e === j.TABULATION || e === j.FORM_FEED;
}
function sr(e) {
	return or(e) || e === j.SOLIDUS || e === j.GREATER_THAN_SIGN;
}
function cr(e) {
	return e === j.NULL ? N.nullCharacterReference : e > 1114111 ? N.characterReferenceOutsideUnicodeRange : wn(e) ? N.surrogateCharacterReference : On(e) ? N.noncharacterCharacterReference : Dn(e) || e === j.CARRIAGE_RETURN ? N.controlCharacterReference : null;
}
var lr = class {
	constructor(e, t) {
		this.options = e, this.handler = t, this.paused = !1, this.inLoop = !1, this.inForeignNode = !1, this.lastStartTagName = "", this.active = !1, this.state = W.DATA, this.returnState = W.DATA, this.entityStartPos = 0, this.consumedAfterSnapshot = -1, this.currentCharacterToken = null, this.currentToken = null, this.currentAttr = {
			name: "",
			value: ""
		}, this.preprocessor = new An(t), this.currentLocation = this.getCurrentLocation(-1), this.entityDecoder = new Gn(Ln, (e, t) => {
			this.preprocessor.pos = this.entityStartPos + t - 1, this._flushCodePointConsumedAsCharacterReference(e);
		}, t.onParseError ? {
			missingSemicolonAfterCharacterReference: () => {
				this._err(N.missingSemicolonAfterCharacterReference, 1);
			},
			absenceOfDigitsInNumericCharacterReference: (e) => {
				this._err(N.absenceOfDigitsInNumericCharacterReference, this.entityStartPos - this.preprocessor.pos + e);
			},
			validateNumericCharacterReference: (e) => {
				let t = cr(e);
				t && this._err(t, 1);
			}
		} : void 0);
	}
	_err(e, t = 0) {
		var n, r;
		(r = (n = this.handler).onParseError) == null || r.call(n, this.preprocessor.getError(e, t));
	}
	getCurrentLocation(e) {
		return this.options.sourceCodeLocationInfo ? {
			startLine: this.preprocessor.line,
			startCol: this.preprocessor.col - e,
			startOffset: this.preprocessor.offset - e,
			endLine: -1,
			endCol: -1,
			endOffset: -1
		} : null;
	}
	_runParsingLoop() {
		if (!this.inLoop) {
			for (this.inLoop = !0; this.active && !this.paused;) {
				this.consumedAfterSnapshot = 0;
				let e = this._consume();
				this._ensureHibernation() || this._callState(e);
			}
			this.inLoop = !1;
		}
	}
	pause() {
		this.paused = !0;
	}
	resume(e) {
		if (!this.paused) throw Error("Parser was already resumed");
		this.paused = !1, !this.inLoop && (this._runParsingLoop(), this.paused || e?.());
	}
	write(e, t, n) {
		this.active = !0, this.preprocessor.write(e, t), this._runParsingLoop(), this.paused || n?.();
	}
	insertHtmlAtCurrentPos(e) {
		this.active = !0, this.preprocessor.insertHtmlAtCurrentPos(e), this._runParsingLoop();
	}
	_ensureHibernation() {
		return this.preprocessor.endOfChunkHit ? (this.preprocessor.retreat(this.consumedAfterSnapshot), this.consumedAfterSnapshot = 0, this.active = !1, !0) : !1;
	}
	_consume() {
		return this.consumedAfterSnapshot++, this.preprocessor.advance();
	}
	_advanceBy(e) {
		this.consumedAfterSnapshot += e;
		for (let t = 0; t < e; t++) this.preprocessor.advance();
	}
	_consumeSequenceIfMatch(e, t) {
		return this.preprocessor.startsWith(e, t) ? (this._advanceBy(e.length - 1), !0) : !1;
	}
	_createStartTagToken() {
		this.currentToken = {
			type: P.START_TAG,
			tagName: "",
			tagID: H.UNKNOWN,
			selfClosing: !1,
			ackSelfClosing: !1,
			attrs: [],
			location: this.getCurrentLocation(1)
		};
	}
	_createEndTagToken() {
		this.currentToken = {
			type: P.END_TAG,
			tagName: "",
			tagID: H.UNKNOWN,
			selfClosing: !1,
			ackSelfClosing: !1,
			attrs: [],
			location: this.getCurrentLocation(2)
		};
	}
	_createCommentToken(e) {
		this.currentToken = {
			type: P.COMMENT,
			data: "",
			location: this.getCurrentLocation(e)
		};
	}
	_createDoctypeToken(e) {
		this.currentToken = {
			type: P.DOCTYPE,
			name: e,
			forceQuirks: !1,
			publicId: null,
			systemId: null,
			location: this.currentLocation
		};
	}
	_createCharacterToken(e, t) {
		this.currentCharacterToken = {
			type: e,
			chars: t,
			location: this.currentLocation
		};
	}
	_createAttr(e) {
		this.currentAttr = {
			name: e,
			value: ""
		}, this.currentLocation = this.getCurrentLocation(0);
	}
	_leaveAttrName() {
		var e;
		let t = this.currentToken;
		if (jn(t, this.currentAttr.name) === null) {
			if (t.attrs.push(this.currentAttr), t.location && this.currentLocation) {
				let n = (e = t.location).attrs ?? (e.attrs = Object.create(null));
				n[this.currentAttr.name] = this.currentLocation, this._leaveAttrValue();
			}
		} else this._err(N.duplicateAttribute);
	}
	_leaveAttrValue() {
		this.currentLocation && (this.currentLocation.endLine = this.preprocessor.line, this.currentLocation.endCol = this.preprocessor.col, this.currentLocation.endOffset = this.preprocessor.offset);
	}
	prepareToken(e) {
		this._emitCurrentCharacterToken(e.location), this.currentToken = null, e.location && (e.location.endLine = this.preprocessor.line, e.location.endCol = this.preprocessor.col + 1, e.location.endOffset = this.preprocessor.offset + 1), this.currentLocation = this.getCurrentLocation(-1);
	}
	emitCurrentTagToken() {
		let e = this.currentToken;
		this.prepareToken(e), e.tagID = Yn(e.tagName), e.type === P.START_TAG ? (this.lastStartTagName = e.tagName, this.handler.onStartTag(e)) : (e.attrs.length > 0 && this._err(N.endTagWithAttributes), e.selfClosing && this._err(N.endTagWithTrailingSolidus), this.handler.onEndTag(e)), this.preprocessor.dropParsedChunk();
	}
	emitCurrentComment(e) {
		this.prepareToken(e), this.handler.onComment(e), this.preprocessor.dropParsedChunk();
	}
	emitCurrentDoctype(e) {
		this.prepareToken(e), this.handler.onDoctype(e), this.preprocessor.dropParsedChunk();
	}
	_emitCurrentCharacterToken(e) {
		if (this.currentCharacterToken) {
			switch (e && this.currentCharacterToken.location && (this.currentCharacterToken.location.endLine = e.startLine, this.currentCharacterToken.location.endCol = e.startCol, this.currentCharacterToken.location.endOffset = e.startOffset), this.currentCharacterToken.type) {
				case P.CHARACTER:
					this.handler.onCharacter(this.currentCharacterToken);
					break;
				case P.NULL_CHARACTER:
					this.handler.onNullCharacter(this.currentCharacterToken);
					break;
				case P.WHITESPACE_CHARACTER: this.handler.onWhitespaceCharacter(this.currentCharacterToken);
			}
			this.currentCharacterToken = null;
		}
	}
	_emitEOFToken() {
		let e = this.getCurrentLocation(0);
		e && (e.endLine = e.startLine, e.endCol = e.startCol, e.endOffset = e.startOffset), this._emitCurrentCharacterToken(e), this.handler.onEof({
			type: P.EOF,
			location: e
		}), this.active = !1;
	}
	_appendCharToCurrentCharacterToken(e, t) {
		if (this.currentCharacterToken) {
			if (this.currentCharacterToken.type === e) {
				this.currentCharacterToken.chars += t;
				return;
			}
			this.currentLocation = this.getCurrentLocation(0), this._emitCurrentCharacterToken(this.currentLocation), this.preprocessor.dropParsedChunk();
		}
		this._createCharacterToken(e, t);
	}
	_emitCodePoint(e) {
		let t = or(e) ? P.WHITESPACE_CHARACTER : e === j.NULL ? P.NULL_CHARACTER : P.CHARACTER;
		this._appendCharToCurrentCharacterToken(t, e < 65536 ? String.fromCharCode(e) : String.fromCodePoint(e));
	}
	_emitChars(e) {
		this._appendCharToCurrentCharacterToken(P.CHARACTER, e);
	}
	_startCharacterReference() {
		this.returnState = this.state, this.state = W.CHARACTER_REFERENCE, this.entityStartPos = this.preprocessor.pos, this.entityDecoder.startEntity(this._isCharacterReferenceInAttribute() ? Wn.Attribute : Wn.Legacy);
	}
	_isCharacterReferenceInAttribute() {
		return this.returnState === W.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === W.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === W.ATTRIBUTE_VALUE_UNQUOTED;
	}
	_flushCodePointConsumedAsCharacterReference(e) {
		this._isCharacterReferenceInAttribute() ? this.currentAttr.value += String.fromCodePoint(e) : this._emitCodePoint(e);
	}
	_callState(e) {
		switch (this.state) {
			case W.DATA:
				this._stateData(e);
				break;
			case W.RCDATA:
				this._stateRcdata(e);
				break;
			case W.RAWTEXT:
				this._stateRawtext(e);
				break;
			case W.SCRIPT_DATA:
				this._stateScriptData(e);
				break;
			case W.PLAINTEXT:
				this._statePlaintext(e);
				break;
			case W.TAG_OPEN:
				this._stateTagOpen(e);
				break;
			case W.END_TAG_OPEN:
				this._stateEndTagOpen(e);
				break;
			case W.TAG_NAME:
				this._stateTagName(e);
				break;
			case W.RCDATA_LESS_THAN_SIGN:
				this._stateRcdataLessThanSign(e);
				break;
			case W.RCDATA_END_TAG_OPEN:
				this._stateRcdataEndTagOpen(e);
				break;
			case W.RCDATA_END_TAG_NAME:
				this._stateRcdataEndTagName(e);
				break;
			case W.RAWTEXT_LESS_THAN_SIGN:
				this._stateRawtextLessThanSign(e);
				break;
			case W.RAWTEXT_END_TAG_OPEN:
				this._stateRawtextEndTagOpen(e);
				break;
			case W.RAWTEXT_END_TAG_NAME:
				this._stateRawtextEndTagName(e);
				break;
			case W.SCRIPT_DATA_LESS_THAN_SIGN:
				this._stateScriptDataLessThanSign(e);
				break;
			case W.SCRIPT_DATA_END_TAG_OPEN:
				this._stateScriptDataEndTagOpen(e);
				break;
			case W.SCRIPT_DATA_END_TAG_NAME:
				this._stateScriptDataEndTagName(e);
				break;
			case W.SCRIPT_DATA_ESCAPE_START:
				this._stateScriptDataEscapeStart(e);
				break;
			case W.SCRIPT_DATA_ESCAPE_START_DASH:
				this._stateScriptDataEscapeStartDash(e);
				break;
			case W.SCRIPT_DATA_ESCAPED:
				this._stateScriptDataEscaped(e);
				break;
			case W.SCRIPT_DATA_ESCAPED_DASH:
				this._stateScriptDataEscapedDash(e);
				break;
			case W.SCRIPT_DATA_ESCAPED_DASH_DASH:
				this._stateScriptDataEscapedDashDash(e);
				break;
			case W.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN:
				this._stateScriptDataEscapedLessThanSign(e);
				break;
			case W.SCRIPT_DATA_ESCAPED_END_TAG_OPEN:
				this._stateScriptDataEscapedEndTagOpen(e);
				break;
			case W.SCRIPT_DATA_ESCAPED_END_TAG_NAME:
				this._stateScriptDataEscapedEndTagName(e);
				break;
			case W.SCRIPT_DATA_DOUBLE_ESCAPE_START:
				this._stateScriptDataDoubleEscapeStart(e);
				break;
			case W.SCRIPT_DATA_DOUBLE_ESCAPED:
				this._stateScriptDataDoubleEscaped(e);
				break;
			case W.SCRIPT_DATA_DOUBLE_ESCAPED_DASH:
				this._stateScriptDataDoubleEscapedDash(e);
				break;
			case W.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH:
				this._stateScriptDataDoubleEscapedDashDash(e);
				break;
			case W.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN:
				this._stateScriptDataDoubleEscapedLessThanSign(e);
				break;
			case W.SCRIPT_DATA_DOUBLE_ESCAPE_END:
				this._stateScriptDataDoubleEscapeEnd(e);
				break;
			case W.BEFORE_ATTRIBUTE_NAME:
				this._stateBeforeAttributeName(e);
				break;
			case W.ATTRIBUTE_NAME:
				this._stateAttributeName(e);
				break;
			case W.AFTER_ATTRIBUTE_NAME:
				this._stateAfterAttributeName(e);
				break;
			case W.BEFORE_ATTRIBUTE_VALUE:
				this._stateBeforeAttributeValue(e);
				break;
			case W.ATTRIBUTE_VALUE_DOUBLE_QUOTED:
				this._stateAttributeValueDoubleQuoted(e);
				break;
			case W.ATTRIBUTE_VALUE_SINGLE_QUOTED:
				this._stateAttributeValueSingleQuoted(e);
				break;
			case W.ATTRIBUTE_VALUE_UNQUOTED:
				this._stateAttributeValueUnquoted(e);
				break;
			case W.AFTER_ATTRIBUTE_VALUE_QUOTED:
				this._stateAfterAttributeValueQuoted(e);
				break;
			case W.SELF_CLOSING_START_TAG:
				this._stateSelfClosingStartTag(e);
				break;
			case W.BOGUS_COMMENT:
				this._stateBogusComment(e);
				break;
			case W.MARKUP_DECLARATION_OPEN:
				this._stateMarkupDeclarationOpen(e);
				break;
			case W.COMMENT_START:
				this._stateCommentStart(e);
				break;
			case W.COMMENT_START_DASH:
				this._stateCommentStartDash(e);
				break;
			case W.COMMENT:
				this._stateComment(e);
				break;
			case W.COMMENT_LESS_THAN_SIGN:
				this._stateCommentLessThanSign(e);
				break;
			case W.COMMENT_LESS_THAN_SIGN_BANG:
				this._stateCommentLessThanSignBang(e);
				break;
			case W.COMMENT_LESS_THAN_SIGN_BANG_DASH:
				this._stateCommentLessThanSignBangDash(e);
				break;
			case W.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH:
				this._stateCommentLessThanSignBangDashDash(e);
				break;
			case W.COMMENT_END_DASH:
				this._stateCommentEndDash(e);
				break;
			case W.COMMENT_END:
				this._stateCommentEnd(e);
				break;
			case W.COMMENT_END_BANG:
				this._stateCommentEndBang(e);
				break;
			case W.DOCTYPE:
				this._stateDoctype(e);
				break;
			case W.BEFORE_DOCTYPE_NAME:
				this._stateBeforeDoctypeName(e);
				break;
			case W.DOCTYPE_NAME:
				this._stateDoctypeName(e);
				break;
			case W.AFTER_DOCTYPE_NAME:
				this._stateAfterDoctypeName(e);
				break;
			case W.AFTER_DOCTYPE_PUBLIC_KEYWORD:
				this._stateAfterDoctypePublicKeyword(e);
				break;
			case W.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER:
				this._stateBeforeDoctypePublicIdentifier(e);
				break;
			case W.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED:
				this._stateDoctypePublicIdentifierDoubleQuoted(e);
				break;
			case W.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED:
				this._stateDoctypePublicIdentifierSingleQuoted(e);
				break;
			case W.AFTER_DOCTYPE_PUBLIC_IDENTIFIER:
				this._stateAfterDoctypePublicIdentifier(e);
				break;
			case W.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS:
				this._stateBetweenDoctypePublicAndSystemIdentifiers(e);
				break;
			case W.AFTER_DOCTYPE_SYSTEM_KEYWORD:
				this._stateAfterDoctypeSystemKeyword(e);
				break;
			case W.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER:
				this._stateBeforeDoctypeSystemIdentifier(e);
				break;
			case W.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED:
				this._stateDoctypeSystemIdentifierDoubleQuoted(e);
				break;
			case W.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED:
				this._stateDoctypeSystemIdentifierSingleQuoted(e);
				break;
			case W.AFTER_DOCTYPE_SYSTEM_IDENTIFIER:
				this._stateAfterDoctypeSystemIdentifier(e);
				break;
			case W.BOGUS_DOCTYPE:
				this._stateBogusDoctype(e);
				break;
			case W.CDATA_SECTION:
				this._stateCdataSection(e);
				break;
			case W.CDATA_SECTION_BRACKET:
				this._stateCdataSectionBracket(e);
				break;
			case W.CDATA_SECTION_END:
				this._stateCdataSectionEnd(e);
				break;
			case W.CHARACTER_REFERENCE:
				this._stateCharacterReference();
				break;
			case W.AMBIGUOUS_AMPERSAND:
				this._stateAmbiguousAmpersand(e);
				break;
			default: throw Error("Unknown state");
		}
	}
	_stateData(e) {
		switch (e) {
			case j.LESS_THAN_SIGN:
				this.state = W.TAG_OPEN;
				break;
			case j.AMPERSAND:
				this._startCharacterReference();
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this._emitCodePoint(e);
				break;
			case j.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateRcdata(e) {
		switch (e) {
			case j.AMPERSAND:
				this._startCharacterReference();
				break;
			case j.LESS_THAN_SIGN:
				this.state = W.RCDATA_LESS_THAN_SIGN;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this._emitChars("�");
				break;
			case j.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateRawtext(e) {
		switch (e) {
			case j.LESS_THAN_SIGN:
				this.state = W.RAWTEXT_LESS_THAN_SIGN;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this._emitChars("�");
				break;
			case j.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptData(e) {
		switch (e) {
			case j.LESS_THAN_SIGN:
				this.state = W.SCRIPT_DATA_LESS_THAN_SIGN;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this._emitChars("�");
				break;
			case j.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_statePlaintext(e) {
		switch (e) {
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this._emitChars("�");
				break;
			case j.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateTagOpen(e) {
		if (rr(e)) this._createStartTagToken(), this.state = W.TAG_NAME, this._stateTagName(e);
		else switch (e) {
			case j.EXCLAMATION_MARK:
				this.state = W.MARKUP_DECLARATION_OPEN;
				break;
			case j.SOLIDUS:
				this.state = W.END_TAG_OPEN;
				break;
			case j.QUESTION_MARK:
				this._err(N.unexpectedQuestionMarkInsteadOfTagName), this._createCommentToken(1), this.state = W.BOGUS_COMMENT, this._stateBogusComment(e);
				break;
			case j.EOF:
				this._err(N.eofBeforeTagName), this._emitChars("<"), this._emitEOFToken();
				break;
			default: this._err(N.invalidFirstCharacterOfTagName), this._emitChars("<"), this.state = W.DATA, this._stateData(e);
		}
	}
	_stateEndTagOpen(e) {
		if (rr(e)) this._createEndTagToken(), this.state = W.TAG_NAME, this._stateTagName(e);
		else switch (e) {
			case j.GREATER_THAN_SIGN:
				this._err(N.missingEndTagName), this.state = W.DATA;
				break;
			case j.EOF:
				this._err(N.eofBeforeTagName), this._emitChars("</"), this._emitEOFToken();
				break;
			default: this._err(N.invalidFirstCharacterOfTagName), this._createCommentToken(2), this.state = W.BOGUS_COMMENT, this._stateBogusComment(e);
		}
	}
	_stateTagName(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED:
				this.state = W.BEFORE_ATTRIBUTE_NAME;
				break;
			case j.SOLIDUS:
				this.state = W.SELF_CLOSING_START_TAG;
				break;
			case j.GREATER_THAN_SIGN:
				this.state = W.DATA, this.emitCurrentTagToken();
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), t.tagName += "�";
				break;
			case j.EOF:
				this._err(N.eofInTag), this._emitEOFToken();
				break;
			default: t.tagName += String.fromCodePoint(tr(e) ? ar(e) : e);
		}
	}
	_stateRcdataLessThanSign(e) {
		e === j.SOLIDUS ? this.state = W.RCDATA_END_TAG_OPEN : (this._emitChars("<"), this.state = W.RCDATA, this._stateRcdata(e));
	}
	_stateRcdataEndTagOpen(e) {
		rr(e) ? (this.state = W.RCDATA_END_TAG_NAME, this._stateRcdataEndTagName(e)) : (this._emitChars("</"), this.state = W.RCDATA, this._stateRcdata(e));
	}
	handleSpecialEndTag(e) {
		if (!this.preprocessor.startsWith(this.lastStartTagName, !1)) return !this._ensureHibernation();
		this._createEndTagToken();
		let t = this.currentToken;
		switch (t.tagName = this.lastStartTagName, this.preprocessor.peek(this.lastStartTagName.length)) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: return this._advanceBy(this.lastStartTagName.length), this.state = W.BEFORE_ATTRIBUTE_NAME, !1;
			case j.SOLIDUS: return this._advanceBy(this.lastStartTagName.length), this.state = W.SELF_CLOSING_START_TAG, !1;
			case j.GREATER_THAN_SIGN: return this._advanceBy(this.lastStartTagName.length), this.emitCurrentTagToken(), this.state = W.DATA, !1;
			default: return !this._ensureHibernation();
		}
	}
	_stateRcdataEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = W.RCDATA, this._stateRcdata(e));
	}
	_stateRawtextLessThanSign(e) {
		e === j.SOLIDUS ? this.state = W.RAWTEXT_END_TAG_OPEN : (this._emitChars("<"), this.state = W.RAWTEXT, this._stateRawtext(e));
	}
	_stateRawtextEndTagOpen(e) {
		rr(e) ? (this.state = W.RAWTEXT_END_TAG_NAME, this._stateRawtextEndTagName(e)) : (this._emitChars("</"), this.state = W.RAWTEXT, this._stateRawtext(e));
	}
	_stateRawtextEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = W.RAWTEXT, this._stateRawtext(e));
	}
	_stateScriptDataLessThanSign(e) {
		switch (e) {
			case j.SOLIDUS:
				this.state = W.SCRIPT_DATA_END_TAG_OPEN;
				break;
			case j.EXCLAMATION_MARK:
				this.state = W.SCRIPT_DATA_ESCAPE_START, this._emitChars("<!");
				break;
			default: this._emitChars("<"), this.state = W.SCRIPT_DATA, this._stateScriptData(e);
		}
	}
	_stateScriptDataEndTagOpen(e) {
		rr(e) ? (this.state = W.SCRIPT_DATA_END_TAG_NAME, this._stateScriptDataEndTagName(e)) : (this._emitChars("</"), this.state = W.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = W.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscapeStart(e) {
		e === j.HYPHEN_MINUS ? (this.state = W.SCRIPT_DATA_ESCAPE_START_DASH, this._emitChars("-")) : (this.state = W.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscapeStartDash(e) {
		e === j.HYPHEN_MINUS ? (this.state = W.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-")) : (this.state = W.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscaped(e) {
		switch (e) {
			case j.HYPHEN_MINUS:
				this.state = W.SCRIPT_DATA_ESCAPED_DASH, this._emitChars("-");
				break;
			case j.LESS_THAN_SIGN:
				this.state = W.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this._emitChars("�");
				break;
			case j.EOF:
				this._err(N.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedDash(e) {
		switch (e) {
			case j.HYPHEN_MINUS:
				this.state = W.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-");
				break;
			case j.LESS_THAN_SIGN:
				this.state = W.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this.state = W.SCRIPT_DATA_ESCAPED, this._emitChars("�");
				break;
			case j.EOF:
				this._err(N.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = W.SCRIPT_DATA_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedDashDash(e) {
		switch (e) {
			case j.HYPHEN_MINUS:
				this._emitChars("-");
				break;
			case j.LESS_THAN_SIGN:
				this.state = W.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case j.GREATER_THAN_SIGN:
				this.state = W.SCRIPT_DATA, this._emitChars(">");
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this.state = W.SCRIPT_DATA_ESCAPED, this._emitChars("�");
				break;
			case j.EOF:
				this._err(N.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = W.SCRIPT_DATA_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedLessThanSign(e) {
		e === j.SOLIDUS ? this.state = W.SCRIPT_DATA_ESCAPED_END_TAG_OPEN : rr(e) ? (this._emitChars("<"), this.state = W.SCRIPT_DATA_DOUBLE_ESCAPE_START, this._stateScriptDataDoubleEscapeStart(e)) : (this._emitChars("<"), this.state = W.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataEscapedEndTagOpen(e) {
		rr(e) ? (this.state = W.SCRIPT_DATA_ESCAPED_END_TAG_NAME, this._stateScriptDataEscapedEndTagName(e)) : (this._emitChars("</"), this.state = W.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataEscapedEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = W.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataDoubleEscapeStart(e) {
		if (this.preprocessor.startsWith(M.SCRIPT, !1) && sr(this.preprocessor.peek(M.SCRIPT.length))) {
			this._emitCodePoint(e);
			for (let e = 0; e < M.SCRIPT.length; e++) this._emitCodePoint(this._consume());
			this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED;
		} else this._ensureHibernation() || (this.state = W.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataDoubleEscaped(e) {
		switch (e) {
			case j.HYPHEN_MINUS:
				this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED_DASH, this._emitChars("-");
				break;
			case j.LESS_THAN_SIGN:
				this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this._emitChars("�");
				break;
			case j.EOF:
				this._err(N.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedDash(e) {
		switch (e) {
			case j.HYPHEN_MINUS:
				this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH, this._emitChars("-");
				break;
			case j.LESS_THAN_SIGN:
				this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars("�");
				break;
			case j.EOF:
				this._err(N.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedDashDash(e) {
		switch (e) {
			case j.HYPHEN_MINUS:
				this._emitChars("-");
				break;
			case j.LESS_THAN_SIGN:
				this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case j.GREATER_THAN_SIGN:
				this.state = W.SCRIPT_DATA, this._emitChars(">");
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars("�");
				break;
			case j.EOF:
				this._err(N.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedLessThanSign(e) {
		e === j.SOLIDUS ? (this.state = W.SCRIPT_DATA_DOUBLE_ESCAPE_END, this._emitChars("/")) : (this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e));
	}
	_stateScriptDataDoubleEscapeEnd(e) {
		if (this.preprocessor.startsWith(M.SCRIPT, !1) && sr(this.preprocessor.peek(M.SCRIPT.length))) {
			this._emitCodePoint(e);
			for (let e = 0; e < M.SCRIPT.length; e++) this._emitCodePoint(this._consume());
			this.state = W.SCRIPT_DATA_ESCAPED;
		} else this._ensureHibernation() || (this.state = W.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e));
	}
	_stateBeforeAttributeName(e) {
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: break;
			case j.SOLIDUS:
			case j.GREATER_THAN_SIGN:
			case j.EOF:
				this.state = W.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(e);
				break;
			case j.EQUALS_SIGN:
				this._err(N.unexpectedEqualsSignBeforeAttributeName), this._createAttr("="), this.state = W.ATTRIBUTE_NAME;
				break;
			default: this._createAttr(""), this.state = W.ATTRIBUTE_NAME, this._stateAttributeName(e);
		}
	}
	_stateAttributeName(e) {
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED:
			case j.SOLIDUS:
			case j.GREATER_THAN_SIGN:
			case j.EOF:
				this._leaveAttrName(), this.state = W.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(e);
				break;
			case j.EQUALS_SIGN:
				this._leaveAttrName(), this.state = W.BEFORE_ATTRIBUTE_VALUE;
				break;
			case j.QUOTATION_MARK:
			case j.APOSTROPHE:
			case j.LESS_THAN_SIGN:
				this._err(N.unexpectedCharacterInAttributeName), this.currentAttr.name += String.fromCodePoint(e);
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this.currentAttr.name += "�";
				break;
			default: this.currentAttr.name += String.fromCodePoint(tr(e) ? ar(e) : e);
		}
	}
	_stateAfterAttributeName(e) {
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: break;
			case j.SOLIDUS:
				this.state = W.SELF_CLOSING_START_TAG;
				break;
			case j.EQUALS_SIGN:
				this.state = W.BEFORE_ATTRIBUTE_VALUE;
				break;
			case j.GREATER_THAN_SIGN:
				this.state = W.DATA, this.emitCurrentTagToken();
				break;
			case j.EOF:
				this._err(N.eofInTag), this._emitEOFToken();
				break;
			default: this._createAttr(""), this.state = W.ATTRIBUTE_NAME, this._stateAttributeName(e);
		}
	}
	_stateBeforeAttributeValue(e) {
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: break;
			case j.QUOTATION_MARK:
				this.state = W.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
				break;
			case j.APOSTROPHE:
				this.state = W.ATTRIBUTE_VALUE_SINGLE_QUOTED;
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.missingAttributeValue), this.state = W.DATA, this.emitCurrentTagToken();
				break;
			default: this.state = W.ATTRIBUTE_VALUE_UNQUOTED, this._stateAttributeValueUnquoted(e);
		}
	}
	_stateAttributeValueDoubleQuoted(e) {
		switch (e) {
			case j.QUOTATION_MARK:
				this.state = W.AFTER_ATTRIBUTE_VALUE_QUOTED;
				break;
			case j.AMPERSAND:
				this._startCharacterReference();
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this.currentAttr.value += "�";
				break;
			case j.EOF:
				this._err(N.eofInTag), this._emitEOFToken();
				break;
			default: this.currentAttr.value += String.fromCodePoint(e);
		}
	}
	_stateAttributeValueSingleQuoted(e) {
		switch (e) {
			case j.APOSTROPHE:
				this.state = W.AFTER_ATTRIBUTE_VALUE_QUOTED;
				break;
			case j.AMPERSAND:
				this._startCharacterReference();
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this.currentAttr.value += "�";
				break;
			case j.EOF:
				this._err(N.eofInTag), this._emitEOFToken();
				break;
			default: this.currentAttr.value += String.fromCodePoint(e);
		}
	}
	_stateAttributeValueUnquoted(e) {
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED:
				this._leaveAttrValue(), this.state = W.BEFORE_ATTRIBUTE_NAME;
				break;
			case j.AMPERSAND:
				this._startCharacterReference();
				break;
			case j.GREATER_THAN_SIGN:
				this._leaveAttrValue(), this.state = W.DATA, this.emitCurrentTagToken();
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this.currentAttr.value += "�";
				break;
			case j.QUOTATION_MARK:
			case j.APOSTROPHE:
			case j.LESS_THAN_SIGN:
			case j.EQUALS_SIGN:
			case j.GRAVE_ACCENT:
				this._err(N.unexpectedCharacterInUnquotedAttributeValue), this.currentAttr.value += String.fromCodePoint(e);
				break;
			case j.EOF:
				this._err(N.eofInTag), this._emitEOFToken();
				break;
			default: this.currentAttr.value += String.fromCodePoint(e);
		}
	}
	_stateAfterAttributeValueQuoted(e) {
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED:
				this._leaveAttrValue(), this.state = W.BEFORE_ATTRIBUTE_NAME;
				break;
			case j.SOLIDUS:
				this._leaveAttrValue(), this.state = W.SELF_CLOSING_START_TAG;
				break;
			case j.GREATER_THAN_SIGN:
				this._leaveAttrValue(), this.state = W.DATA, this.emitCurrentTagToken();
				break;
			case j.EOF:
				this._err(N.eofInTag), this._emitEOFToken();
				break;
			default: this._err(N.missingWhitespaceBetweenAttributes), this.state = W.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(e);
		}
	}
	_stateSelfClosingStartTag(e) {
		switch (e) {
			case j.GREATER_THAN_SIGN: {
				let e = this.currentToken;
				e.selfClosing = !0, this.state = W.DATA, this.emitCurrentTagToken();
				break;
			}
			case j.EOF:
				this._err(N.eofInTag), this._emitEOFToken();
				break;
			default: this._err(N.unexpectedSolidusInTag), this.state = W.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(e);
		}
	}
	_stateBogusComment(e) {
		let t = this.currentToken;
		switch (e) {
			case j.GREATER_THAN_SIGN:
				this.state = W.DATA, this.emitCurrentComment(t);
				break;
			case j.EOF:
				this.emitCurrentComment(t), this._emitEOFToken();
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), t.data += "�";
				break;
			default: t.data += String.fromCodePoint(e);
		}
	}
	_stateMarkupDeclarationOpen(e) {
		this._consumeSequenceIfMatch(M.DASH_DASH, !0) ? (this._createCommentToken(M.DASH_DASH.length + 1), this.state = W.COMMENT_START) : this._consumeSequenceIfMatch(M.DOCTYPE, !1) ? (this.currentLocation = this.getCurrentLocation(M.DOCTYPE.length + 1), this.state = W.DOCTYPE) : this._consumeSequenceIfMatch(M.CDATA_START, !0) ? this.inForeignNode ? this.state = W.CDATA_SECTION : (this._err(N.cdataInHtmlContent), this._createCommentToken(M.CDATA_START.length + 1), this.currentToken.data = "[CDATA[", this.state = W.BOGUS_COMMENT) : this._ensureHibernation() || (this._err(N.incorrectlyOpenedComment), this._createCommentToken(2), this.state = W.BOGUS_COMMENT, this._stateBogusComment(e));
	}
	_stateCommentStart(e) {
		switch (e) {
			case j.HYPHEN_MINUS:
				this.state = W.COMMENT_START_DASH;
				break;
			case j.GREATER_THAN_SIGN: {
				this._err(N.abruptClosingOfEmptyComment), this.state = W.DATA;
				let e = this.currentToken;
				this.emitCurrentComment(e);
				break;
			}
			default: this.state = W.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentStartDash(e) {
		let t = this.currentToken;
		switch (e) {
			case j.HYPHEN_MINUS:
				this.state = W.COMMENT_END;
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.abruptClosingOfEmptyComment), this.state = W.DATA, this.emitCurrentComment(t);
				break;
			case j.EOF:
				this._err(N.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += "-", this.state = W.COMMENT, this._stateComment(e);
		}
	}
	_stateComment(e) {
		let t = this.currentToken;
		switch (e) {
			case j.HYPHEN_MINUS:
				this.state = W.COMMENT_END_DASH;
				break;
			case j.LESS_THAN_SIGN:
				t.data += "<", this.state = W.COMMENT_LESS_THAN_SIGN;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), t.data += "�";
				break;
			case j.EOF:
				this._err(N.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += String.fromCodePoint(e);
		}
	}
	_stateCommentLessThanSign(e) {
		let t = this.currentToken;
		switch (e) {
			case j.EXCLAMATION_MARK:
				t.data += "!", this.state = W.COMMENT_LESS_THAN_SIGN_BANG;
				break;
			case j.LESS_THAN_SIGN:
				t.data += "<";
				break;
			default: this.state = W.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentLessThanSignBang(e) {
		e === j.HYPHEN_MINUS ? this.state = W.COMMENT_LESS_THAN_SIGN_BANG_DASH : (this.state = W.COMMENT, this._stateComment(e));
	}
	_stateCommentLessThanSignBangDash(e) {
		e === j.HYPHEN_MINUS ? this.state = W.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH : (this.state = W.COMMENT_END_DASH, this._stateCommentEndDash(e));
	}
	_stateCommentLessThanSignBangDashDash(e) {
		e !== j.GREATER_THAN_SIGN && e !== j.EOF && this._err(N.nestedComment), this.state = W.COMMENT_END, this._stateCommentEnd(e);
	}
	_stateCommentEndDash(e) {
		let t = this.currentToken;
		switch (e) {
			case j.HYPHEN_MINUS:
				this.state = W.COMMENT_END;
				break;
			case j.EOF:
				this._err(N.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += "-", this.state = W.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentEnd(e) {
		let t = this.currentToken;
		switch (e) {
			case j.GREATER_THAN_SIGN:
				this.state = W.DATA, this.emitCurrentComment(t);
				break;
			case j.EXCLAMATION_MARK:
				this.state = W.COMMENT_END_BANG;
				break;
			case j.HYPHEN_MINUS:
				t.data += "-";
				break;
			case j.EOF:
				this._err(N.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += "--", this.state = W.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentEndBang(e) {
		let t = this.currentToken;
		switch (e) {
			case j.HYPHEN_MINUS:
				t.data += "--!", this.state = W.COMMENT_END_DASH;
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.incorrectlyClosedComment), this.state = W.DATA, this.emitCurrentComment(t);
				break;
			case j.EOF:
				this._err(N.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += "--!", this.state = W.COMMENT, this._stateComment(e);
		}
	}
	_stateDoctype(e) {
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED:
				this.state = W.BEFORE_DOCTYPE_NAME;
				break;
			case j.GREATER_THAN_SIGN:
				this.state = W.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(e);
				break;
			case j.EOF: {
				this._err(N.eofInDoctype), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this._emitEOFToken();
				break;
			}
			default: this._err(N.missingWhitespaceBeforeDoctypeName), this.state = W.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(e);
		}
	}
	_stateBeforeDoctypeName(e) {
		if (tr(e)) this._createDoctypeToken(String.fromCharCode(ar(e))), this.state = W.DOCTYPE_NAME;
		else switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), this._createDoctypeToken("�"), this.state = W.DOCTYPE_NAME;
				break;
			case j.GREATER_THAN_SIGN: {
				this._err(N.missingDoctypeName), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this.state = W.DATA;
				break;
			}
			case j.EOF: {
				this._err(N.eofInDoctype), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this._emitEOFToken();
				break;
			}
			default: this._createDoctypeToken(String.fromCodePoint(e)), this.state = W.DOCTYPE_NAME;
		}
	}
	_stateDoctypeName(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED:
				this.state = W.AFTER_DOCTYPE_NAME;
				break;
			case j.GREATER_THAN_SIGN:
				this.state = W.DATA, this.emitCurrentDoctype(t);
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), t.name += "�";
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.name += String.fromCodePoint(tr(e) ? ar(e) : e);
		}
	}
	_stateAfterDoctypeName(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: break;
			case j.GREATER_THAN_SIGN:
				this.state = W.DATA, this.emitCurrentDoctype(t);
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._consumeSequenceIfMatch(M.PUBLIC, !1) ? this.state = W.AFTER_DOCTYPE_PUBLIC_KEYWORD : this._consumeSequenceIfMatch(M.SYSTEM, !1) ? this.state = W.AFTER_DOCTYPE_SYSTEM_KEYWORD : this._ensureHibernation() || (this._err(N.invalidCharacterSequenceAfterDoctypeName), t.forceQuirks = !0, this.state = W.BOGUS_DOCTYPE, this._stateBogusDoctype(e));
		}
	}
	_stateAfterDoctypePublicKeyword(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED:
				this.state = W.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case j.QUOTATION_MARK:
				this._err(N.missingWhitespaceAfterDoctypePublicKeyword), t.publicId = "", this.state = W.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case j.APOSTROPHE:
				this._err(N.missingWhitespaceAfterDoctypePublicKeyword), t.publicId = "", this.state = W.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.missingDoctypePublicIdentifier), t.forceQuirks = !0, this.state = W.DATA, this.emitCurrentDoctype(t);
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(N.missingQuoteBeforeDoctypePublicIdentifier), t.forceQuirks = !0, this.state = W.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBeforeDoctypePublicIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: break;
			case j.QUOTATION_MARK:
				t.publicId = "", this.state = W.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case j.APOSTROPHE:
				t.publicId = "", this.state = W.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.missingDoctypePublicIdentifier), t.forceQuirks = !0, this.state = W.DATA, this.emitCurrentDoctype(t);
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(N.missingQuoteBeforeDoctypePublicIdentifier), t.forceQuirks = !0, this.state = W.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateDoctypePublicIdentifierDoubleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case j.QUOTATION_MARK:
				this.state = W.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), t.publicId += "�";
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.abruptDoctypePublicIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = W.DATA;
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.publicId += String.fromCodePoint(e);
		}
	}
	_stateDoctypePublicIdentifierSingleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case j.APOSTROPHE:
				this.state = W.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), t.publicId += "�";
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.abruptDoctypePublicIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = W.DATA;
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.publicId += String.fromCodePoint(e);
		}
	}
	_stateAfterDoctypePublicIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED:
				this.state = W.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
				break;
			case j.GREATER_THAN_SIGN:
				this.state = W.DATA, this.emitCurrentDoctype(t);
				break;
			case j.QUOTATION_MARK:
				this._err(N.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), t.systemId = "", this.state = W.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case j.APOSTROPHE:
				this._err(N.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), t.systemId = "", this.state = W.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(N.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = W.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBetweenDoctypePublicAndSystemIdentifiers(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: break;
			case j.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(t), this.state = W.DATA;
				break;
			case j.QUOTATION_MARK:
				t.systemId = "", this.state = W.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case j.APOSTROPHE:
				t.systemId = "", this.state = W.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(N.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = W.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateAfterDoctypeSystemKeyword(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED:
				this.state = W.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case j.QUOTATION_MARK:
				this._err(N.missingWhitespaceAfterDoctypeSystemKeyword), t.systemId = "", this.state = W.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case j.APOSTROPHE:
				this._err(N.missingWhitespaceAfterDoctypeSystemKeyword), t.systemId = "", this.state = W.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.missingDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = W.DATA, this.emitCurrentDoctype(t);
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(N.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = W.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBeforeDoctypeSystemIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: break;
			case j.QUOTATION_MARK:
				t.systemId = "", this.state = W.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case j.APOSTROPHE:
				t.systemId = "", this.state = W.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.missingDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = W.DATA, this.emitCurrentDoctype(t);
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(N.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = W.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateDoctypeSystemIdentifierDoubleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case j.QUOTATION_MARK:
				this.state = W.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), t.systemId += "�";
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.abruptDoctypeSystemIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = W.DATA;
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.systemId += String.fromCodePoint(e);
		}
	}
	_stateDoctypeSystemIdentifierSingleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case j.APOSTROPHE:
				this.state = W.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter), t.systemId += "�";
				break;
			case j.GREATER_THAN_SIGN:
				this._err(N.abruptDoctypeSystemIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = W.DATA;
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.systemId += String.fromCodePoint(e);
		}
	}
	_stateAfterDoctypeSystemIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case j.SPACE:
			case j.LINE_FEED:
			case j.TABULATION:
			case j.FORM_FEED: break;
			case j.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(t), this.state = W.DATA;
				break;
			case j.EOF:
				this._err(N.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(N.unexpectedCharacterAfterDoctypeSystemIdentifier), this.state = W.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBogusDoctype(e) {
		let t = this.currentToken;
		switch (e) {
			case j.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(t), this.state = W.DATA;
				break;
			case j.NULL:
				this._err(N.unexpectedNullCharacter);
				break;
			case j.EOF: this.emitCurrentDoctype(t), this._emitEOFToken();
		}
	}
	_stateCdataSection(e) {
		switch (e) {
			case j.RIGHT_SQUARE_BRACKET:
				this.state = W.CDATA_SECTION_BRACKET;
				break;
			case j.EOF:
				this._err(N.eofInCdata), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateCdataSectionBracket(e) {
		e === j.RIGHT_SQUARE_BRACKET ? this.state = W.CDATA_SECTION_END : (this._emitChars("]"), this.state = W.CDATA_SECTION, this._stateCdataSection(e));
	}
	_stateCdataSectionEnd(e) {
		switch (e) {
			case j.GREATER_THAN_SIGN:
				this.state = W.DATA;
				break;
			case j.RIGHT_SQUARE_BRACKET:
				this._emitChars("]");
				break;
			default: this._emitChars("]]"), this.state = W.CDATA_SECTION, this._stateCdataSection(e);
		}
	}
	_stateCharacterReference() {
		let e = this.entityDecoder.write(this.preprocessor.html, this.preprocessor.pos);
		if (e < 0) {
			if (this.preprocessor.lastChunkWritten) e = this.entityDecoder.end();
			else {
				this.active = !1, this.preprocessor.pos = this.preprocessor.html.length - 1, this.consumedAfterSnapshot = 0, this.preprocessor.endOfChunkHit = !0;
				return;
			}
		}
		e === 0 ? (this.preprocessor.pos = this.entityStartPos, this._flushCodePointConsumedAsCharacterReference(j.AMPERSAND), this.state = !this._isCharacterReferenceInAttribute() && ir(this.preprocessor.peek(1)) ? W.AMBIGUOUS_AMPERSAND : this.returnState) : this.state = this.returnState;
	}
	_stateAmbiguousAmpersand(e) {
		ir(e) ? this._flushCodePointConsumedAsCharacterReference(e) : (e === j.SEMICOLON && this._err(N.unknownNamedCharacterReference), this.state = this.returnState, this._callState(e));
	}
}, ur = /* @__PURE__ */ new Set([
	H.DD,
	H.DT,
	H.LI,
	H.OPTGROUP,
	H.OPTION,
	H.P,
	H.RB,
	H.RP,
	H.RT,
	H.RTC
]), dr = /* @__PURE__ */ new Set([
	...ur,
	H.CAPTION,
	H.COLGROUP,
	H.TBODY,
	H.TD,
	H.TFOOT,
	H.TH,
	H.THEAD,
	H.TR
]), fr = /* @__PURE__ */ new Set([
	H.APPLET,
	H.CAPTION,
	H.HTML,
	H.MARQUEE,
	H.OBJECT,
	H.TABLE,
	H.TD,
	H.TEMPLATE,
	H.TH
]), pr = /* @__PURE__ */ new Set([
	...fr,
	H.OL,
	H.UL
]), mr = /* @__PURE__ */ new Set([...fr, H.BUTTON]), hr = /* @__PURE__ */ new Set([
	H.ANNOTATION_XML,
	H.MI,
	H.MN,
	H.MO,
	H.MS,
	H.MTEXT
]), gr = /* @__PURE__ */ new Set([
	H.DESC,
	H.FOREIGN_OBJECT,
	H.TITLE
]), _r = /* @__PURE__ */ new Set([
	H.TR,
	H.TEMPLATE,
	H.HTML
]), vr = /* @__PURE__ */ new Set([
	H.TBODY,
	H.TFOOT,
	H.THEAD,
	H.TEMPLATE,
	H.HTML
]), yr = /* @__PURE__ */ new Set([
	H.TABLE,
	H.TEMPLATE,
	H.HTML
]), br = /* @__PURE__ */ new Set([H.TD, H.TH]), xr = class {
	get currentTmplContentOrNode() {
		return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current;
	}
	constructor(e, t, n) {
		this.treeAdapter = t, this.handler = n, this.items = [], this.tagIDs = [], this.stackTop = -1, this.tmplCount = 0, this.currentTagId = H.UNKNOWN, this.current = e;
	}
	_indexOf(e) {
		return this.items.lastIndexOf(e, this.stackTop);
	}
	_isInTemplate() {
		return this.currentTagId === H.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === z.HTML;
	}
	_updateCurrentElement() {
		this.current = this.items[this.stackTop], this.currentTagId = this.tagIDs[this.stackTop];
	}
	push(e, t) {
		this.stackTop++, this.items[this.stackTop] = e, this.current = e, this.tagIDs[this.stackTop] = t, this.currentTagId = t, this._isInTemplate() && this.tmplCount++, this.handler.onItemPush(e, t, !0);
	}
	pop() {
		let e = this.current;
		this.tmplCount > 0 && this._isInTemplate() && this.tmplCount--, this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(e, !0);
	}
	replace(e, t) {
		let n = this._indexOf(e);
		this.items[n] = t, n === this.stackTop && (this.current = t);
	}
	insertAfter(e, t, n) {
		let r = this._indexOf(e) + 1;
		this.items.splice(r, 0, t), this.tagIDs.splice(r, 0, n), this.stackTop++, r === this.stackTop && this._updateCurrentElement(), this.current && this.currentTagId !== void 0 && this.handler.onItemPush(this.current, this.currentTagId, r === this.stackTop);
	}
	popUntilTagNamePopped(e) {
		let t = this.stackTop + 1;
		do
			t = this.tagIDs.lastIndexOf(e, t - 1);
		while (t > 0 && this.treeAdapter.getNamespaceURI(this.items[t]) !== z.HTML);
		this.shortenToLength(Math.max(t, 0));
	}
	shortenToLength(e) {
		for (; this.stackTop >= e;) {
			let t = this.current;
			this.tmplCount > 0 && this._isInTemplate() && --this.tmplCount, this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(t, this.stackTop < e);
		}
	}
	popUntilElementPopped(e) {
		let t = this._indexOf(e);
		this.shortenToLength(Math.max(t, 0));
	}
	popUntilPopped(e, t) {
		let n = this._indexOfTagNames(e, t);
		this.shortenToLength(Math.max(n, 0));
	}
	popUntilNumberedHeaderPopped() {
		this.popUntilPopped(Zn, z.HTML);
	}
	popUntilTableCellPopped() {
		this.popUntilPopped(br, z.HTML);
	}
	popAllUpToHtmlElement() {
		this.tmplCount = 0, this.shortenToLength(1);
	}
	_indexOfTagNames(e, t) {
		for (let n = this.stackTop; n >= 0; n--) if (e.has(this.tagIDs[n]) && this.treeAdapter.getNamespaceURI(this.items[n]) === t) return n;
		return -1;
	}
	clearBackTo(e, t) {
		let n = this._indexOfTagNames(e, t);
		this.shortenToLength(n + 1);
	}
	clearBackToTableContext() {
		this.clearBackTo(yr, z.HTML);
	}
	clearBackToTableBodyContext() {
		this.clearBackTo(vr, z.HTML);
	}
	clearBackToTableRowContext() {
		this.clearBackTo(_r, z.HTML);
	}
	remove(e) {
		let t = this._indexOf(e);
		t >= 0 && (t === this.stackTop ? this.pop() : (this.items.splice(t, 1), this.tagIDs.splice(t, 1), this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(e, !1)));
	}
	tryPeekProperlyNestedBodyElement() {
		return this.stackTop >= 1 && this.tagIDs[1] === H.BODY ? this.items[1] : null;
	}
	contains(e) {
		return this._indexOf(e) > -1;
	}
	getCommonAncestor(e) {
		let t = this._indexOf(e) - 1;
		return t >= 0 ? this.items[t] : null;
	}
	isRootHtmlElementCurrent() {
		return this.stackTop === 0 && this.tagIDs[0] === H.HTML;
	}
	hasInDynamicScope(e, t) {
		for (let n = this.stackTop; n >= 0; n--) {
			let r = this.tagIDs[n];
			switch (this.treeAdapter.getNamespaceURI(this.items[n])) {
				case z.HTML:
					if (r === e) return !0;
					if (t.has(r)) return !1;
					break;
				case z.SVG:
					if (gr.has(r)) return !1;
					break;
				case z.MATHML: if (hr.has(r)) return !1;
			}
		}
		return !0;
	}
	hasInScope(e) {
		return this.hasInDynamicScope(e, fr);
	}
	hasInListItemScope(e) {
		return this.hasInDynamicScope(e, pr);
	}
	hasInButtonScope(e) {
		return this.hasInDynamicScope(e, mr);
	}
	hasNumberedHeaderInScope() {
		for (let e = this.stackTop; e >= 0; e--) {
			let t = this.tagIDs[e];
			switch (this.treeAdapter.getNamespaceURI(this.items[e])) {
				case z.HTML:
					if (Zn.has(t)) return !0;
					if (fr.has(t)) return !1;
					break;
				case z.SVG:
					if (gr.has(t)) return !1;
					break;
				case z.MATHML: if (hr.has(t)) return !1;
			}
		}
		return !0;
	}
	hasInTableScope(e) {
		for (let t = this.stackTop; t >= 0; t--) if (this.treeAdapter.getNamespaceURI(this.items[t]) === z.HTML) switch (this.tagIDs[t]) {
			case e: return !0;
			case H.TABLE:
			case H.HTML: return !1;
		}
		return !0;
	}
	hasTableBodyContextInTableScope() {
		for (let e = this.stackTop; e >= 0; e--) if (this.treeAdapter.getNamespaceURI(this.items[e]) === z.HTML) switch (this.tagIDs[e]) {
			case H.TBODY:
			case H.THEAD:
			case H.TFOOT: return !0;
			case H.TABLE:
			case H.HTML: return !1;
		}
		return !0;
	}
	hasInSelectScope(e) {
		for (let t = this.stackTop; t >= 0; t--) if (this.treeAdapter.getNamespaceURI(this.items[t]) === z.HTML) switch (this.tagIDs[t]) {
			case e: return !0;
			case H.OPTION:
			case H.OPTGROUP: break;
			default: return !1;
		}
		return !0;
	}
	generateImpliedEndTags() {
		for (; this.currentTagId !== void 0 && ur.has(this.currentTagId);) this.pop();
	}
	generateImpliedEndTagsThoroughly() {
		for (; this.currentTagId !== void 0 && dr.has(this.currentTagId);) this.pop();
	}
	generateImpliedEndTagsWithExclusion(e) {
		for (; this.currentTagId !== void 0 && this.currentTagId !== e && dr.has(this.currentTagId);) this.pop();
	}
}, Sr = 3, Cr;
(function(e) {
	e[e.Marker = 0] = "Marker", e[e.Element = 1] = "Element";
})(Cr ||= {});
var wr = { type: Cr.Marker }, Tr = class {
	constructor(e) {
		this.treeAdapter = e, this.entries = [], this.bookmark = null;
	}
	_getNoahArkConditionCandidates(e, t) {
		let n = [], r = t.length, i = this.treeAdapter.getTagName(e), a = this.treeAdapter.getNamespaceURI(e);
		for (let e = 0; e < this.entries.length; e++) {
			let t = this.entries[e];
			if (t.type === Cr.Marker) break;
			let { element: o } = t;
			if (this.treeAdapter.getTagName(o) === i && this.treeAdapter.getNamespaceURI(o) === a) {
				let t = this.treeAdapter.getAttrList(o);
				t.length === r && n.push({
					idx: e,
					attrs: t
				});
			}
		}
		return n;
	}
	_ensureNoahArkCondition(e) {
		if (this.entries.length < Sr) return;
		let t = this.treeAdapter.getAttrList(e), n = this._getNoahArkConditionCandidates(e, t);
		if (n.length < Sr) return;
		let r = new Map(t.map((e) => [e.name, e.value])), i = 0;
		for (let e = 0; e < n.length; e++) {
			let t = n[e];
			t.attrs.every((e) => r.get(e.name) === e.value) && (i += 1, i >= Sr && this.entries.splice(t.idx, 1));
		}
	}
	insertMarker() {
		this.entries.unshift(wr);
	}
	pushElement(e, t) {
		this._ensureNoahArkCondition(e), this.entries.unshift({
			type: Cr.Element,
			element: e,
			token: t
		});
	}
	insertElementAfterBookmark(e, t) {
		let n = this.entries.indexOf(this.bookmark);
		this.entries.splice(n, 0, {
			type: Cr.Element,
			element: e,
			token: t
		});
	}
	removeEntry(e) {
		let t = this.entries.indexOf(e);
		t !== -1 && this.entries.splice(t, 1);
	}
	clearToLastMarker() {
		let e = this.entries.indexOf(wr);
		e === -1 ? this.entries.length = 0 : this.entries.splice(0, e + 1);
	}
	getElementEntryInScopeWithTagName(e) {
		let t = this.entries.find((t) => t.type === Cr.Marker || this.treeAdapter.getTagName(t.element) === e);
		return t && t.type === Cr.Element ? t : null;
	}
	getElementEntry(e) {
		return this.entries.find((t) => t.type === Cr.Element && t.element === e);
	}
}, K = {
	createDocument() {
		return {
			nodeName: "#document",
			mode: B.NO_QUIRKS,
			childNodes: []
		};
	},
	createDocumentFragment() {
		return {
			nodeName: "#document-fragment",
			childNodes: []
		};
	},
	createElement(e, t, n) {
		return {
			nodeName: e,
			tagName: e,
			attrs: n,
			namespaceURI: t,
			childNodes: [],
			parentNode: null
		};
	},
	createCommentNode(e) {
		return {
			nodeName: "#comment",
			data: e,
			parentNode: null
		};
	},
	createTextNode(e) {
		return {
			nodeName: "#text",
			value: e,
			parentNode: null
		};
	},
	appendChild(e, t) {
		e.childNodes.push(t), t.parentNode = e;
	},
	insertBefore(e, t, n) {
		let r = e.childNodes.indexOf(n);
		e.childNodes.splice(r, 0, t), t.parentNode = e;
	},
	setTemplateContent(e, t) {
		e.content = t;
	},
	getTemplateContent(e) {
		return e.content;
	},
	setDocumentType(e, t, n, r) {
		let i = e.childNodes.find((e) => e.nodeName === "#documentType");
		if (i) i.name = t, i.publicId = n, i.systemId = r;
		else {
			let i = {
				nodeName: "#documentType",
				name: t,
				publicId: n,
				systemId: r,
				parentNode: null
			};
			K.appendChild(e, i);
		}
	},
	setDocumentMode(e, t) {
		e.mode = t;
	},
	getDocumentMode(e) {
		return e.mode;
	},
	detachNode(e) {
		if (e.parentNode) {
			let t = e.parentNode.childNodes.indexOf(e);
			e.parentNode.childNodes.splice(t, 1), e.parentNode = null;
		}
	},
	insertText(e, t) {
		if (e.childNodes.length > 0) {
			let n = e.childNodes[e.childNodes.length - 1];
			if (K.isTextNode(n)) {
				n.value += t;
				return;
			}
		}
		K.appendChild(e, K.createTextNode(t));
	},
	insertTextBefore(e, t, n) {
		let r = e.childNodes[e.childNodes.indexOf(n) - 1];
		r && K.isTextNode(r) ? r.value += t : K.insertBefore(e, K.createTextNode(t), n);
	},
	adoptAttributes(e, t) {
		let n = new Set(e.attrs.map((e) => e.name));
		for (let r = 0; r < t.length; r++) n.has(t[r].name) || e.attrs.push(t[r]);
	},
	getFirstChild(e) {
		return e.childNodes[0];
	},
	getChildNodes(e) {
		return e.childNodes;
	},
	getParentNode(e) {
		return e.parentNode;
	},
	getAttrList(e) {
		return e.attrs;
	},
	getTagName(e) {
		return e.tagName;
	},
	getNamespaceURI(e) {
		return e.namespaceURI;
	},
	getTextNodeContent(e) {
		return e.value;
	},
	getCommentNodeContent(e) {
		return e.data;
	},
	getDocumentTypeNodeName(e) {
		return e.name;
	},
	getDocumentTypeNodePublicId(e) {
		return e.publicId;
	},
	getDocumentTypeNodeSystemId(e) {
		return e.systemId;
	},
	isTextNode(e) {
		return e.nodeName === "#text";
	},
	isCommentNode(e) {
		return e.nodeName === "#comment";
	},
	isDocumentTypeNode(e) {
		return e.nodeName === "#documentType";
	},
	isElementNode(e) {
		return Object.prototype.hasOwnProperty.call(e, "tagName");
	},
	setNodeSourceCodeLocation(e, t) {
		e.sourceCodeLocation = t;
	},
	getNodeSourceCodeLocation(e) {
		return e.sourceCodeLocation;
	},
	updateNodeSourceCodeLocation(e, t) {
		e.sourceCodeLocation = {
			...e.sourceCodeLocation,
			...t
		};
	}
}, Er = "html", Dr = "about:legacy-compat", Or = "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd", kr = /* @__PURE__ */ "+//silmaril//dtd html pro v0r11 19970101//,-//as//dtd html 3.0 aswedit + extensions//,-//advasoft ltd//dtd html 3.0 aswedit + extensions//,-//ietf//dtd html 2.0 level 1//,-//ietf//dtd html 2.0 level 2//,-//ietf//dtd html 2.0 strict level 1//,-//ietf//dtd html 2.0 strict level 2//,-//ietf//dtd html 2.0 strict//,-//ietf//dtd html 2.0//,-//ietf//dtd html 2.1e//,-//ietf//dtd html 3.0//,-//ietf//dtd html 3.2 final//,-//ietf//dtd html 3.2//,-//ietf//dtd html 3//,-//ietf//dtd html level 0//,-//ietf//dtd html level 1//,-//ietf//dtd html level 2//,-//ietf//dtd html level 3//,-//ietf//dtd html strict level 0//,-//ietf//dtd html strict level 1//,-//ietf//dtd html strict level 2//,-//ietf//dtd html strict level 3//,-//ietf//dtd html strict//,-//ietf//dtd html//,-//metrius//dtd metrius presentational//,-//microsoft//dtd internet explorer 2.0 html strict//,-//microsoft//dtd internet explorer 2.0 html//,-//microsoft//dtd internet explorer 2.0 tables//,-//microsoft//dtd internet explorer 3.0 html strict//,-//microsoft//dtd internet explorer 3.0 html//,-//microsoft//dtd internet explorer 3.0 tables//,-//netscape comm. corp.//dtd html//,-//netscape comm. corp.//dtd strict html//,-//o'reilly and associates//dtd html 2.0//,-//o'reilly and associates//dtd html extended 1.0//,-//o'reilly and associates//dtd html extended relaxed 1.0//,-//sq//dtd html 2.0 hotmetal + extensions//,-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//,-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//,-//spyglass//dtd html 2.0 extended//,-//sun microsystems corp.//dtd hotjava html//,-//sun microsystems corp.//dtd hotjava strict html//,-//w3c//dtd html 3 1995-03-24//,-//w3c//dtd html 3.2 draft//,-//w3c//dtd html 3.2 final//,-//w3c//dtd html 3.2//,-//w3c//dtd html 3.2s draft//,-//w3c//dtd html 4.0 frameset//,-//w3c//dtd html 4.0 transitional//,-//w3c//dtd html experimental 19960712//,-//w3c//dtd html experimental 970421//,-//w3c//dtd w3 html//,-//w3o//dtd w3 html 3.0//,-//webtechs//dtd mozilla html 2.0//,-//webtechs//dtd mozilla html//".split(","), Ar = [
	...kr,
	"-//w3c//dtd html 4.01 frameset//",
	"-//w3c//dtd html 4.01 transitional//"
], jr = /* @__PURE__ */ new Set([
	"-//w3o//dtd w3 html strict 3.0//en//",
	"-/w3c/dtd html 4.0 transitional/en",
	"html"
]), Mr = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"], Nr = [
	...Mr,
	"-//w3c//dtd html 4.01 frameset//",
	"-//w3c//dtd html 4.01 transitional//"
];
function Pr(e, t) {
	return t.some((t) => e.startsWith(t));
}
function Fr(e) {
	return e.name === Er && e.publicId === null && (e.systemId === null || e.systemId === Dr);
}
function Ir(e) {
	if (e.name !== Er) return B.QUIRKS;
	let { systemId: t } = e;
	if (t && t.toLowerCase() === Or) return B.QUIRKS;
	let { publicId: n } = e;
	if (n !== null) {
		if (n = n.toLowerCase(), jr.has(n)) return B.QUIRKS;
		let e = t === null ? Ar : kr;
		if (Pr(n, e)) return B.QUIRKS;
		if (e = t === null ? Mr : Nr, Pr(n, e)) return B.LIMITED_QUIRKS;
	}
	return B.NO_QUIRKS;
}
// node_modules/parse5/dist/common/foreign-content.js
var Lr = {
	TEXT_HTML: "text/html",
	APPLICATION_XML: "application/xhtml+xml"
}, Rr = "definitionurl", zr = "definitionURL", Br = new Map((/* @__PURE__ */ "attributeName.attributeType.baseFrequency.baseProfile.calcMode.clipPathUnits.diffuseConstant.edgeMode.filterUnits.glyphRef.gradientTransform.gradientUnits.kernelMatrix.kernelUnitLength.keyPoints.keySplines.keyTimes.lengthAdjust.limitingConeAngle.markerHeight.markerUnits.markerWidth.maskContentUnits.maskUnits.numOctaves.pathLength.patternContentUnits.patternTransform.patternUnits.pointsAtX.pointsAtY.pointsAtZ.preserveAlpha.preserveAspectRatio.primitiveUnits.refX.refY.repeatCount.repeatDur.requiredExtensions.requiredFeatures.specularConstant.specularExponent.spreadMethod.startOffset.stdDeviation.stitchTiles.surfaceScale.systemLanguage.tableValues.targetX.targetY.textLength.viewBox.viewTarget.xChannelSelector.yChannelSelector.zoomAndPan".split(".")).map((e) => [e.toLowerCase(), e])), Vr = /* @__PURE__ */ new Map([
	["xlink:actuate", {
		prefix: "xlink",
		name: "actuate",
		namespace: z.XLINK
	}],
	["xlink:arcrole", {
		prefix: "xlink",
		name: "arcrole",
		namespace: z.XLINK
	}],
	["xlink:href", {
		prefix: "xlink",
		name: "href",
		namespace: z.XLINK
	}],
	["xlink:role", {
		prefix: "xlink",
		name: "role",
		namespace: z.XLINK
	}],
	["xlink:show", {
		prefix: "xlink",
		name: "show",
		namespace: z.XLINK
	}],
	["xlink:title", {
		prefix: "xlink",
		name: "title",
		namespace: z.XLINK
	}],
	["xlink:type", {
		prefix: "xlink",
		name: "type",
		namespace: z.XLINK
	}],
	["xml:lang", {
		prefix: "xml",
		name: "lang",
		namespace: z.XML
	}],
	["xml:space", {
		prefix: "xml",
		name: "space",
		namespace: z.XML
	}],
	["xmlns", {
		prefix: "",
		name: "xmlns",
		namespace: z.XMLNS
	}],
	["xmlns:xlink", {
		prefix: "xmlns",
		name: "xlink",
		namespace: z.XMLNS
	}]
]), Hr = new Map((/* @__PURE__ */ "altGlyph.altGlyphDef.altGlyphItem.animateColor.animateMotion.animateTransform.clipPath.feBlend.feColorMatrix.feComponentTransfer.feComposite.feConvolveMatrix.feDiffuseLighting.feDisplacementMap.feDistantLight.feFlood.feFuncA.feFuncB.feFuncG.feFuncR.feGaussianBlur.feImage.feMerge.feMergeNode.feMorphology.feOffset.fePointLight.feSpecularLighting.feSpotLight.feTile.feTurbulence.foreignObject.glyphRef.linearGradient.radialGradient.textPath".split(".")).map((e) => [e.toLowerCase(), e])), Ur = /* @__PURE__ */ new Set([
	H.B,
	H.BIG,
	H.BLOCKQUOTE,
	H.BODY,
	H.BR,
	H.CENTER,
	H.CODE,
	H.DD,
	H.DIV,
	H.DL,
	H.DT,
	H.EM,
	H.EMBED,
	H.H1,
	H.H2,
	H.H3,
	H.H4,
	H.H5,
	H.H6,
	H.HEAD,
	H.HR,
	H.I,
	H.IMG,
	H.LI,
	H.LISTING,
	H.MENU,
	H.META,
	H.NOBR,
	H.OL,
	H.P,
	H.PRE,
	H.RUBY,
	H.S,
	H.SMALL,
	H.SPAN,
	H.STRONG,
	H.STRIKE,
	H.SUB,
	H.SUP,
	H.TABLE,
	H.TT,
	H.U,
	H.UL,
	H.VAR
]);
function Wr(e) {
	let t = e.tagID;
	return t === H.FONT && e.attrs.some(({ name: e }) => e === qn.COLOR || e === qn.SIZE || e === qn.FACE) || Ur.has(t);
}
function Gr(e) {
	for (let t = 0; t < e.attrs.length; t++) if (e.attrs[t].name === Rr) {
		e.attrs[t].name = zr;
		break;
	}
}
function Kr(e) {
	for (let t = 0; t < e.attrs.length; t++) {
		let n = Br.get(e.attrs[t].name);
		n != null && (e.attrs[t].name = n);
	}
}
function qr(e) {
	for (let t = 0; t < e.attrs.length; t++) {
		let n = Vr.get(e.attrs[t].name);
		n && (e.attrs[t].prefix = n.prefix, e.attrs[t].name = n.name, e.attrs[t].namespace = n.namespace);
	}
}
function Jr(e) {
	let t = Hr.get(e.tagName);
	t != null && (e.tagName = t, e.tagID = Yn(e.tagName));
}
function Yr(e, t) {
	return t === z.MATHML && (e === H.MI || e === H.MO || e === H.MN || e === H.MS || e === H.MTEXT);
}
function Xr(e, t, n) {
	if (t === z.MATHML && e === H.ANNOTATION_XML) {
		for (let e = 0; e < n.length; e++) if (n[e].name === qn.ENCODING) {
			let t = n[e].value.toLowerCase();
			return t === Lr.TEXT_HTML || t === Lr.APPLICATION_XML;
		}
	}
	return t === z.SVG && (e === H.FOREIGN_OBJECT || e === H.DESC || e === H.TITLE);
}
function Zr(e, t, n, r) {
	return (!r || r === z.HTML) && Xr(e, t, n) || (!r || r === z.MATHML) && Yr(e, t);
}
// node_modules/parse5/dist/parser/index.js
var Qr = "hidden", $r = 8, ei = 3, q;
(function(e) {
	e[e.INITIAL = 0] = "INITIAL", e[e.BEFORE_HTML = 1] = "BEFORE_HTML", e[e.BEFORE_HEAD = 2] = "BEFORE_HEAD", e[e.IN_HEAD = 3] = "IN_HEAD", e[e.IN_HEAD_NO_SCRIPT = 4] = "IN_HEAD_NO_SCRIPT", e[e.AFTER_HEAD = 5] = "AFTER_HEAD", e[e.IN_BODY = 6] = "IN_BODY", e[e.TEXT = 7] = "TEXT", e[e.IN_TABLE = 8] = "IN_TABLE", e[e.IN_TABLE_TEXT = 9] = "IN_TABLE_TEXT", e[e.IN_CAPTION = 10] = "IN_CAPTION", e[e.IN_COLUMN_GROUP = 11] = "IN_COLUMN_GROUP", e[e.IN_TABLE_BODY = 12] = "IN_TABLE_BODY", e[e.IN_ROW = 13] = "IN_ROW", e[e.IN_CELL = 14] = "IN_CELL", e[e.IN_SELECT = 15] = "IN_SELECT", e[e.IN_SELECT_IN_TABLE = 16] = "IN_SELECT_IN_TABLE", e[e.IN_TEMPLATE = 17] = "IN_TEMPLATE", e[e.AFTER_BODY = 18] = "AFTER_BODY", e[e.IN_FRAMESET = 19] = "IN_FRAMESET", e[e.AFTER_FRAMESET = 20] = "AFTER_FRAMESET", e[e.AFTER_AFTER_BODY = 21] = "AFTER_AFTER_BODY", e[e.AFTER_AFTER_FRAMESET = 22] = "AFTER_AFTER_FRAMESET";
})(q ||= {});
var ti = {
	startLine: -1,
	startCol: -1,
	startOffset: -1,
	endLine: -1,
	endCol: -1,
	endOffset: -1
}, ni = /* @__PURE__ */ new Set([
	H.TABLE,
	H.TBODY,
	H.TFOOT,
	H.THEAD,
	H.TR
]), ri = {
	scriptingEnabled: !0,
	sourceCodeLocationInfo: !1,
	treeAdapter: K,
	onParseError: null
}, ii = class {
	constructor(e, t, n = null, r = null) {
		this.fragmentContext = n, this.scriptHandler = r, this.currentToken = null, this.stopped = !1, this.insertionMode = q.INITIAL, this.originalInsertionMode = q.INITIAL, this.headElement = null, this.formElement = null, this.currentNotInHTML = !1, this.tmplInsertionModeStack = [], this.pendingCharacterTokens = [], this.hasNonWhitespacePendingCharacterToken = !1, this.framesetOk = !0, this.skipNextNewLine = !1, this.fosterParentingEnabled = !1, this.options = {
			...ri,
			...e
		}, this.treeAdapter = this.options.treeAdapter, this.onParseError = this.options.onParseError, this.onParseError && (this.options.sourceCodeLocationInfo = !0), this.document = t ?? this.treeAdapter.createDocument(), this.tokenizer = new lr(this.options, this), this.activeFormattingElements = new Tr(this.treeAdapter), this.fragmentContextID = n ? Yn(this.treeAdapter.getTagName(n)) : H.UNKNOWN, this._setContextModes(n ?? this.document, this.fragmentContextID), this.openElements = new xr(this.document, this.treeAdapter, this);
	}
	static parse(e, t) {
		let n = new this(t);
		return n.tokenizer.write(e, !0), n.document;
	}
	static getFragmentParser(e, t) {
		let n = {
			...ri,
			...t
		};
		e ??= n.treeAdapter.createElement(V.TEMPLATE, z.HTML, []);
		let r = n.treeAdapter.createElement("documentmock", z.HTML, []), i = new this(n, r, e);
		return i.fragmentContextID === H.TEMPLATE && i.tmplInsertionModeStack.unshift(q.IN_TEMPLATE), i._initTokenizerForFragmentParsing(), i._insertFakeRootElement(), i._resetInsertionMode(), i._findFormInFragmentContext(), i;
	}
	getFragment() {
		let e = this.treeAdapter.getFirstChild(this.document), t = this.treeAdapter.createDocumentFragment();
		return this._adoptNodes(e, t), t;
	}
	_err(e, t, n) {
		if (!this.onParseError) return;
		let r = e.location ?? ti, i = {
			code: t,
			startLine: r.startLine,
			startCol: r.startCol,
			startOffset: r.startOffset,
			endLine: n ? r.startLine : r.endLine,
			endCol: n ? r.startCol : r.endCol,
			endOffset: n ? r.startOffset : r.endOffset
		};
		this.onParseError(i);
	}
	onItemPush(e, t, n) {
		var r, i;
		(i = (r = this.treeAdapter).onItemPush) == null || i.call(r, e), n && this.openElements.stackTop > 0 && this._setContextModes(e, t);
	}
	onItemPop(e, t) {
		var n, r;
		if (this.options.sourceCodeLocationInfo && this._setEndLocation(e, this.currentToken), (r = (n = this.treeAdapter).onItemPop) == null || r.call(n, e, this.openElements.current), t) {
			let e, t;
			this.openElements.stackTop === 0 && this.fragmentContext ? (e = this.fragmentContext, t = this.fragmentContextID) : {current: e, currentTagId: t} = this.openElements, this._setContextModes(e, t);
		}
	}
	_setContextModes(e, t) {
		let n = e === this.document || e && this.treeAdapter.getNamespaceURI(e) === z.HTML;
		this.currentNotInHTML = !n, this.tokenizer.inForeignNode = !n && e !== void 0 && t !== void 0 && !this._isIntegrationPoint(t, e);
	}
	_switchToTextParsing(e, t) {
		this._insertElement(e, z.HTML), this.tokenizer.state = t, this.originalInsertionMode = this.insertionMode, this.insertionMode = q.TEXT;
	}
	switchToPlaintextParsing() {
		this.insertionMode = q.TEXT, this.originalInsertionMode = q.IN_BODY, this.tokenizer.state = G.PLAINTEXT;
	}
	_getAdjustedCurrentElement() {
		return this.openElements.stackTop === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.current;
	}
	_findFormInFragmentContext() {
		let e = this.fragmentContext;
		for (; e;) {
			if (this.treeAdapter.getTagName(e) === V.FORM) {
				this.formElement = e;
				break;
			}
			e = this.treeAdapter.getParentNode(e);
		}
	}
	_initTokenizerForFragmentParsing() {
		if (this.fragmentContext && this.treeAdapter.getNamespaceURI(this.fragmentContext) === z.HTML) switch (this.fragmentContextID) {
			case H.TITLE:
			case H.TEXTAREA:
				this.tokenizer.state = G.RCDATA;
				break;
			case H.STYLE:
			case H.XMP:
			case H.IFRAME:
			case H.NOEMBED:
			case H.NOFRAMES:
			case H.NOSCRIPT:
				this.tokenizer.state = G.RAWTEXT;
				break;
			case H.SCRIPT:
				this.tokenizer.state = G.SCRIPT_DATA;
				break;
			case H.PLAINTEXT: this.tokenizer.state = G.PLAINTEXT;
		}
	}
	_setDocumentType(e) {
		let t = e.name || "", n = e.publicId || "", r = e.systemId || "";
		if (this.treeAdapter.setDocumentType(this.document, t, n, r), e.location) {
			let t = this.treeAdapter.getChildNodes(this.document).find((e) => this.treeAdapter.isDocumentTypeNode(e));
			t && this.treeAdapter.setNodeSourceCodeLocation(t, e.location);
		}
	}
	_attachElementToTree(e, t) {
		if (this.options.sourceCodeLocationInfo) {
			let n = t && {
				...t,
				startTag: t
			};
			this.treeAdapter.setNodeSourceCodeLocation(e, n);
		}
		if (this._shouldFosterParentOnInsertion()) this._fosterParentElement(e);
		else {
			let t = this.openElements.currentTmplContentOrNode;
			this.treeAdapter.appendChild(t ?? this.document, e);
		}
	}
	_appendElement(e, t) {
		let n = this.treeAdapter.createElement(e.tagName, t, e.attrs);
		this._attachElementToTree(n, e.location);
	}
	_insertElement(e, t) {
		let n = this.treeAdapter.createElement(e.tagName, t, e.attrs);
		this._attachElementToTree(n, e.location), this.openElements.push(n, e.tagID);
	}
	_insertFakeElement(e, t) {
		let n = this.treeAdapter.createElement(e, z.HTML, []);
		this._attachElementToTree(n, null), this.openElements.push(n, t);
	}
	_insertTemplate(e) {
		let t = this.treeAdapter.createElement(e.tagName, z.HTML, e.attrs), n = this.treeAdapter.createDocumentFragment();
		this.treeAdapter.setTemplateContent(t, n), this._attachElementToTree(t, e.location), this.openElements.push(t, e.tagID), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(n, null);
	}
	_insertFakeRootElement() {
		let e = this.treeAdapter.createElement(V.HTML, z.HTML, []);
		this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(e, null), this.treeAdapter.appendChild(this.openElements.current, e), this.openElements.push(e, H.HTML);
	}
	_appendCommentNode(e, t) {
		let n = this.treeAdapter.createCommentNode(e.data);
		this.treeAdapter.appendChild(t, n), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(n, e.location);
	}
	_insertCharacters(e) {
		let t, n;
		if (this._shouldFosterParentOnInsertion() ? ({parent: t, beforeElement: n} = this._findFosterParentingLocation(), n ? this.treeAdapter.insertTextBefore(t, e.chars, n) : this.treeAdapter.insertText(t, e.chars)) : (t = this.openElements.currentTmplContentOrNode, this.treeAdapter.insertText(t, e.chars)), !e.location) return;
		let r = this.treeAdapter.getChildNodes(t), i = r[(n ? r.lastIndexOf(n) : r.length) - 1];
		if (this.treeAdapter.getNodeSourceCodeLocation(i)) {
			let { endLine: t, endCol: n, endOffset: r } = e.location;
			this.treeAdapter.updateNodeSourceCodeLocation(i, {
				endLine: t,
				endCol: n,
				endOffset: r
			});
		} else this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(i, e.location);
	}
	_adoptNodes(e, t) {
		for (let n = this.treeAdapter.getFirstChild(e); n; n = this.treeAdapter.getFirstChild(e)) this.treeAdapter.detachNode(n), this.treeAdapter.appendChild(t, n);
	}
	_setEndLocation(e, t) {
		if (this.treeAdapter.getNodeSourceCodeLocation(e) && t.location) {
			let n = t.location, r = this.treeAdapter.getTagName(e), i = t.type === P.END_TAG && r === t.tagName ? {
				endTag: { ...n },
				endLine: n.endLine,
				endCol: n.endCol,
				endOffset: n.endOffset
			} : {
				endLine: n.startLine,
				endCol: n.startCol,
				endOffset: n.startOffset
			};
			this.treeAdapter.updateNodeSourceCodeLocation(e, i);
		}
	}
	shouldProcessStartTagTokenInForeignContent(e) {
		if (!this.currentNotInHTML) return !1;
		let t, n;
		return this.openElements.stackTop === 0 && this.fragmentContext ? (t = this.fragmentContext, n = this.fragmentContextID) : {current: t, currentTagId: n} = this.openElements, e.tagID === H.SVG && this.treeAdapter.getTagName(t) === V.ANNOTATION_XML && this.treeAdapter.getNamespaceURI(t) === z.MATHML ? !1 : this.tokenizer.inForeignNode || (e.tagID === H.MGLYPH || e.tagID === H.MALIGNMARK) && n !== void 0 && !this._isIntegrationPoint(n, t, z.HTML);
	}
	_processToken(e) {
		switch (e.type) {
			case P.CHARACTER:
				this.onCharacter(e);
				break;
			case P.NULL_CHARACTER:
				this.onNullCharacter(e);
				break;
			case P.COMMENT:
				this.onComment(e);
				break;
			case P.DOCTYPE:
				this.onDoctype(e);
				break;
			case P.START_TAG:
				this._processStartTag(e);
				break;
			case P.END_TAG:
				this.onEndTag(e);
				break;
			case P.EOF:
				this.onEof(e);
				break;
			case P.WHITESPACE_CHARACTER: this.onWhitespaceCharacter(e);
		}
	}
	_isIntegrationPoint(e, t, n) {
		return Zr(e, this.treeAdapter.getNamespaceURI(t), this.treeAdapter.getAttrList(t), n);
	}
	_reconstructActiveFormattingElements() {
		let e = this.activeFormattingElements.entries.length;
		if (e) {
			let t = this.activeFormattingElements.entries.findIndex((e) => e.type === Cr.Marker || this.openElements.contains(e.element)), n = t === -1 ? e - 1 : t - 1;
			for (let e = n; e >= 0; e--) {
				let t = this.activeFormattingElements.entries[e];
				this._insertElement(t.token, this.treeAdapter.getNamespaceURI(t.element)), t.element = this.openElements.current;
			}
		}
	}
	_closeTableCell() {
		this.openElements.generateImpliedEndTags(), this.openElements.popUntilTableCellPopped(), this.activeFormattingElements.clearToLastMarker(), this.insertionMode = q.IN_ROW;
	}
	_closePElement() {
		this.openElements.generateImpliedEndTagsWithExclusion(H.P), this.openElements.popUntilTagNamePopped(H.P);
	}
	_resetInsertionMode() {
		for (let e = this.openElements.stackTop; e >= 0; e--) switch (e === 0 && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[e]) {
			case H.TR:
				this.insertionMode = q.IN_ROW;
				return;
			case H.TBODY:
			case H.THEAD:
			case H.TFOOT:
				this.insertionMode = q.IN_TABLE_BODY;
				return;
			case H.CAPTION:
				this.insertionMode = q.IN_CAPTION;
				return;
			case H.COLGROUP:
				this.insertionMode = q.IN_COLUMN_GROUP;
				return;
			case H.TABLE:
				this.insertionMode = q.IN_TABLE;
				return;
			case H.BODY:
				this.insertionMode = q.IN_BODY;
				return;
			case H.FRAMESET:
				this.insertionMode = q.IN_FRAMESET;
				return;
			case H.SELECT:
				this._resetInsertionModeForSelect(e);
				return;
			case H.TEMPLATE:
				this.insertionMode = this.tmplInsertionModeStack[0];
				return;
			case H.HTML:
				this.insertionMode = this.headElement ? q.AFTER_HEAD : q.BEFORE_HEAD;
				return;
			case H.TD:
			case H.TH:
				if (e > 0) {
					this.insertionMode = q.IN_CELL;
					return;
				}
				break;
			case H.HEAD: if (e > 0) {
				this.insertionMode = q.IN_HEAD;
				return;
			}
		}
		this.insertionMode = q.IN_BODY;
	}
	_resetInsertionModeForSelect(e) {
		if (e > 0) for (let t = e - 1; t > 0; t--) {
			let e = this.openElements.tagIDs[t];
			if (e === H.TEMPLATE) break;
			if (e === H.TABLE) {
				this.insertionMode = q.IN_SELECT_IN_TABLE;
				return;
			}
		}
		this.insertionMode = q.IN_SELECT;
	}
	_isElementCausesFosterParenting(e) {
		return ni.has(e);
	}
	_shouldFosterParentOnInsertion() {
		return this.fosterParentingEnabled && this.openElements.currentTagId !== void 0 && this._isElementCausesFosterParenting(this.openElements.currentTagId);
	}
	_findFosterParentingLocation() {
		for (let e = this.openElements.stackTop; e >= 0; e--) {
			let t = this.openElements.items[e];
			switch (this.openElements.tagIDs[e]) {
				case H.TEMPLATE:
					if (this.treeAdapter.getNamespaceURI(t) === z.HTML) return {
						parent: this.treeAdapter.getTemplateContent(t),
						beforeElement: null
					};
					break;
				case H.TABLE: {
					let n = this.treeAdapter.getParentNode(t);
					return n ? {
						parent: n,
						beforeElement: t
					} : {
						parent: this.openElements.items[e - 1],
						beforeElement: null
					};
				}
			}
		}
		return {
			parent: this.openElements.items[0],
			beforeElement: null
		};
	}
	_fosterParentElement(e) {
		let t = this._findFosterParentingLocation();
		t.beforeElement ? this.treeAdapter.insertBefore(t.parent, e, t.beforeElement) : this.treeAdapter.appendChild(t.parent, e);
	}
	_isSpecialElement(e, t) {
		return Xn[this.treeAdapter.getNamespaceURI(e)].has(t);
	}
	onCharacter(e) {
		if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) xo(this, e);
		else switch (this.insertionMode) {
			case q.INITIAL:
				_i(this, e);
				break;
			case q.BEFORE_HTML:
				bi(this, e);
				break;
			case q.BEFORE_HEAD:
				Ci(this, e);
				break;
			case q.IN_HEAD:
				Ei(this, e);
				break;
			case q.IN_HEAD_NO_SCRIPT:
				ki(this, e);
				break;
			case q.AFTER_HEAD:
				Mi(this, e);
				break;
			case q.IN_BODY:
			case q.IN_CAPTION:
			case q.IN_CELL:
			case q.IN_TEMPLATE:
				Fi(this, e);
				break;
			case q.TEXT:
			case q.IN_SELECT:
			case q.IN_SELECT_IN_TABLE:
				this._insertCharacters(e);
				break;
			case q.IN_TABLE:
			case q.IN_TABLE_BODY:
			case q.IN_ROW:
				ka(this, e);
				break;
			case q.IN_TABLE_TEXT:
				Ha(this, e);
				break;
			case q.IN_COLUMN_GROUP:
				Ya(this, e);
				break;
			case q.AFTER_BODY:
				fo(this, e);
				break;
			case q.AFTER_AFTER_BODY: vo(this, e);
		}
	}
	onNullCharacter(e) {
		if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) bo(this, e);
		else switch (this.insertionMode) {
			case q.INITIAL:
				_i(this, e);
				break;
			case q.BEFORE_HTML:
				bi(this, e);
				break;
			case q.BEFORE_HEAD:
				Ci(this, e);
				break;
			case q.IN_HEAD:
				Ei(this, e);
				break;
			case q.IN_HEAD_NO_SCRIPT:
				ki(this, e);
				break;
			case q.AFTER_HEAD:
				Mi(this, e);
				break;
			case q.TEXT:
				this._insertCharacters(e);
				break;
			case q.IN_TABLE:
			case q.IN_TABLE_BODY:
			case q.IN_ROW:
				ka(this, e);
				break;
			case q.IN_COLUMN_GROUP:
				Ya(this, e);
				break;
			case q.AFTER_BODY:
				fo(this, e);
				break;
			case q.AFTER_AFTER_BODY: vo(this, e);
		}
	}
	onComment(e) {
		if (this.skipNextNewLine = !1, this.currentNotInHTML) fi(this, e);
		else switch (this.insertionMode) {
			case q.INITIAL:
			case q.BEFORE_HTML:
			case q.BEFORE_HEAD:
			case q.IN_HEAD:
			case q.IN_HEAD_NO_SCRIPT:
			case q.AFTER_HEAD:
			case q.IN_BODY:
			case q.IN_TABLE:
			case q.IN_CAPTION:
			case q.IN_COLUMN_GROUP:
			case q.IN_TABLE_BODY:
			case q.IN_ROW:
			case q.IN_CELL:
			case q.IN_SELECT:
			case q.IN_SELECT_IN_TABLE:
			case q.IN_TEMPLATE:
			case q.IN_FRAMESET:
			case q.AFTER_FRAMESET:
				fi(this, e);
				break;
			case q.IN_TABLE_TEXT:
				Ua(this, e);
				break;
			case q.AFTER_BODY:
				pi(this, e);
				break;
			case q.AFTER_AFTER_BODY:
			case q.AFTER_AFTER_FRAMESET: mi(this, e);
		}
	}
	onDoctype(e) {
		switch (this.skipNextNewLine = !1, this.insertionMode) {
			case q.INITIAL:
				gi(this, e);
				break;
			case q.BEFORE_HEAD:
			case q.IN_HEAD:
			case q.IN_HEAD_NO_SCRIPT:
			case q.AFTER_HEAD:
				this._err(e, N.misplacedDoctype);
				break;
			case q.IN_TABLE_TEXT: Ua(this, e);
		}
	}
	onStartTag(e) {
		this.skipNextNewLine = !1, this.currentToken = e, this._processStartTag(e), e.selfClosing && !e.ackSelfClosing && this._err(e, N.nonVoidHtmlElementStartTagWithTrailingSolidus);
	}
	_processStartTag(e) {
		this.shouldProcessStartTagTokenInForeignContent(e) ? Co(this, e) : this._startTagOutsideForeignContent(e);
	}
	_startTagOutsideForeignContent(e) {
		switch (this.insertionMode) {
			case q.INITIAL:
				_i(this, e);
				break;
			case q.BEFORE_HTML:
				vi(this, e);
				break;
			case q.BEFORE_HEAD:
				xi(this, e);
				break;
			case q.IN_HEAD:
				J(this, e);
				break;
			case q.IN_HEAD_NO_SCRIPT:
				Di(this, e);
				break;
			case q.AFTER_HEAD:
				Ai(this, e);
				break;
			case q.IN_BODY:
				Y(this, e);
				break;
			case q.IN_TABLE:
				Ra(this, e);
				break;
			case q.IN_TABLE_TEXT:
				Ua(this, e);
				break;
			case q.IN_CAPTION:
				Ga(this, e);
				break;
			case q.IN_COLUMN_GROUP:
				qa(this, e);
				break;
			case q.IN_TABLE_BODY:
				Xa(this, e);
				break;
			case q.IN_ROW:
				Qa(this, e);
				break;
			case q.IN_CELL:
				eo(this, e);
				break;
			case q.IN_SELECT:
				no(this, e);
				break;
			case q.IN_SELECT_IN_TABLE:
				io(this, e);
				break;
			case q.IN_TEMPLATE:
				oo(this, e);
				break;
			case q.AFTER_BODY:
				lo(this, e);
				break;
			case q.IN_FRAMESET:
				po(this, e);
				break;
			case q.AFTER_FRAMESET:
				ho(this, e);
				break;
			case q.AFTER_AFTER_BODY:
				_o(this, e);
				break;
			case q.AFTER_AFTER_FRAMESET: yo(this, e);
		}
	}
	onEndTag(e) {
		this.skipNextNewLine = !1, this.currentToken = e, this.currentNotInHTML ? wo(this, e) : this._endTagOutsideForeignContent(e);
	}
	_endTagOutsideForeignContent(e) {
		switch (this.insertionMode) {
			case q.INITIAL:
				_i(this, e);
				break;
			case q.BEFORE_HTML:
				yi(this, e);
				break;
			case q.BEFORE_HEAD:
				Si(this, e);
				break;
			case q.IN_HEAD:
				wi(this, e);
				break;
			case q.IN_HEAD_NO_SCRIPT:
				Oi(this, e);
				break;
			case q.AFTER_HEAD:
				ji(this, e);
				break;
			case q.IN_BODY:
				Ta(this, e);
				break;
			case q.TEXT:
				Da(this, e);
				break;
			case q.IN_TABLE:
				za(this, e);
				break;
			case q.IN_TABLE_TEXT:
				Ua(this, e);
				break;
			case q.IN_CAPTION:
				Ka(this, e);
				break;
			case q.IN_COLUMN_GROUP:
				Ja(this, e);
				break;
			case q.IN_TABLE_BODY:
				Za(this, e);
				break;
			case q.IN_ROW:
				$a(this, e);
				break;
			case q.IN_CELL:
				to(this, e);
				break;
			case q.IN_SELECT:
				ro(this, e);
				break;
			case q.IN_SELECT_IN_TABLE:
				ao(this, e);
				break;
			case q.IN_TEMPLATE:
				so(this, e);
				break;
			case q.AFTER_BODY:
				uo(this, e);
				break;
			case q.IN_FRAMESET:
				mo(this, e);
				break;
			case q.AFTER_FRAMESET:
				go(this, e);
				break;
			case q.AFTER_AFTER_BODY: vo(this, e);
		}
	}
	onEof(e) {
		switch (this.insertionMode) {
			case q.INITIAL:
				_i(this, e);
				break;
			case q.BEFORE_HTML:
				bi(this, e);
				break;
			case q.BEFORE_HEAD:
				Ci(this, e);
				break;
			case q.IN_HEAD:
				Ei(this, e);
				break;
			case q.IN_HEAD_NO_SCRIPT:
				ki(this, e);
				break;
			case q.AFTER_HEAD:
				Mi(this, e);
				break;
			case q.IN_BODY:
			case q.IN_TABLE:
			case q.IN_CAPTION:
			case q.IN_COLUMN_GROUP:
			case q.IN_TABLE_BODY:
			case q.IN_ROW:
			case q.IN_CELL:
			case q.IN_SELECT:
			case q.IN_SELECT_IN_TABLE:
				Ea(this, e);
				break;
			case q.TEXT:
				Oa(this, e);
				break;
			case q.IN_TABLE_TEXT:
				Ua(this, e);
				break;
			case q.IN_TEMPLATE:
				co(this, e);
				break;
			case q.AFTER_BODY:
			case q.IN_FRAMESET:
			case q.AFTER_FRAMESET:
			case q.AFTER_AFTER_BODY:
			case q.AFTER_AFTER_FRAMESET: hi(this, e);
		}
	}
	onWhitespaceCharacter(e) {
		if (this.skipNextNewLine && (this.skipNextNewLine = !1, e.chars.charCodeAt(0) === j.LINE_FEED)) {
			if (e.chars.length === 1) return;
			e.chars = e.chars.substr(1);
		}
		if (this.tokenizer.inForeignNode) this._insertCharacters(e);
		else switch (this.insertionMode) {
			case q.IN_HEAD:
			case q.IN_HEAD_NO_SCRIPT:
			case q.AFTER_HEAD:
			case q.TEXT:
			case q.IN_COLUMN_GROUP:
			case q.IN_SELECT:
			case q.IN_SELECT_IN_TABLE:
			case q.IN_FRAMESET:
			case q.AFTER_FRAMESET:
				this._insertCharacters(e);
				break;
			case q.IN_BODY:
			case q.IN_CAPTION:
			case q.IN_CELL:
			case q.IN_TEMPLATE:
			case q.AFTER_BODY:
			case q.AFTER_AFTER_BODY:
			case q.AFTER_AFTER_FRAMESET:
				Pi(this, e);
				break;
			case q.IN_TABLE:
			case q.IN_TABLE_BODY:
			case q.IN_ROW:
				ka(this, e);
				break;
			case q.IN_TABLE_TEXT: Va(this, e);
		}
	}
};
function ai(e, t) {
	let n = e.activeFormattingElements.getElementEntryInScopeWithTagName(t.tagName);
	return n ? e.openElements.contains(n.element) ? e.openElements.hasInScope(t.tagID) || (n = null) : (e.activeFormattingElements.removeEntry(n), n = null) : wa(e, t), n;
}
function oi(e, t) {
	let n = null, r = e.openElements.stackTop;
	for (; r >= 0; r--) {
		let i = e.openElements.items[r];
		if (i === t.element) break;
		e._isSpecialElement(i, e.openElements.tagIDs[r]) && (n = i);
	}
	return n || (e.openElements.shortenToLength(Math.max(r, 0)), e.activeFormattingElements.removeEntry(t)), n;
}
function si(e, t, n) {
	let r = t, i = e.openElements.getCommonAncestor(t);
	for (let a = 0, o = i; o !== n; a++, o = i) {
		i = e.openElements.getCommonAncestor(o);
		let n = e.activeFormattingElements.getElementEntry(o), s = n && a >= ei;
		!n || s ? (s && e.activeFormattingElements.removeEntry(n), e.openElements.remove(o)) : (o = ci(e, n), r === t && (e.activeFormattingElements.bookmark = n), e.treeAdapter.detachNode(r), e.treeAdapter.appendChild(o, r), r = o);
	}
	return r;
}
function ci(e, t) {
	let n = e.treeAdapter.getNamespaceURI(t.element), r = e.treeAdapter.createElement(t.token.tagName, n, t.token.attrs);
	return e.openElements.replace(t.element, r), t.element = r, r;
}
function li(e, t, n) {
	let r = Yn(e.treeAdapter.getTagName(t));
	if (e._isElementCausesFosterParenting(r)) e._fosterParentElement(n);
	else {
		let i = e.treeAdapter.getNamespaceURI(t);
		r === H.TEMPLATE && i === z.HTML && (t = e.treeAdapter.getTemplateContent(t)), e.treeAdapter.appendChild(t, n);
	}
}
function ui(e, t, n) {
	let r = e.treeAdapter.getNamespaceURI(n.element), { token: i } = n, a = e.treeAdapter.createElement(i.tagName, r, i.attrs);
	e._adoptNodes(t, a), e.treeAdapter.appendChild(t, a), e.activeFormattingElements.insertElementAfterBookmark(a, i), e.activeFormattingElements.removeEntry(n), e.openElements.remove(n.element), e.openElements.insertAfter(t, a, i.tagID);
}
function di(e, t) {
	for (let n = 0; n < $r; n++) {
		let n = ai(e, t);
		if (!n) break;
		let r = oi(e, n);
		if (!r) break;
		e.activeFormattingElements.bookmark = n;
		let i = si(e, r, n.element), a = e.openElements.getCommonAncestor(n.element);
		e.treeAdapter.detachNode(i), a && li(e, a, i), ui(e, r, n);
	}
}
function fi(e, t) {
	e._appendCommentNode(t, e.openElements.currentTmplContentOrNode);
}
function pi(e, t) {
	e._appendCommentNode(t, e.openElements.items[0]);
}
function mi(e, t) {
	e._appendCommentNode(t, e.document);
}
function hi(e, t) {
	if (e.stopped = !0, t.location) {
		let n = e.fragmentContext ? 0 : 2;
		for (let r = e.openElements.stackTop; r >= n; r--) e._setEndLocation(e.openElements.items[r], t);
		if (!e.fragmentContext && e.openElements.stackTop >= 0) {
			let n = e.openElements.items[0], r = e.treeAdapter.getNodeSourceCodeLocation(n);
			if (r && !r.endTag && (e._setEndLocation(n, t), e.openElements.stackTop >= 1)) {
				let n = e.openElements.items[1], r = e.treeAdapter.getNodeSourceCodeLocation(n);
				r && !r.endTag && e._setEndLocation(n, t);
			}
		}
	}
}
function gi(e, t) {
	e._setDocumentType(t);
	let n = t.forceQuirks ? B.QUIRKS : Ir(t);
	Fr(t) || e._err(t, N.nonConformingDoctype), e.treeAdapter.setDocumentMode(e.document, n), e.insertionMode = q.BEFORE_HTML;
}
function _i(e, t) {
	e._err(t, N.missingDoctype, !0), e.treeAdapter.setDocumentMode(e.document, B.QUIRKS), e.insertionMode = q.BEFORE_HTML, e._processToken(t);
}
function vi(e, t) {
	t.tagID === H.HTML ? (e._insertElement(t, z.HTML), e.insertionMode = q.BEFORE_HEAD) : bi(e, t);
}
function yi(e, t) {
	let n = t.tagID;
	(n === H.HTML || n === H.HEAD || n === H.BODY || n === H.BR) && bi(e, t);
}
function bi(e, t) {
	e._insertFakeRootElement(), e.insertionMode = q.BEFORE_HEAD, e._processToken(t);
}
function xi(e, t) {
	switch (t.tagID) {
		case H.HTML:
			Y(e, t);
			break;
		case H.HEAD:
			e._insertElement(t, z.HTML), e.headElement = e.openElements.current, e.insertionMode = q.IN_HEAD;
			break;
		default: Ci(e, t);
	}
}
function Si(e, t) {
	let n = t.tagID;
	n === H.HEAD || n === H.BODY || n === H.HTML || n === H.BR ? Ci(e, t) : e._err(t, N.endTagWithoutMatchingOpenElement);
}
function Ci(e, t) {
	e._insertFakeElement(V.HEAD, H.HEAD), e.headElement = e.openElements.current, e.insertionMode = q.IN_HEAD, e._processToken(t);
}
function J(e, t) {
	switch (t.tagID) {
		case H.HTML:
			Y(e, t);
			break;
		case H.BASE:
		case H.BASEFONT:
		case H.BGSOUND:
		case H.LINK:
		case H.META:
			e._appendElement(t, z.HTML), t.ackSelfClosing = !0;
			break;
		case H.TITLE:
			e._switchToTextParsing(t, G.RCDATA);
			break;
		case H.NOSCRIPT:
			e.options.scriptingEnabled ? e._switchToTextParsing(t, G.RAWTEXT) : (e._insertElement(t, z.HTML), e.insertionMode = q.IN_HEAD_NO_SCRIPT);
			break;
		case H.NOFRAMES:
		case H.STYLE:
			e._switchToTextParsing(t, G.RAWTEXT);
			break;
		case H.SCRIPT:
			e._switchToTextParsing(t, G.SCRIPT_DATA);
			break;
		case H.TEMPLATE:
			e._insertTemplate(t), e.activeFormattingElements.insertMarker(), e.framesetOk = !1, e.insertionMode = q.IN_TEMPLATE, e.tmplInsertionModeStack.unshift(q.IN_TEMPLATE);
			break;
		case H.HEAD:
			e._err(t, N.misplacedStartTagForHeadElement);
			break;
		default: Ei(e, t);
	}
}
function wi(e, t) {
	switch (t.tagID) {
		case H.HEAD:
			e.openElements.pop(), e.insertionMode = q.AFTER_HEAD;
			break;
		case H.BODY:
		case H.BR:
		case H.HTML:
			Ei(e, t);
			break;
		case H.TEMPLATE:
			Ti(e, t);
			break;
		default: e._err(t, N.endTagWithoutMatchingOpenElement);
	}
}
function Ti(e, t) {
	e.openElements.tmplCount > 0 ? (e.openElements.generateImpliedEndTagsThoroughly(), e.openElements.currentTagId !== H.TEMPLATE && e._err(t, N.closingOfElementWithOpenChildElements), e.openElements.popUntilTagNamePopped(H.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode()) : e._err(t, N.endTagWithoutMatchingOpenElement);
}
function Ei(e, t) {
	e.openElements.pop(), e.insertionMode = q.AFTER_HEAD, e._processToken(t);
}
function Di(e, t) {
	switch (t.tagID) {
		case H.HTML:
			Y(e, t);
			break;
		case H.BASEFONT:
		case H.BGSOUND:
		case H.HEAD:
		case H.LINK:
		case H.META:
		case H.NOFRAMES:
		case H.STYLE:
			J(e, t);
			break;
		case H.NOSCRIPT:
			e._err(t, N.nestedNoscriptInHead);
			break;
		default: ki(e, t);
	}
}
function Oi(e, t) {
	switch (t.tagID) {
		case H.NOSCRIPT:
			e.openElements.pop(), e.insertionMode = q.IN_HEAD;
			break;
		case H.BR:
			ki(e, t);
			break;
		default: e._err(t, N.endTagWithoutMatchingOpenElement);
	}
}
function ki(e, t) {
	let n = t.type === P.EOF ? N.openElementsLeftAfterEof : N.disallowedContentInNoscriptInHead;
	e._err(t, n), e.openElements.pop(), e.insertionMode = q.IN_HEAD, e._processToken(t);
}
function Ai(e, t) {
	switch (t.tagID) {
		case H.HTML:
			Y(e, t);
			break;
		case H.BODY:
			e._insertElement(t, z.HTML), e.framesetOk = !1, e.insertionMode = q.IN_BODY;
			break;
		case H.FRAMESET:
			e._insertElement(t, z.HTML), e.insertionMode = q.IN_FRAMESET;
			break;
		case H.BASE:
		case H.BASEFONT:
		case H.BGSOUND:
		case H.LINK:
		case H.META:
		case H.NOFRAMES:
		case H.SCRIPT:
		case H.STYLE:
		case H.TEMPLATE:
		case H.TITLE:
			e._err(t, N.abandonedHeadElementChild), e.openElements.push(e.headElement, H.HEAD), J(e, t), e.openElements.remove(e.headElement);
			break;
		case H.HEAD:
			e._err(t, N.misplacedStartTagForHeadElement);
			break;
		default: Mi(e, t);
	}
}
function ji(e, t) {
	switch (t.tagID) {
		case H.BODY:
		case H.HTML:
		case H.BR:
			Mi(e, t);
			break;
		case H.TEMPLATE:
			Ti(e, t);
			break;
		default: e._err(t, N.endTagWithoutMatchingOpenElement);
	}
}
function Mi(e, t) {
	e._insertFakeElement(V.BODY, H.BODY), e.insertionMode = q.IN_BODY, Ni(e, t);
}
function Ni(e, t) {
	switch (t.type) {
		case P.CHARACTER:
			Fi(e, t);
			break;
		case P.WHITESPACE_CHARACTER:
			Pi(e, t);
			break;
		case P.COMMENT:
			fi(e, t);
			break;
		case P.START_TAG:
			Y(e, t);
			break;
		case P.END_TAG:
			Ta(e, t);
			break;
		case P.EOF: Ea(e, t);
	}
}
function Pi(e, t) {
	e._reconstructActiveFormattingElements(), e._insertCharacters(t);
}
function Fi(e, t) {
	e._reconstructActiveFormattingElements(), e._insertCharacters(t), e.framesetOk = !1;
}
function Ii(e, t) {
	e.openElements.tmplCount === 0 && e.treeAdapter.adoptAttributes(e.openElements.items[0], t.attrs);
}
function Li(e, t) {
	let n = e.openElements.tryPeekProperlyNestedBodyElement();
	n && e.openElements.tmplCount === 0 && (e.framesetOk = !1, e.treeAdapter.adoptAttributes(n, t.attrs));
}
function Ri(e, t) {
	let n = e.openElements.tryPeekProperlyNestedBodyElement();
	e.framesetOk && n && (e.treeAdapter.detachNode(n), e.openElements.popAllUpToHtmlElement(), e._insertElement(t, z.HTML), e.insertionMode = q.IN_FRAMESET);
}
function zi(e, t) {
	e.openElements.hasInButtonScope(H.P) && e._closePElement(), e._insertElement(t, z.HTML);
}
function Bi(e, t) {
	e.openElements.hasInButtonScope(H.P) && e._closePElement(), e.openElements.currentTagId !== void 0 && Zn.has(e.openElements.currentTagId) && e.openElements.pop(), e._insertElement(t, z.HTML);
}
function Vi(e, t) {
	e.openElements.hasInButtonScope(H.P) && e._closePElement(), e._insertElement(t, z.HTML), e.skipNextNewLine = !0, e.framesetOk = !1;
}
function Hi(e, t) {
	let n = e.openElements.tmplCount > 0;
	(!e.formElement || n) && (e.openElements.hasInButtonScope(H.P) && e._closePElement(), e._insertElement(t, z.HTML), n || (e.formElement = e.openElements.current));
}
function Ui(e, t) {
	e.framesetOk = !1;
	let n = t.tagID;
	for (let t = e.openElements.stackTop; t >= 0; t--) {
		let r = e.openElements.tagIDs[t];
		if (n === H.LI && r === H.LI || (n === H.DD || n === H.DT) && (r === H.DD || r === H.DT)) {
			e.openElements.generateImpliedEndTagsWithExclusion(r), e.openElements.popUntilTagNamePopped(r);
			break;
		}
		if (r !== H.ADDRESS && r !== H.DIV && r !== H.P && e._isSpecialElement(e.openElements.items[t], r)) break;
	}
	e.openElements.hasInButtonScope(H.P) && e._closePElement(), e._insertElement(t, z.HTML);
}
function Wi(e, t) {
	e.openElements.hasInButtonScope(H.P) && e._closePElement(), e._insertElement(t, z.HTML), e.tokenizer.state = G.PLAINTEXT;
}
function Gi(e, t) {
	e.openElements.hasInScope(H.BUTTON) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(H.BUTTON)), e._reconstructActiveFormattingElements(), e._insertElement(t, z.HTML), e.framesetOk = !1;
}
function Ki(e, t) {
	let n = e.activeFormattingElements.getElementEntryInScopeWithTagName(V.A);
	n && (di(e, t), e.openElements.remove(n.element), e.activeFormattingElements.removeEntry(n)), e._reconstructActiveFormattingElements(), e._insertElement(t, z.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function qi(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, z.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Ji(e, t) {
	e._reconstructActiveFormattingElements(), e.openElements.hasInScope(H.NOBR) && (di(e, t), e._reconstructActiveFormattingElements()), e._insertElement(t, z.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Yi(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, z.HTML), e.activeFormattingElements.insertMarker(), e.framesetOk = !1;
}
function Xi(e, t) {
	e.treeAdapter.getDocumentMode(e.document) !== B.QUIRKS && e.openElements.hasInButtonScope(H.P) && e._closePElement(), e._insertElement(t, z.HTML), e.framesetOk = !1, e.insertionMode = q.IN_TABLE;
}
function Zi(e, t) {
	e._reconstructActiveFormattingElements(), e._appendElement(t, z.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function Qi(e) {
	let t = jn(e, qn.TYPE);
	return t != null && t.toLowerCase() === Qr;
}
function $i(e, t) {
	e._reconstructActiveFormattingElements(), e._appendElement(t, z.HTML), Qi(t) || (e.framesetOk = !1), t.ackSelfClosing = !0;
}
function ea(e, t) {
	e._appendElement(t, z.HTML), t.ackSelfClosing = !0;
}
function ta(e, t) {
	e.openElements.hasInButtonScope(H.P) && e._closePElement(), e._appendElement(t, z.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function na(e, t) {
	t.tagName = V.IMG, t.tagID = H.IMG, Zi(e, t);
}
function ra(e, t) {
	e._insertElement(t, z.HTML), e.skipNextNewLine = !0, e.tokenizer.state = G.RCDATA, e.originalInsertionMode = e.insertionMode, e.framesetOk = !1, e.insertionMode = q.TEXT;
}
function ia(e, t) {
	e.openElements.hasInButtonScope(H.P) && e._closePElement(), e._reconstructActiveFormattingElements(), e.framesetOk = !1, e._switchToTextParsing(t, G.RAWTEXT);
}
function aa(e, t) {
	e.framesetOk = !1, e._switchToTextParsing(t, G.RAWTEXT);
}
function oa(e, t) {
	e._switchToTextParsing(t, G.RAWTEXT);
}
function sa(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, z.HTML), e.framesetOk = !1, e.insertionMode = e.insertionMode === q.IN_TABLE || e.insertionMode === q.IN_CAPTION || e.insertionMode === q.IN_TABLE_BODY || e.insertionMode === q.IN_ROW || e.insertionMode === q.IN_CELL ? q.IN_SELECT_IN_TABLE : q.IN_SELECT;
}
function ca(e, t) {
	e.openElements.currentTagId === H.OPTION && e.openElements.pop(), e._reconstructActiveFormattingElements(), e._insertElement(t, z.HTML);
}
function la(e, t) {
	e.openElements.hasInScope(H.RUBY) && e.openElements.generateImpliedEndTags(), e._insertElement(t, z.HTML);
}
function ua(e, t) {
	e.openElements.hasInScope(H.RUBY) && e.openElements.generateImpliedEndTagsWithExclusion(H.RTC), e._insertElement(t, z.HTML);
}
function da(e, t) {
	e._reconstructActiveFormattingElements(), Gr(t), qr(t), t.selfClosing ? e._appendElement(t, z.MATHML) : e._insertElement(t, z.MATHML), t.ackSelfClosing = !0;
}
function fa(e, t) {
	e._reconstructActiveFormattingElements(), Kr(t), qr(t), t.selfClosing ? e._appendElement(t, z.SVG) : e._insertElement(t, z.SVG), t.ackSelfClosing = !0;
}
function pa(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, z.HTML);
}
function Y(e, t) {
	switch (t.tagID) {
		case H.I:
		case H.S:
		case H.B:
		case H.U:
		case H.EM:
		case H.TT:
		case H.BIG:
		case H.CODE:
		case H.FONT:
		case H.SMALL:
		case H.STRIKE:
		case H.STRONG:
			qi(e, t);
			break;
		case H.A:
			Ki(e, t);
			break;
		case H.H1:
		case H.H2:
		case H.H3:
		case H.H4:
		case H.H5:
		case H.H6:
			Bi(e, t);
			break;
		case H.P:
		case H.DL:
		case H.OL:
		case H.UL:
		case H.DIV:
		case H.DIR:
		case H.NAV:
		case H.MAIN:
		case H.MENU:
		case H.ASIDE:
		case H.CENTER:
		case H.FIGURE:
		case H.FOOTER:
		case H.HEADER:
		case H.HGROUP:
		case H.DIALOG:
		case H.DETAILS:
		case H.ADDRESS:
		case H.ARTICLE:
		case H.SEARCH:
		case H.SECTION:
		case H.SUMMARY:
		case H.FIELDSET:
		case H.BLOCKQUOTE:
		case H.FIGCAPTION:
			zi(e, t);
			break;
		case H.LI:
		case H.DD:
		case H.DT:
			Ui(e, t);
			break;
		case H.BR:
		case H.IMG:
		case H.WBR:
		case H.AREA:
		case H.EMBED:
		case H.KEYGEN:
			Zi(e, t);
			break;
		case H.HR:
			ta(e, t);
			break;
		case H.RB:
		case H.RTC:
			la(e, t);
			break;
		case H.RT:
		case H.RP:
			ua(e, t);
			break;
		case H.PRE:
		case H.LISTING:
			Vi(e, t);
			break;
		case H.XMP:
			ia(e, t);
			break;
		case H.SVG:
			fa(e, t);
			break;
		case H.HTML:
			Ii(e, t);
			break;
		case H.BASE:
		case H.LINK:
		case H.META:
		case H.STYLE:
		case H.TITLE:
		case H.SCRIPT:
		case H.BGSOUND:
		case H.BASEFONT:
		case H.TEMPLATE:
			J(e, t);
			break;
		case H.BODY:
			Li(e, t);
			break;
		case H.FORM:
			Hi(e, t);
			break;
		case H.NOBR:
			Ji(e, t);
			break;
		case H.MATH:
			da(e, t);
			break;
		case H.TABLE:
			Xi(e, t);
			break;
		case H.INPUT:
			$i(e, t);
			break;
		case H.PARAM:
		case H.TRACK:
		case H.SOURCE:
			ea(e, t);
			break;
		case H.IMAGE:
			na(e, t);
			break;
		case H.BUTTON:
			Gi(e, t);
			break;
		case H.APPLET:
		case H.OBJECT:
		case H.MARQUEE:
			Yi(e, t);
			break;
		case H.IFRAME:
			aa(e, t);
			break;
		case H.SELECT:
			sa(e, t);
			break;
		case H.OPTION:
		case H.OPTGROUP:
			ca(e, t);
			break;
		case H.NOEMBED:
		case H.NOFRAMES:
			oa(e, t);
			break;
		case H.FRAMESET:
			Ri(e, t);
			break;
		case H.TEXTAREA:
			ra(e, t);
			break;
		case H.NOSCRIPT:
			e.options.scriptingEnabled ? oa(e, t) : pa(e, t);
			break;
		case H.PLAINTEXT:
			Wi(e, t);
			break;
		case H.COL:
		case H.TH:
		case H.TD:
		case H.TR:
		case H.HEAD:
		case H.FRAME:
		case H.TBODY:
		case H.TFOOT:
		case H.THEAD:
		case H.CAPTION:
		case H.COLGROUP: break;
		default: pa(e, t);
	}
}
function ma(e, t) {
	if (e.openElements.hasInScope(H.BODY) && (e.insertionMode = q.AFTER_BODY, e.options.sourceCodeLocationInfo)) {
		let n = e.openElements.tryPeekProperlyNestedBodyElement();
		n && e._setEndLocation(n, t);
	}
}
function ha(e, t) {
	e.openElements.hasInScope(H.BODY) && (e.insertionMode = q.AFTER_BODY, uo(e, t));
}
function ga(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n));
}
function _a(e) {
	let t = e.openElements.tmplCount > 0, { formElement: n } = e;
	t || (e.formElement = null), (n || t) && e.openElements.hasInScope(H.FORM) && (e.openElements.generateImpliedEndTags(), t ? e.openElements.popUntilTagNamePopped(H.FORM) : n && e.openElements.remove(n));
}
function va(e) {
	e.openElements.hasInButtonScope(H.P) || e._insertFakeElement(V.P, H.P), e._closePElement();
}
function ya(e) {
	e.openElements.hasInListItemScope(H.LI) && (e.openElements.generateImpliedEndTagsWithExclusion(H.LI), e.openElements.popUntilTagNamePopped(H.LI));
}
function ba(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTagsWithExclusion(n), e.openElements.popUntilTagNamePopped(n));
}
function xa(e) {
	e.openElements.hasNumberedHeaderInScope() && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilNumberedHeaderPopped());
}
function Sa(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n), e.activeFormattingElements.clearToLastMarker());
}
function Ca(e) {
	e._reconstructActiveFormattingElements(), e._insertFakeElement(V.BR, H.BR), e.openElements.pop(), e.framesetOk = !1;
}
function wa(e, t) {
	let n = t.tagName, r = t.tagID;
	for (let t = e.openElements.stackTop; t > 0; t--) {
		let i = e.openElements.items[t], a = e.openElements.tagIDs[t];
		if (r === a && (r !== H.UNKNOWN || e.treeAdapter.getTagName(i) === n)) {
			e.openElements.generateImpliedEndTagsWithExclusion(r), e.openElements.stackTop >= t && e.openElements.shortenToLength(t);
			break;
		}
		if (e._isSpecialElement(i, a)) break;
	}
}
function Ta(e, t) {
	switch (t.tagID) {
		case H.A:
		case H.B:
		case H.I:
		case H.S:
		case H.U:
		case H.EM:
		case H.TT:
		case H.BIG:
		case H.CODE:
		case H.FONT:
		case H.NOBR:
		case H.SMALL:
		case H.STRIKE:
		case H.STRONG:
			di(e, t);
			break;
		case H.P:
			va(e);
			break;
		case H.DL:
		case H.UL:
		case H.OL:
		case H.DIR:
		case H.DIV:
		case H.NAV:
		case H.PRE:
		case H.MAIN:
		case H.MENU:
		case H.ASIDE:
		case H.BUTTON:
		case H.CENTER:
		case H.FIGURE:
		case H.FOOTER:
		case H.HEADER:
		case H.HGROUP:
		case H.DIALOG:
		case H.ADDRESS:
		case H.ARTICLE:
		case H.DETAILS:
		case H.SEARCH:
		case H.SECTION:
		case H.SUMMARY:
		case H.LISTING:
		case H.FIELDSET:
		case H.BLOCKQUOTE:
		case H.FIGCAPTION:
			ga(e, t);
			break;
		case H.LI:
			ya(e);
			break;
		case H.DD:
		case H.DT:
			ba(e, t);
			break;
		case H.H1:
		case H.H2:
		case H.H3:
		case H.H4:
		case H.H5:
		case H.H6:
			xa(e);
			break;
		case H.BR:
			Ca(e);
			break;
		case H.BODY:
			ma(e, t);
			break;
		case H.HTML:
			ha(e, t);
			break;
		case H.FORM:
			_a(e);
			break;
		case H.APPLET:
		case H.OBJECT:
		case H.MARQUEE:
			Sa(e, t);
			break;
		case H.TEMPLATE:
			Ti(e, t);
			break;
		default: wa(e, t);
	}
}
function Ea(e, t) {
	e.tmplInsertionModeStack.length > 0 ? co(e, t) : hi(e, t);
}
function Da(e, t) {
	var n;
	t.tagID === H.SCRIPT && ((n = e.scriptHandler) == null || n.call(e, e.openElements.current)), e.openElements.pop(), e.insertionMode = e.originalInsertionMode;
}
function Oa(e, t) {
	e._err(t, N.eofInElementThatCanContainOnlyText), e.openElements.pop(), e.insertionMode = e.originalInsertionMode, e.onEof(t);
}
function ka(e, t) {
	if (e.openElements.currentTagId !== void 0 && ni.has(e.openElements.currentTagId)) switch (e.pendingCharacterTokens.length = 0, e.hasNonWhitespacePendingCharacterToken = !1, e.originalInsertionMode = e.insertionMode, e.insertionMode = q.IN_TABLE_TEXT, t.type) {
		case P.CHARACTER:
			Ha(e, t);
			break;
		case P.WHITESPACE_CHARACTER: Va(e, t);
	}
	else Ba(e, t);
}
function Aa(e, t) {
	e.openElements.clearBackToTableContext(), e.activeFormattingElements.insertMarker(), e._insertElement(t, z.HTML), e.insertionMode = q.IN_CAPTION;
}
function ja(e, t) {
	e.openElements.clearBackToTableContext(), e._insertElement(t, z.HTML), e.insertionMode = q.IN_COLUMN_GROUP;
}
function Ma(e, t) {
	e.openElements.clearBackToTableContext(), e._insertFakeElement(V.COLGROUP, H.COLGROUP), e.insertionMode = q.IN_COLUMN_GROUP, qa(e, t);
}
function Na(e, t) {
	e.openElements.clearBackToTableContext(), e._insertElement(t, z.HTML), e.insertionMode = q.IN_TABLE_BODY;
}
function Pa(e, t) {
	e.openElements.clearBackToTableContext(), e._insertFakeElement(V.TBODY, H.TBODY), e.insertionMode = q.IN_TABLE_BODY, Xa(e, t);
}
function Fa(e, t) {
	e.openElements.hasInTableScope(H.TABLE) && (e.openElements.popUntilTagNamePopped(H.TABLE), e._resetInsertionMode(), e._processStartTag(t));
}
function Ia(e, t) {
	Qi(t) ? e._appendElement(t, z.HTML) : Ba(e, t), t.ackSelfClosing = !0;
}
function La(e, t) {
	!e.formElement && e.openElements.tmplCount === 0 && (e._insertElement(t, z.HTML), e.formElement = e.openElements.current, e.openElements.pop());
}
function Ra(e, t) {
	switch (t.tagID) {
		case H.TD:
		case H.TH:
		case H.TR:
			Pa(e, t);
			break;
		case H.STYLE:
		case H.SCRIPT:
		case H.TEMPLATE:
			J(e, t);
			break;
		case H.COL:
			Ma(e, t);
			break;
		case H.FORM:
			La(e, t);
			break;
		case H.TABLE:
			Fa(e, t);
			break;
		case H.TBODY:
		case H.TFOOT:
		case H.THEAD:
			Na(e, t);
			break;
		case H.INPUT:
			Ia(e, t);
			break;
		case H.CAPTION:
			Aa(e, t);
			break;
		case H.COLGROUP:
			ja(e, t);
			break;
		default: Ba(e, t);
	}
}
function za(e, t) {
	switch (t.tagID) {
		case H.TABLE:
			e.openElements.hasInTableScope(H.TABLE) && (e.openElements.popUntilTagNamePopped(H.TABLE), e._resetInsertionMode());
			break;
		case H.TEMPLATE:
			Ti(e, t);
			break;
		case H.BODY:
		case H.CAPTION:
		case H.COL:
		case H.COLGROUP:
		case H.HTML:
		case H.TBODY:
		case H.TD:
		case H.TFOOT:
		case H.TH:
		case H.THEAD:
		case H.TR: break;
		default: Ba(e, t);
	}
}
function Ba(e, t) {
	let n = e.fosterParentingEnabled;
	e.fosterParentingEnabled = !0, Ni(e, t), e.fosterParentingEnabled = n;
}
function Va(e, t) {
	e.pendingCharacterTokens.push(t);
}
function Ha(e, t) {
	e.pendingCharacterTokens.push(t), e.hasNonWhitespacePendingCharacterToken = !0;
}
function Ua(e, t) {
	let n = 0;
	if (e.hasNonWhitespacePendingCharacterToken) for (; n < e.pendingCharacterTokens.length; n++) Ba(e, e.pendingCharacterTokens[n]);
	else for (; n < e.pendingCharacterTokens.length; n++) e._insertCharacters(e.pendingCharacterTokens[n]);
	e.insertionMode = e.originalInsertionMode, e._processToken(t);
}
var Wa = /* @__PURE__ */ new Set([
	H.CAPTION,
	H.COL,
	H.COLGROUP,
	H.TBODY,
	H.TD,
	H.TFOOT,
	H.TH,
	H.THEAD,
	H.TR
]);
function Ga(e, t) {
	let n = t.tagID;
	Wa.has(n) ? e.openElements.hasInTableScope(H.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(H.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = q.IN_TABLE, Ra(e, t)) : Y(e, t);
}
function Ka(e, t) {
	let n = t.tagID;
	switch (n) {
		case H.CAPTION:
		case H.TABLE:
			e.openElements.hasInTableScope(H.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(H.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = q.IN_TABLE, n === H.TABLE && za(e, t));
			break;
		case H.BODY:
		case H.COL:
		case H.COLGROUP:
		case H.HTML:
		case H.TBODY:
		case H.TD:
		case H.TFOOT:
		case H.TH:
		case H.THEAD:
		case H.TR: break;
		default: Ta(e, t);
	}
}
function qa(e, t) {
	switch (t.tagID) {
		case H.HTML:
			Y(e, t);
			break;
		case H.COL:
			e._appendElement(t, z.HTML), t.ackSelfClosing = !0;
			break;
		case H.TEMPLATE:
			J(e, t);
			break;
		default: Ya(e, t);
	}
}
function Ja(e, t) {
	switch (t.tagID) {
		case H.COLGROUP:
			e.openElements.currentTagId === H.COLGROUP && (e.openElements.pop(), e.insertionMode = q.IN_TABLE);
			break;
		case H.TEMPLATE:
			Ti(e, t);
			break;
		case H.COL: break;
		default: Ya(e, t);
	}
}
function Ya(e, t) {
	e.openElements.currentTagId === H.COLGROUP && (e.openElements.pop(), e.insertionMode = q.IN_TABLE, e._processToken(t));
}
function Xa(e, t) {
	switch (t.tagID) {
		case H.TR:
			e.openElements.clearBackToTableBodyContext(), e._insertElement(t, z.HTML), e.insertionMode = q.IN_ROW;
			break;
		case H.TH:
		case H.TD:
			e.openElements.clearBackToTableBodyContext(), e._insertFakeElement(V.TR, H.TR), e.insertionMode = q.IN_ROW, Qa(e, t);
			break;
		case H.CAPTION:
		case H.COL:
		case H.COLGROUP:
		case H.TBODY:
		case H.TFOOT:
		case H.THEAD:
			e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = q.IN_TABLE, Ra(e, t));
			break;
		default: Ra(e, t);
	}
}
function Za(e, t) {
	let n = t.tagID;
	switch (t.tagID) {
		case H.TBODY:
		case H.TFOOT:
		case H.THEAD:
			e.openElements.hasInTableScope(n) && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = q.IN_TABLE);
			break;
		case H.TABLE:
			e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = q.IN_TABLE, za(e, t));
			break;
		case H.BODY:
		case H.CAPTION:
		case H.COL:
		case H.COLGROUP:
		case H.HTML:
		case H.TD:
		case H.TH:
		case H.TR: break;
		default: za(e, t);
	}
}
function Qa(e, t) {
	switch (t.tagID) {
		case H.TH:
		case H.TD:
			e.openElements.clearBackToTableRowContext(), e._insertElement(t, z.HTML), e.insertionMode = q.IN_CELL, e.activeFormattingElements.insertMarker();
			break;
		case H.CAPTION:
		case H.COL:
		case H.COLGROUP:
		case H.TBODY:
		case H.TFOOT:
		case H.THEAD:
		case H.TR:
			e.openElements.hasInTableScope(H.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = q.IN_TABLE_BODY, Xa(e, t));
			break;
		default: Ra(e, t);
	}
}
function $a(e, t) {
	switch (t.tagID) {
		case H.TR:
			e.openElements.hasInTableScope(H.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = q.IN_TABLE_BODY);
			break;
		case H.TABLE:
			e.openElements.hasInTableScope(H.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = q.IN_TABLE_BODY, Za(e, t));
			break;
		case H.TBODY:
		case H.TFOOT:
		case H.THEAD:
			(e.openElements.hasInTableScope(t.tagID) || e.openElements.hasInTableScope(H.TR)) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = q.IN_TABLE_BODY, Za(e, t));
			break;
		case H.BODY:
		case H.CAPTION:
		case H.COL:
		case H.COLGROUP:
		case H.HTML:
		case H.TD:
		case H.TH: break;
		default: za(e, t);
	}
}
function eo(e, t) {
	let n = t.tagID;
	Wa.has(n) ? (e.openElements.hasInTableScope(H.TD) || e.openElements.hasInTableScope(H.TH)) && (e._closeTableCell(), Qa(e, t)) : Y(e, t);
}
function to(e, t) {
	let n = t.tagID;
	switch (n) {
		case H.TD:
		case H.TH:
			e.openElements.hasInTableScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = q.IN_ROW);
			break;
		case H.TABLE:
		case H.TBODY:
		case H.TFOOT:
		case H.THEAD:
		case H.TR:
			e.openElements.hasInTableScope(n) && (e._closeTableCell(), $a(e, t));
			break;
		case H.BODY:
		case H.CAPTION:
		case H.COL:
		case H.COLGROUP:
		case H.HTML: break;
		default: Ta(e, t);
	}
}
function no(e, t) {
	switch (t.tagID) {
		case H.HTML:
			Y(e, t);
			break;
		case H.OPTION:
			e.openElements.currentTagId === H.OPTION && e.openElements.pop(), e._insertElement(t, z.HTML);
			break;
		case H.OPTGROUP:
			e.openElements.currentTagId === H.OPTION && e.openElements.pop(), e.openElements.currentTagId === H.OPTGROUP && e.openElements.pop(), e._insertElement(t, z.HTML);
			break;
		case H.HR:
			e.openElements.currentTagId === H.OPTION && e.openElements.pop(), e.openElements.currentTagId === H.OPTGROUP && e.openElements.pop(), e._appendElement(t, z.HTML), t.ackSelfClosing = !0;
			break;
		case H.INPUT:
		case H.KEYGEN:
		case H.TEXTAREA:
		case H.SELECT:
			e.openElements.hasInSelectScope(H.SELECT) && (e.openElements.popUntilTagNamePopped(H.SELECT), e._resetInsertionMode(), t.tagID !== H.SELECT && e._processStartTag(t));
			break;
		case H.SCRIPT:
		case H.TEMPLATE: J(e, t);
	}
}
function ro(e, t) {
	switch (t.tagID) {
		case H.OPTGROUP:
			e.openElements.stackTop > 0 && e.openElements.currentTagId === H.OPTION && e.openElements.tagIDs[e.openElements.stackTop - 1] === H.OPTGROUP && e.openElements.pop(), e.openElements.currentTagId === H.OPTGROUP && e.openElements.pop();
			break;
		case H.OPTION:
			e.openElements.currentTagId === H.OPTION && e.openElements.pop();
			break;
		case H.SELECT:
			e.openElements.hasInSelectScope(H.SELECT) && (e.openElements.popUntilTagNamePopped(H.SELECT), e._resetInsertionMode());
			break;
		case H.TEMPLATE: Ti(e, t);
	}
}
function io(e, t) {
	let n = t.tagID;
	n === H.CAPTION || n === H.TABLE || n === H.TBODY || n === H.TFOOT || n === H.THEAD || n === H.TR || n === H.TD || n === H.TH ? (e.openElements.popUntilTagNamePopped(H.SELECT), e._resetInsertionMode(), e._processStartTag(t)) : no(e, t);
}
function ao(e, t) {
	let n = t.tagID;
	n === H.CAPTION || n === H.TABLE || n === H.TBODY || n === H.TFOOT || n === H.THEAD || n === H.TR || n === H.TD || n === H.TH ? e.openElements.hasInTableScope(n) && (e.openElements.popUntilTagNamePopped(H.SELECT), e._resetInsertionMode(), e.onEndTag(t)) : ro(e, t);
}
function oo(e, t) {
	switch (t.tagID) {
		case H.BASE:
		case H.BASEFONT:
		case H.BGSOUND:
		case H.LINK:
		case H.META:
		case H.NOFRAMES:
		case H.SCRIPT:
		case H.STYLE:
		case H.TEMPLATE:
		case H.TITLE:
			J(e, t);
			break;
		case H.CAPTION:
		case H.COLGROUP:
		case H.TBODY:
		case H.TFOOT:
		case H.THEAD:
			e.tmplInsertionModeStack[0] = q.IN_TABLE, e.insertionMode = q.IN_TABLE, Ra(e, t);
			break;
		case H.COL:
			e.tmplInsertionModeStack[0] = q.IN_COLUMN_GROUP, e.insertionMode = q.IN_COLUMN_GROUP, qa(e, t);
			break;
		case H.TR:
			e.tmplInsertionModeStack[0] = q.IN_TABLE_BODY, e.insertionMode = q.IN_TABLE_BODY, Xa(e, t);
			break;
		case H.TD:
		case H.TH:
			e.tmplInsertionModeStack[0] = q.IN_ROW, e.insertionMode = q.IN_ROW, Qa(e, t);
			break;
		default: e.tmplInsertionModeStack[0] = q.IN_BODY, e.insertionMode = q.IN_BODY, Y(e, t);
	}
}
function so(e, t) {
	t.tagID === H.TEMPLATE && Ti(e, t);
}
function co(e, t) {
	e.openElements.tmplCount > 0 ? (e.openElements.popUntilTagNamePopped(H.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode(), e.onEof(t)) : hi(e, t);
}
function lo(e, t) {
	t.tagID === H.HTML ? Y(e, t) : fo(e, t);
}
function uo(e, t) {
	if (t.tagID === H.HTML) {
		if (e.fragmentContext || (e.insertionMode = q.AFTER_AFTER_BODY), e.options.sourceCodeLocationInfo && e.openElements.tagIDs[0] === H.HTML) {
			e._setEndLocation(e.openElements.items[0], t);
			let n = e.openElements.items[1];
			n && !e.treeAdapter.getNodeSourceCodeLocation(n)?.endTag && e._setEndLocation(n, t);
		}
	} else fo(e, t);
}
function fo(e, t) {
	e.insertionMode = q.IN_BODY, Ni(e, t);
}
function po(e, t) {
	switch (t.tagID) {
		case H.HTML:
			Y(e, t);
			break;
		case H.FRAMESET:
			e._insertElement(t, z.HTML);
			break;
		case H.FRAME:
			e._appendElement(t, z.HTML), t.ackSelfClosing = !0;
			break;
		case H.NOFRAMES: J(e, t);
	}
}
function mo(e, t) {
	t.tagID === H.FRAMESET && !e.openElements.isRootHtmlElementCurrent() && (e.openElements.pop(), !e.fragmentContext && e.openElements.currentTagId !== H.FRAMESET && (e.insertionMode = q.AFTER_FRAMESET));
}
function ho(e, t) {
	switch (t.tagID) {
		case H.HTML:
			Y(e, t);
			break;
		case H.NOFRAMES: J(e, t);
	}
}
function go(e, t) {
	t.tagID === H.HTML && (e.insertionMode = q.AFTER_AFTER_FRAMESET);
}
function _o(e, t) {
	t.tagID === H.HTML ? Y(e, t) : vo(e, t);
}
function vo(e, t) {
	e.insertionMode = q.IN_BODY, Ni(e, t);
}
function yo(e, t) {
	switch (t.tagID) {
		case H.HTML:
			Y(e, t);
			break;
		case H.NOFRAMES: J(e, t);
	}
}
function bo(e, t) {
	t.chars = "�", e._insertCharacters(t);
}
function xo(e, t) {
	e._insertCharacters(t), e.framesetOk = !1;
}
function So(e) {
	for (; e.treeAdapter.getNamespaceURI(e.openElements.current) !== z.HTML && e.openElements.currentTagId !== void 0 && !e._isIntegrationPoint(e.openElements.currentTagId, e.openElements.current);) e.openElements.pop();
}
function Co(e, t) {
	if (Wr(t)) So(e), e._startTagOutsideForeignContent(t);
	else {
		let n = e._getAdjustedCurrentElement(), r = e.treeAdapter.getNamespaceURI(n);
		r === z.MATHML ? Gr(t) : r === z.SVG && (Jr(t), Kr(t)), qr(t), t.selfClosing ? e._appendElement(t, r) : e._insertElement(t, r), t.ackSelfClosing = !0;
	}
}
function wo(e, t) {
	if (t.tagID === H.P || t.tagID === H.BR) So(e), e._endTagOutsideForeignContent(t);
	else for (let n = e.openElements.stackTop; n > 0; n--) {
		let r = e.openElements.items[n];
		if (e.treeAdapter.getNamespaceURI(r) === z.HTML) {
			e._endTagOutsideForeignContent(t);
			break;
		}
		let i = e.treeAdapter.getTagName(r);
		if (i.toLowerCase() === t.tagName) {
			t.tagName = i, e.openElements.shortenToLength(n);
			break;
		}
	}
}
// node_modules/entities/dist/escape.js
function To(e) {
	return e === 34 ? "&quot;" : e === 38 ? "&amp;" : e === 39 ? "&apos;" : e === 60 ? "&lt;" : e === 62 ? "&gt;" : "&nbsp;";
}
function Eo(e, t) {
	if (e.lastIndex = 0, !e.test(t)) return t;
	let n = "", r = 0;
	do {
		let i = e.lastIndex - 1;
		r !== i && (n += t.substring(r, i));
		let a = t.charCodeAt(i);
		n += To(a), r = i + 1;
	} while (e.test(t));
	return n + t.substring(r);
}
var Do = /["&\u{A0}]/gu;
function Oo(e) {
	return Eo(Do, e);
}
var ko = /[&<>\u{A0}]/gu;
function Ao(e) {
	return Eo(ko, e);
}
// node_modules/parse5/dist/serializer/index.js
var jo = /* @__PURE__ */ new Set([
	V.AREA,
	V.BASE,
	V.BASEFONT,
	V.BGSOUND,
	V.BR,
	V.COL,
	V.EMBED,
	V.FRAME,
	V.HR,
	V.IMG,
	V.INPUT,
	V.KEYGEN,
	V.LINK,
	V.META,
	V.PARAM,
	V.SOURCE,
	V.TRACK,
	V.WBR
]);
function Mo(e, t) {
	return t.treeAdapter.isElementNode(e) && t.treeAdapter.getNamespaceURI(e) === z.HTML && jo.has(t.treeAdapter.getTagName(e));
}
var No = {
	treeAdapter: K,
	scriptingEnabled: !0
};
function Po(e, t) {
	return Io(e, {
		...No,
		...t
	});
}
function Fo(e, t) {
	let n = "", r = t.treeAdapter.isElementNode(e) && t.treeAdapter.getTagName(e) === V.TEMPLATE && t.treeAdapter.getNamespaceURI(e) === z.HTML ? t.treeAdapter.getTemplateContent(e) : e, i = t.treeAdapter.getChildNodes(r);
	if (i) for (let e of i) n += Io(e, t);
	return n;
}
function Io(e, t) {
	return t.treeAdapter.isElementNode(e) ? Lo(e, t) : t.treeAdapter.isTextNode(e) ? zo(e, t) : t.treeAdapter.isCommentNode(e) ? Bo(e, t) : t.treeAdapter.isDocumentTypeNode(e) ? Vo(e, t) : "";
}
function Lo(e, t) {
	let n = t.treeAdapter.getTagName(e);
	return `<${n}${Ro(e, t)}>${Mo(e, t) ? "" : `${Fo(e, t)}</${n}>`}`;
}
function Ro(e, { treeAdapter: t }) {
	let n = "";
	for (let r of t.getAttrList(e)) {
		if (n += " ", r.namespace) switch (r.namespace) {
			case z.XML:
				n += `xml:${r.name}`;
				break;
			case z.XMLNS:
				r.name !== "xmlns" && (n += "xmlns:"), n += r.name;
				break;
			case z.XLINK:
				n += `xlink:${r.name}`;
				break;
			default: n += `${r.prefix}:${r.name}`;
		}
		else n += r.name;
		n += `="${Oo(r.value)}"`;
	}
	return n;
}
function zo(e, t) {
	let { treeAdapter: n } = t, r = n.getTextNodeContent(e), i = n.getParentNode(e), a = i && n.isElementNode(i) && n.getTagName(i);
	return a && n.getNamespaceURI(i) === z.HTML && $n(a, t.scriptingEnabled) ? r : Ao(r);
}
function Bo(e, { treeAdapter: t }) {
	return `<!--${t.getCommentNodeContent(e)}-->`;
}
function Vo(e, { treeAdapter: t }) {
	return `<!DOCTYPE ${t.getDocumentTypeNodeName(e)}>`;
}
// node_modules/parse5/dist/index.js
function Ho(e, t) {
	return ii.parse(e, t);
}
function Uo(e, t, n) {
	typeof e == "string" && (n = t, t = e, e = null);
	let r = ii.getFragmentParser(e, n);
	return r.tokenizer.write(t, !0), r.getFragment();
}
// src/local/version.ts
var Wo = "local-draft-3", Go = /* @__PURE__ */ new Set([
	"table",
	"caption",
	"colgroup",
	"col",
	"thead",
	"tbody",
	"tfoot",
	"tr",
	"th",
	"td"
]), Ko = {
	colgroup: /* @__PURE__ */ new Set(["span"]),
	col: /* @__PURE__ */ new Set(["span"]),
	td: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"align"
	]),
	th: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"scope",
		"abbr",
		"align"
	])
};
function qo(e, t) {
	let n = t.trim();
	return [
		"colspan",
		"rowspan",
		"span"
	].includes(e) ? /^\d{1,5}$/.test(n) && Number(n) <= (e === "rowspan" ? 65534 : 1e3) && Number(n) >= (e === "rowspan" ? 0 : 1) : e === "align" ? ne(t) !== null : e !== "scope" || [
		"row",
		"col",
		"rowgroup",
		"colgroup"
	].includes(n.toLowerCase());
}
var Jo = {
	table: [
		"caption",
		"colgroup",
		"thead",
		"tbody",
		"tfoot"
	],
	colgroup: ["col"],
	thead: ["tr"],
	tbody: ["tr"],
	tfoot: ["tr"],
	tr: ["th", "td"],
	col: []
};
function Yo(e, t, n) {
	let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, t + 80));
	if (!r) return null;
	let i = "";
	for (let a = t + r[0].length; a < n; a++) {
		let t = e[a];
		if (i) t === i && (i = "");
		else if (t === "\"" || t === "'") i = t;
		else if (t === ">") return {
			name: r[2].toLowerCase(),
			closing: !!r[1],
			end: a + 1
		};
	}
	return null;
}
function Xo(e, t, n) {
	let r = "", i = "";
	if (e.startsWith("\\(", t) ? (r = "\\(", i = "\\)") : e.startsWith("\\[", t) ? (r = "\\[", i = "\\]") : e[t] === "$" && (r = e[t + 1] === "$" ? "$$" : "$", i = r), !r) return null;
	for (let a = t + r.length; a < n; a++) {
		if (e.startsWith(i, a)) return r === "$" && (/^\s|\s$/.test(e.slice(t + 1, a)) || /\d/.test(e[a + 1] ?? "")) ? null : a + i.length;
		if (e[a] === "\\" && a++, r === "$" && e[a] === "\n") return null;
	}
	return r === "$" ? null : n;
}
function Zo(e, t, n, r) {
	let i = Yo(e, t, n);
	if (!i || i.closing || i.name !== "table") return null;
	let a = 0, o = 0, s = n, c = !1, l = !1, u = [];
	for (let i = t; i < n;) {
		let t = Xo(e, i, n);
		if (t !== null) {
			i = t;
			continue;
		}
		let d = r.shield(i, n);
		if (d !== null) {
			i = d;
			continue;
		}
		if (e.startsWith("<!--", i)) {
			let t = e.indexOf("-->", i + 4);
			i = t < 0 ? n : Math.min(n, t + 3);
			continue;
		}
		if (e[i] !== "<") {
			i++;
			continue;
		}
		let f = Yo(e, i, n);
		if (!f) i++;
		else if (!f.closing && [
			"pre",
			"code",
			"script",
			"style"
		].includes(f.name)) {
			let t = RegExp(`</${f.name}\\s*>`, "gi");
			t.lastIndex = f.end;
			let r = t.exec(e);
			i = r && r.index < n ? r.index + r[0].length : n;
		} else {
			if (Go.has(f.name) && (u.push({
				start: i,
				end: f.end
			}), o++, f.name !== "table" && (l = !0), l && r.budget(i, o), f.name === "table" && (a += f.closing ? -1 : 1, a === 0))) {
				s = f.end, c = !0;
				break;
			}
			i = f.end;
		}
	}
	if (!l) return null;
	c || r.problem("unclosed", t, s, "table");
	let d = e.slice(t, s).replace(/[^\r\n]/g, " ").split("");
	for (let n of u) for (let r = n.start; r < n.end; r++) d[r - t] = e[r];
	let f = Uo(d.join(""), { sourceCodeLocationInfo: !0 }).childNodes.find((e) => e.tagName === "table");
	if (!f) return r.problem("structure", t, s), {
		node: r.node("htmlTable", t, s, { children: [] }),
		end: s
	};
	let p = (e) => {
		let n = e.sourceCodeLocation;
		if (n) return {
			start: t + n.startOffset,
			end: t + n.endOffset
		};
		let r = (e.childNodes ?? []).filter((e) => e.tagName);
		return r.length ? {
			start: p(r[0]).start,
			end: p(r.at(-1)).end
		} : {
			start: t,
			end: t
		};
	}, m = (t, n) => !e.slice(t, n).replace(/<!--[\s\S]*?-->/g, "").trim(), ee = (e, n) => {
		let i = e.tagName, a = e.sourceCodeLocation, o = p(e);
		if (n > 120) return r.problem("structure", o.start, o.end, i), r.node("htmlTableElement", o.start, o.end, {
			name: i,
			children: []
		});
		let s = a?.startTag ? r.attributes(i, t + a.startTag.startOffset, t + a.startTag.endOffset) : {}, c, l = a?.startTag ? t + a.startTag.endOffset : o.start, u = a?.endTag ? t + a.endTag.startOffset : o.end, d = (e.childNodes ?? []).filter((e) => e.tagName);
		if (i === "table" && [
			"caption",
			"thead",
			"tfoot"
		].some((e) => d.filter((t) => t.tagName === e).length > 1) && r.problem("structure", o.start, o.end, i), i === "colgroup" && s.span !== void 0 && d.length > 0 && r.problem("structure", o.start, o.end, i), i === "td" || i === "th" || i === "caption") c = r.content(l, u);
		else {
			c = [];
			let e = l;
			for (let t of d) {
				let a = p(t);
				m(e, a.start) || r.problem("mixed", e, a.start, i), (Jo[i] ?? []).includes(t.tagName) ? c.push(ee(t, n + 1)) : r.problem("structure", a.start, a.end, i), e = a.end;
			}
			m(e, u) || r.problem("mixed", e, u, i);
		}
		return r.node(i === "table" ? "htmlTable" : "htmlTableElement", o.start, o.end, {
			name: i,
			attrs: s,
			children: c
		});
	};
	return {
		node: ee(f, 0),
		end: s
	};
}
var Qo = Object.freeze([
	Object.freeze({
		name: "computed",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: !0,
				required: !0
			},
			value: {
				kind: "string",
				required: !0
			}
		},
		structure: {
			rule: "none",
			label: "none"
		},
		rules: [{
			kind: "require-full-interpolation",
			attributes: ["value"]
		}]
	}),
	Object.freeze({
		name: "const",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: !0,
				required: !0
			},
			value: {
				kind: "string",
				required: !0
			}
		},
		structure: {
			rule: "none",
			label: "none"
		},
		rules: [{
			kind: "require-full-interpolation",
			attributes: ["value"]
		}]
	}),
	Object.freeze({
		name: "external",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: !0,
				required: !0
			},
			type: {
				kind: "enum",
				static: !0,
				required: !0,
				values: [
					"string",
					"number",
					"boolean",
					"string-array",
					"number-array"
				]
			}
		},
		structure: {
			rule: "none",
			label: "none"
		}
	})
]);
function $o(e, t) {
	let n = Array.from({ length: t.length + 1 }, (e, t) => t);
	for (let r = 1; r <= e.length; r++) {
		let i = n[0];
		n[0] = r;
		for (let a = 1; a <= t.length; a++) {
			let o = n[a];
			n[a] = Math.min(n[a] + 1, n[a - 1] + 1, i + (e[r - 1] === t[a - 1] ? 0 : 1)), i = o;
		}
	}
	return n[t.length];
}
function es(e, t) {
	let n, r = Infinity;
	for (let i of t) {
		let t = $o(e, i);
		t < r && (n = i, r = t);
	}
	return r <= 2 ? n : void 0;
}
// src/sdk/compiler-config.ts
var X = Object.freeze({
	id: "reactive-md/default",
	version: c
}), ts = 16777216, ns = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), rs = /* @__PURE__ */ new Set([
	"protocol",
	"key",
	"presets",
	"components",
	"registry",
	"themes"
]);
function Z(e, t) {
	throw Error(`Invalid local SDK config (${e}): ${t}`);
}
function is(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function as(e, t, n) {
	for (let r of Object.keys(e)) ns.has(r) && Z(n, `field "${r}" is not allowed.`), t.has(r) || Z(n, `unknown field "${r}".`);
}
function os() {
	return Object.freeze([X]);
}
function ss(e) {
	if (e === void 0) return os();
	Array.isArray(e) || Z("presets", "must be an array."), e.length === 0 && Z("presets", "must select at least the default preset.");
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r], a, o;
		typeof i == "string" ? a = i : is(i) ? ((i.id === void 0 || typeof i.id != "string") && Z(`presets[${r}].id`, "must be a string."), a = i.id, i.version !== void 0 && (typeof i.version != "string" && Z(`presets[${r}].version`, "must be a string."), o = i.version)) : Z(`presets[${r}]`, "must be a preset id or preset reference."), (a === "default" ? X.id : a) !== X.id && Z(`presets[${r}]`, `unsupported preset "${a}"; phase one accepts only "${X.id}".`), o !== void 0 && o !== X.version && Z(`presets[${r}].version`, `must be "${X.version}".`), t.has(X.id) && Z("presets", `"${X.id}" is selected more than once.`), t.add(X.id), n.push(X);
	}
	return Object.freeze(n);
}
function cs(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) t.add(n.name), t.add(n.id);
	return t;
}
function ls(e, t) {
	let n = new Map(e.map((e) => [e.id, e])), r = cs(t);
	for (let t of e) {
		let e = t.requires?.kernel;
		e !== void 0 && !l("0.7.0", e) && Z("requires", `component "${t.id}" requires kernel ${e}, but ${c} is installed.`);
		for (let e of t.dependencies ?? []) {
			let i = n.get(e.id)?.version ?? (r.has(e.id) ? "0.7.0" : null);
			i === null && Z("dependencies", `component "${t.id}" requires missing component "${e.id}".`), e.version !== void 0 && !l(i, e.version) && Z("dependencies", `component "${t.id}" requires "${e.id}" ${e.version}, but version ${i} is installed.`);
		}
	}
	let i = /* @__PURE__ */ new Map(), a = (e, t) => {
		let r = i.get(e);
		if (r === "done") return;
		r === "visiting" && Z("dependencies", `dependency cycle: ${[...t, e].join(" -> ")}.`), i.set(e, "visiting");
		let o = n.get(e);
		for (let r of o?.dependencies ?? []) n.has(r.id) && a(r.id, [...t, e]);
		i.set(e, "done");
	};
	for (let e of n.keys()) a(e, []);
}
function us(e, t) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || Z("components", "must be an array."), e.length > 64 && Z("components", "accepts at most 64 external components.");
	let n = new Set([
		...t.map((e) => e.name),
		...Qo.map((e) => e.name),
		...v
	].map((e) => e.toLowerCase()));
	n.add("theme");
	let r = new Set(t.map((e) => e.id)), i = /* @__PURE__ */ new Set(), a = [];
	for (let t = 0; t < e.length; t += 1) {
		let o = s(e[t]);
		n.has(o.name.toLowerCase()) && Z(`components[${t}]`, `name "${o.name}" conflicts with a built-in component, HTML tag or theme declaration.`), r.has(o.id) && Z("components", `component id "${o.id}" is declared more than once.`), i.has(o.name) && Z("components", `component name "${o.name}" is declared more than once.`), r.add(o.id), i.add(o.name), a.push(o);
	}
	return ls(a, t), Object.freeze(a);
}
function ds(e) {
	return [...e].map((e) => ({
		id: e.id,
		version: e.version
	})).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id));
}
function fs(e, n) {
	let i = JSON.stringify({
		protocol: r,
		presets: ds(e),
		components: [...n].map((e) => ({
			id: e.id,
			version: e.version,
			digest: t(e)
		})).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id))
	});
	return a(i);
}
function ps(e, t = []) {
	is(e) || Z("config", "must be an object."), as(e, rs, "config"), e.protocol !== "reactive-md-config/v1" && Z("config.protocol", `must be "${r}".`);
	let n = ss(e.presets), i = t.length > 0 ? n : Object.freeze([]), a = us(e.components, t), s = Object.freeze([]);
	return o({
		protocol: "reactive-md-config/v1",
		presets: i,
		components: a
	}) > ts && Z("config", `serialized size exceeds the ${ts}-byte budget.`), Object.freeze({
		protocol: r,
		key: fs(i, a),
		presets: i,
		components: a,
		registry: Object.freeze([...t, ...a]),
		themes: s
	});
}
// src/local/options-core.ts
var ms = [
	"enableCss",
	"enableJavaScript",
	"enableExtendedHtml"
], hs = X;
function gs(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var _s = "local.options.invalid.host-components", vs = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, ys = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), bs = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), xs = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean"
]), Ss = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]), Cs = /* @__PURE__ */ new Set([
	"maxSyntaxNodes",
	"maxParseWork",
	"maxMarkdownDepth"
]);
function ws(e, t, n) {
	if (!Object.hasOwn(e, t)) return {
		ok: !0,
		value: n
	};
	let r = e[t];
	if (r === void 0) return {
		ok: !0,
		value: n
	};
	if (typeof r != "number" || !Number.isSafeInteger(r) || r < 1) {
		let e = t === "maxSyntaxNodes" ? "max-syntax-nodes" : t === "maxParseWork" ? "max-parse-work" : "max-markdown-depth";
		return {
			ok: !1,
			message: `Compile option limits.${t} must be a positive safe integer.`,
			key: `local.options.invalid.${e}`
		};
	}
	return {
		ok: !0,
		value: r
	};
}
function Q(e) {
	return {
		ok: !1,
		message: `Compile option hostComponents is invalid: ${e}`,
		key: _s,
		detail: e
	};
}
function Ts(e, t) {
	if (e === void 0) return {
		ok: !0,
		binding: void 0
	};
	if (!gs(e)) return Q(`${t} "binding" must be an object.`);
	for (let n of Object.keys(e)) if (![
		"kind",
		"initialRule",
		"min",
		"max",
		"step",
		"options",
		"exclusive"
	].includes(n)) return Q(`${t} "binding" has unknown field "${n}".`);
	let n = e.kind;
	if (typeof n != "string" || !xs.has(n)) return Q(`${t} "binding.kind" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
	let r = { kind: n };
	if (Object.hasOwn(e, "exclusive") && e.exclusive !== void 0) {
		if (typeof e.exclusive != "boolean") return Q(`${t} "binding.exclusive" must be a boolean.`);
		r.exclusive = e.exclusive;
	}
	if (Object.hasOwn(e, "initialRule") && e.initialRule !== void 0) {
		let n = e.initialRule;
		if (typeof n != "string" || ![
			"empty",
			"false",
			"nearest-zero",
			"min",
			"first-option"
		].includes(n)) return Q(`${t} "binding.initialRule" is not supported.`);
		r.initialRule = n;
	}
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (!Object.hasOwn(e, n) || e[n] === void 0) continue;
		if (r.kind !== "number") return Q(`${t} "binding.${n}" is only valid for number bindings.`);
		let i = e[n];
		if (typeof i != "number" || !Number.isFinite(i)) return Q(`${t} "binding.${n}" must be a finite number.`);
		r[n] = i;
	}
	if (r.kind === "number") {
		if (r.step !== void 0 && !(r.step > 0)) return Q(`${t} "binding.step" must be greater than 0.`);
		if (r.min !== void 0 && r.max !== void 0 && r.min > r.max) return Q(`${t} "binding.min" cannot exceed "binding.max".`);
		if (r.initialRule !== void 0 && !["min", "nearest-zero"].includes(r.initialRule)) return Q(`${t} "binding.initialRule" must be "min" or "nearest-zero" for number bindings.`);
		r.initialRule ??= "nearest-zero";
	}
	let i = Object.hasOwn(e, "options") && e.options !== void 0;
	if (i) {
		if (r.kind !== "string") return Q(`${t} "binding.options" is only valid for string bindings.`);
		let n = e.options;
		if (!Array.isArray(n) || n.length === 0) return Q(`${t} "binding.options" must be a non-empty string array.`);
		if (n.length > 64) return Q(`${t} "binding.options" accepts at most 64 values.`);
		let i = /* @__PURE__ */ new Set(), a = [];
		for (let e of n) {
			if (typeof e != "string" || e === "") return Q(`${t} "binding.options" must be a non-empty string array.`);
			if (e.length > 128) return Q(`${t} "binding.options" value exceeds the 128-character limit.`);
			if (i.has(e)) return Q(`${t} "binding.options" value "${e}" is declared more than once.`);
			i.add(e), a.push(e);
		}
		r.options = a, r.initialRule ??= "first-option";
	}
	if (r.kind === "string") {
		let e = i ? "first-option" : "empty";
		if (r.initialRule !== void 0 && r.initialRule !== e) return Q(`${t} "binding.initialRule" must be "${e}" for ${i ? "choice" : "string"} bindings.`);
		r.initialRule ??= e;
	}
	if (r.kind === "boolean") {
		if (r.initialRule !== void 0 && r.initialRule !== "false") return Q(`${t} "binding.initialRule" must be "false" for boolean bindings.`);
		r.initialRule ??= "false";
	}
	return {
		ok: !0,
		binding: r
	};
}
function Es(e, t) {
	let r = [], i = /* @__PURE__ */ new Map();
	if (e === void 0) return {
		ok: !0,
		hostComponents: r,
		hostByName: i
	};
	if (!Array.isArray(e)) return Q("must be an array.");
	if (e.length > 32) return Q("accepts at most 32 components.");
	let a = /* @__PURE__ */ new Set();
	for (let e of t) a.add(e.name.toLowerCase());
	for (let e of Qo) a.add(e.name.toLowerCase());
	for (let e of v) a.add(e.toLowerCase());
	a.add("theme");
	for (let t = 0; t < e.length; t += 1) {
		let o = e[t], s = `hostComponents[${t}]`;
		if (!gs(o)) return Q(`${s} must be an object.`);
		let c = o.name;
		if (typeof c != "string") return Q(`${s} "name" must be a string.`);
		if (c.length > 128) return Q(`${s} "name" exceeds the 128-character limit.`);
		if (!vs.test(c)) return Q(`${s} "name" ${c} must use lowercase kebab-case.`);
		if (a.has(c.toLowerCase())) return Q(`${s} "name" ${c} conflicts with a built-in component, HTML tag or theme.`);
		if (i.has(c.toLowerCase())) return Q(`${s} "name" ${c} is declared more than once.`);
		if (typeof o.form != "string" || !bs.has(o.form)) return Q(`${s} "form" must be "leaf", "inline" or "container".`);
		let l = o.form, u = Ts(o.binding, s);
		if (!u.ok) return u;
		let d = u.binding, f = o.props;
		if (!gs(f)) return Q(`${s} "props" must be an object.`);
		let p = {};
		for (let e of Object.keys(f)) {
			if (!vs.test(e)) return Q(`${s} property "${e}" must use lowercase kebab-case.`);
			if (d && Ss.has(e)) return Q(`${s} property "${e}" is reserved by the host binding.`);
			let t = f[e];
			if (!gs(t)) return Q(`${s} property "${e}" must be an object.`);
			let r = t.kind;
			if (typeof r != "string" || !ys.has(r)) return Q(`property "${e}" has unsupported kind ${typeof r == "string" ? `"${r}"` : String(r)}.`);
			let i = { kind: r };
			for (let n of ["required", "static"]) if (Object.hasOwn(t, n) && t[n] !== void 0) {
				if (typeof t[n] != "boolean") return Q(`${s} property "${e}" "${n}" must be a boolean.`);
				i[n] = t[n];
			}
			let a = Object.hasOwn(t, "enum") && t.enum !== void 0;
			if (r !== "enum") {
				if (a) return Q(`${s} property "${e}" has "enum" but kind is "${r}".`);
			} else {
				let n = t.enum;
				if (!Array.isArray(n) || n.length === 0) return Q(`${s} property "${e}" "enum" must be a non-empty string array.`);
				if (n.length > 64) return Q(`${s} property "${e}" "enum" accepts at most 64 values.`);
				let r = /* @__PURE__ */ new Set();
				for (let t of n) {
					if (typeof t != "string") return Q(`${s} property "${e}" "enum" must be a non-empty string array.`);
					if (t.length > 128) return Q(`${s} property "${e}" enum value exceeds the 128-character limit.`);
					if (r.has(t)) return Q(`${s} property "${e}" enum value "${t}" is declared more than once.`);
					r.add(t);
				}
				i.enum = [...n];
			}
			let o = Object.hasOwn(t, "pattern") && t.pattern !== void 0;
			if (r !== "string") {
				if (o) return Q(`${s} property "${e}" has "pattern" but kind is "${r}".`);
			} else if (o) {
				let r = t.pattern;
				if (typeof r != "string") return Q(`${s} property "${e}" "pattern" must be a string.`);
				if (r.length > 512) return Q(`${s} property "${e}" "pattern" exceeds the 512-character limit.`);
				try {
					new RegExp(r);
				} catch {
					return Q(`${s} property "${e}" "pattern" is not a valid regular expression.`);
				}
				if (!n(r)) return Q(`${s} property "${e}" "pattern" uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected.`);
				i.pattern = r;
			}
			p[e] = i;
		}
		let m = {
			name: c,
			form: l,
			props: p,
			...d ? { binding: d } : {}
		};
		r.push(m), i.set(c, m);
	}
	return {
		ok: !0,
		hostComponents: r,
		hostByName: i
	};
}
function Ds(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Os(e) {
	let t = e.static === !0 || e.dynamic === !1;
	if (e.kind === "enum") {
		let n = `^(?:${(e.enum ?? []).map(Ds).join("|")})$`;
		if (n.length <= 512) return {
			kind: "string",
			...e.required === !0 ? { required: !0 } : {},
			...t ? { static: !0 } : {},
			pattern: n
		};
	}
	let n = { kind: e.kind };
	return e.required === !0 && e.default === void 0 && (n.required = !0), t && (n.static = !0), e.enum && (n.enum = [...e.enum]), e.pattern !== void 0 && (n.pattern = e.pattern), n;
}
function ks(t) {
	let n = [], r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let a of t.components) {
		let t = {};
		for (let e of Object.keys(a.props)) t[e] = Os(a.props[e]);
		let o = e(a), s = {
			name: a.name,
			form: a.form,
			props: t,
			...o ? { binding: o } : {}
		};
		n.push(s), r.set(a.name, s), i.set(a.name, a);
	}
	return {
		hostComponents: n,
		hostByName: r,
		sdkByName: i
	};
}
function As(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.name, t);
	let r = /* @__PURE__ */ new Map();
	for (let e of t.values()) r.set(e.name, e);
	for (let e of Qo) r.has(e.name) || r.set(e.name, e);
	return {
		componentByName: n,
		schemaByName: r
	};
}
function js(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.name, re(n));
	return t;
}
function Ms(e, t) {
	let n = t.defaults, r = new Set(n.map((e) => e.name));
	if (e !== void 0 && !gs(e)) return {
		ok: !1,
		message: "Compile options must be an object.",
		key: "local.options.invalid.object"
	};
	let a = e ?? {}, o = {
		enableCss: !1,
		enableJavaScript: !1,
		enableExtendedHtml: !1
	};
	for (let e of ms) {
		if (!Object.hasOwn(a, e)) continue;
		let t = a[e];
		if (t !== void 0) {
			if (typeof t != "boolean") return {
				ok: !1,
				message: `Compile option ${e} must be a boolean.`,
				key: "local.options.invalid.html-flag"
			};
			o[e] = t;
		}
	}
	let s = !1;
	if (Object.hasOwn(a, "markdownBreaks")) {
		let e = a.markdownBreaks;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option markdownBreaks must be a boolean.",
				key: "local.options.invalid.markdown-breaks"
			};
			s = e;
		}
	}
	let c = !0;
	if (Object.hasOwn(a, "strict")) {
		let e = a.strict;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option strict must be a boolean.",
				key: "local.options.invalid.strict"
			};
			c = e;
		}
	}
	let l = a.limits, f = u, p = d, m = i;
	if (l !== void 0) {
		if (!gs(l)) return {
			ok: !1,
			message: "Compile option limits must be an object.",
			key: "local.options.invalid.limits"
		};
		for (let e of Object.keys(l)) if (!Cs.has(e) && l[e] !== void 0) return {
			ok: !1,
			message: `Compile option limits.${e} is not supported.`,
			key: "local.options.invalid.limits-unknown",
			detail: e
		};
		let e = ws(l, "maxSyntaxNodes", f);
		if (!e.ok) return e;
		f = e.value;
		let t = ws(l, "maxParseWork", p);
		if (!t.ok) return t;
		p = t.value;
		let n = ws(l, "maxMarkdownDepth", m);
		if (!n.ok) return n;
		m = n.value;
	}
	let ee = Object.hasOwn(a, "config") && a.config !== void 0, h = Object.hasOwn(a, "hostComponents") && a.hostComponents !== void 0;
	if (ee && h) return {
		ok: !1,
		message: "Compile option config cannot be combined with hostComponents.",
		key: "local.options.invalid.config-conflict"
	};
	let g, _, te, v, y, ne, re, ie, ae;
	if (ee) {
		try {
			g = t.readConfig(a.config, n);
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			return {
				ok: !1,
				message: `Compile option config is invalid: ${t}`,
				key: "local.options.invalid.config",
				detail: t
			};
		}
		let e = ks(g);
		_ = e.hostComponents, te = e.hostByName, v = e.sdkByName, y = g.registry;
		let r = As(y, js(y));
		ne = r.schemaByName, re = r.componentByName, ie = new Set(g.components.map((e) => e.name)), ae = /* @__PURE__ */ new Set();
	} else if (h) {
		let e = Es(a.hostComponents, n);
		if (!e.ok) return e;
		_ = e.hostComponents, te = e.hostByName, v = /* @__PURE__ */ new Map(), y = n;
		let t = js(n);
		for (let [n, r] of e.hostByName) t.set(n, Object.freeze({
			...r,
			legacyHost: !0
		}));
		let r = As(n, t);
		ne = r.schemaByName, re = r.componentByName, ie = new Set(e.hostByName.keys()), ae = new Set(e.hostByName.keys());
	} else {
		_ = [], te = /* @__PURE__ */ new Map(), v = /* @__PURE__ */ new Map(), y = n;
		let e = As(n, js(n));
		ne = e.schemaByName, re = e.componentByName, ie = /* @__PURE__ */ new Set(), ae = /* @__PURE__ */ new Set();
	}
	return {
		ok: !0,
		maxSyntaxNodes: f,
		maxParseWork: p,
		maxMarkdownDepth: m,
		html: o,
		htmlActive: o.enableCss || o.enableJavaScript || o.enableExtendedHtml,
		markdownBreaks: s,
		strict: c,
		hostComponents: _,
		hostByName: te,
		...g ? { config: g } : {},
		sdkByName: v,
		registry: y,
		componentByName: re,
		schemaByName: ne,
		defaultComponentNames: r,
		externalComponentNames: ie,
		legacyHostNames: ae,
		componentConfigKey: g ? t.configKey(g) : t.defaultConfigKey,
		...t.preset ? { preset: t.preset } : {}
	};
}
function Ns(e, t = []) {
	let n = t.length > 0 ? hs : void 0, r = n ? [n] : [];
	return Ms(e, {
		defaults: t,
		...n ? { preset: n } : {},
		defaultConfigKey: fs(r, []),
		readConfig: ps,
		configKey: (e) => e.key
	});
}
function Ps(e) {
	return e.componentConfigKey;
}
// src/local/validation.ts
var Fs = "local.validation.failed", Is = "local.validation.expression", Ls = "Validation failed.";
function Rs(e) {
	return e.length > 2e3 ? `${e.slice(0, ee - 1)}…` : e;
}
function zs(e) {
	let t = e.trim();
	return t ? t.split(/\s+/) : [];
}
function Bs(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function Vs(e) {
	if (!e || typeof e != "object") return !1;
	let t = e, n = t.range;
	return typeof t.expression == "string" && typeof t.message == "string" && Array.isArray(t.fields) && !!n && Number.isFinite(n.start) && Number.isFinite(n.end);
}
function Hs(e, t, n, r, i) {
	let a = e.length, o = Math.max(0, Math.min(a, Math.trunc(n.start))), s = Math.max(o + 1, Math.min(a, Math.trunc(n.end))), c = 0, l = Math.max(0, t.length - 1);
	for (; c < l;) {
		let e = Math.ceil((c + l) / 2);
		t[e] <= o ? c = e : l = e - 1;
	}
	return {
		code: r,
		message: i,
		severity: "error",
		range: {
			start: o,
			end: s
		},
		line: c + 1,
		column: o - t[c] + 1
	};
}
// src/local/html.ts
var Us = "http://www.w3.org/1999/xhtml", Ws = /* @__PURE__ */ new Set([
	"b",
	"strong",
	"i",
	"em",
	"s",
	"del",
	"u",
	"mark",
	"sup",
	"sub",
	"br",
	"hr",
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"div",
	"span",
	"details",
	"summary",
	"blockquote",
	"code",
	"pre",
	"ul",
	"ol",
	"li",
	"a",
	"img",
	...Go
]), Gs = /* @__PURE__ */ new Set([
	"html",
	"head",
	"body"
]), Ks = /* @__PURE__ */ new Set([
	"frameset",
	"frame",
	"noframes",
	"applet"
]), qs = /* @__PURE__ */ new Set([
	"animate",
	"animatemotion",
	"animatetransform",
	"set",
	"discard"
]), Js = /* @__PURE__ */ new Set(/* @__PURE__ */ "alignment-baseline.baseline-shift.clip.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-rendering.cursor.direction.display.dominant-baseline.fill.fill-opacity.fill-rule.filter.flood-color.flood-opacity.font.font-family.font-size.font-size-adjust.font-stretch.font-style.font-variant.font-weight.glyph-orientation-horizontal.glyph-orientation-vertical.image-rendering.kerning.letter-spacing.lighting-color.marker.marker-end.marker-mid.marker-start.mask.opacity.overflow.paint-order.pointer-events.shape-rendering.stop-color.stop-opacity.stroke.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke-width.text-anchor.text-decoration.text-rendering.transform-origin.unicode-bidi.vector-effect.visibility.word-spacing.writing-mode".split(".")), Ys = /* @__PURE__ */ new Set([
	"id",
	"class",
	"title",
	"lang",
	"dir"
]), Xs = /* @__PURE__ */ new Set([
	"align",
	"bgcolor",
	"background",
	"face",
	"text",
	"link",
	"alink",
	"vlink",
	"border",
	"cellpadding",
	"cellspacing",
	"frame",
	"rules",
	"hspace",
	"vspace"
]), Zs = {
	a: g,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...Ko,
	script: /* @__PURE__ */ new Set([
		"type",
		"src",
		"async",
		"defer",
		"nomodule",
		"crossorigin",
		"integrity",
		"referrerpolicy"
	]),
	style: /* @__PURE__ */ new Set(["type", "media"]),
	link: /* @__PURE__ */ new Set([
		"rel",
		"href",
		"type",
		"media",
		"crossorigin",
		"integrity",
		"referrerpolicy",
		"disabled"
	])
}, Qs = {
	href: "link",
	action: "form",
	formaction: "form",
	poster: "image",
	background: "image",
	data: "frame",
	src: "source",
	cite: "link",
	longdesc: "link"
}, $s = 4, ec = class extends Error {
	start;
	end;
	limit;
	constructor(e, t, n) {
		super(`Syntax nodes exceed the limit of ${n}.`), this.start = e, this.end = t, this.limit = n, this.name = "HtmlBudgetError";
	}
};
function tc(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function nc(e, t, n) {
	let r = e.source.length, i = Math.max(0, Math.min(r, t)), a = Math.max(i, Math.min(r, Math.max(i, n))), o = 0, s = e.lines.starts.length - 1;
	for (; o < s;) {
		let t = Math.ceil((o + s) / 2);
		e.lines.starts[t] <= i ? o = t : s = t - 1;
	}
	return {
		start: i,
		end: a,
		line: o + 1,
		column: i - e.lines.starts[o] + 1
	};
}
function $(e, t, n, r, i, a) {
	if (e.diagnostics.length >= 100) return;
	let o = nc(e, r, i), s = y(a?.key ?? t, a?.params);
	e.diagnostics.push({
		code: t,
		message: n,
		severity: "warning",
		range: {
			start: o.start,
			end: o.end
		},
		line: o.line,
		column: o.column,
		messageKey: s.key,
		...s.params ? { params: s.params } : {}
	});
}
function rc(e, t) {
	let n = e.sourceCodeLocation, r = n && Number.isInteger(n.startOffset) ? n.startOffset : 0, i = n && Number.isInteger(n.endOffset) ? n.endOffset : r;
	return {
		start: Math.max(0, Math.min(t.source.length, r)),
		end: Math.max(0, Math.min(t.source.length, i))
	};
}
function ic(e, t, n) {
	let r = e.sourceCodeLocation?.attrs, i = r && (r[t.name] ?? (t.prefix ? r[`${t.prefix}:${t.name}`] : void 0));
	return i && Number.isInteger(i.startOffset) && Number.isInteger(i.endOffset) ? {
		start: i.startOffset,
		end: i.endOffset
	} : rc(e, n);
}
function ac(e, t, n) {
	if (e.budget.nodes += 1, e.budget.nodes > e.maxNodes) throw new ec(t, n, e.maxNodes);
}
function oc(e, t) {
	let n = rc(e, t);
	return t.source.slice(n.start, n.end).replace(/\u0000/g, "�");
}
function sc(e) {
	return K.createTextNode(e.replace(/\u0000/g, "�"));
}
function cc(e) {
	return e.replace(/[\u0000- \u007f-\u009f]+/g, "");
}
function lc(e) {
	let t = /^([a-z][a-z0-9+.-]*):/i.exec(cc(e));
	return t ? t[1].toLowerCase() : null;
}
function uc(e, t) {
	let n = e.trim();
	if (n === "") return !0;
	let r = lc(n);
	return r === null ? !0 : r === "javascript" || r === "vbscript" ? !1 : r === "data" ? t === "image" && /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/i.test(n.replace(/\s+/g, "")) : r === "http" || r === "https" || t === "link" && (r === "mailto" || r === "tel");
}
function dc(e) {
	return Object.hasOwn(Qs, e) || e === "xlink:href";
}
function fc(e, t) {
	return (e === "href" || e === "xlink:href") && t === "image" ? "image" : e === "href" && t === "base" ? "source" : e === "xlink:href" ? "link" : e === "src" ? t === "img" || t === "image" ? "image" : t === "iframe" || t === "frame" || t === "embed" ? "frame" : t === "audio" || t === "video" || t === "source" || t === "track" ? "media" : "source" : Qs[e] ?? "source";
}
function pc(e, t) {
	return Ys.has(t) || t.startsWith("aria-") || t.startsWith("data-") ? !0 : Zs[e]?.has(t) ?? !1;
}
function mc(e) {
	return /^on[a-z]/i.test(e);
}
function hc(e, t) {
	return Js.has(e) ? !0 : t && Xs.has(e);
}
function gc(e) {
	return [...e.enableJavaScript ? ["allow-scripts"] : [], ...e.enableExtendedHtml ? ["allow-forms"] : []].join(" ");
}
function _c(e, t) {
	return e.split(/\s+/).filter(Boolean).filter((e) => {
		let n = e.toLowerCase();
		return n === "allow-same-origin" || n === "allow-top-navigation" || n === "allow-top-navigation-by-user-activation" || n === "allow-parent-navigation" || n === "allow-popups" || n === "allow-popups-to-escape-sandbox" || n === "allow-modals" || n === "allow-downloads" || n === "allow-orientation-lock" || n === "allow-pointer-lock" || n === "allow-presentation" ? !1 : n === "allow-forms" ? t.enableExtendedHtml : n === "allow-scripts" && t.enableJavaScript;
	}).join(" ");
}
function vc(e, t) {
	for (let n of e.childNodes) if (K.isElementNode(n) && n.tagName.toLowerCase() === t) return n;
	return null;
}
function yc(e) {
	let t = "";
	for (let n of e.childNodes) t += Po(n, { scriptingEnabled: !1 });
	return t;
}
function bc(e) {
	return e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function xc(e) {
	return [
		"default-src 'none'",
		e.enableExtendedHtml ? "base-uri 'self' http: https:" : "base-uri 'none'",
		e.enableExtendedHtml ? "form-action http: https:" : "form-action 'none'",
		"object-src 'none'",
		"connect-src 'none'",
		"media-src 'none'",
		"font-src data:",
		"img-src data:",
		e.enableCss ? "style-src 'unsafe-inline'" : "style-src 'none'",
		e.enableJavaScript ? "script-src 'unsafe-inline'" : "script-src 'none'",
		e.enableExtendedHtml ? "frame-src about: data: blob:" : "frame-src 'none'"
	].join("; ");
}
function Sc(e, t) {
	let n = vc(t, "html"), r = n ? vc(n, "head") : null, i = n ? vc(n, "body") : null, a = r ? yc(r) : "", o = yc(i || n || t);
	e.bodyFallbacks.length > 0 && (o = e.bodyFallbacks.map((e) => Po(sc(e), { scriptingEnabled: !1 })).join("") + o);
	let s = bc(xc(e.policy)), c = (e) => (e?.attrs ?? []).map((e) => ` ${e.prefix ? `${e.prefix}:` : ""}${e.name}="${bc(e.value)}"`).join("");
	return `<!doctype html><html${c(n)}><head${c(r)}><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${s}">${a}</head><body${c(i)}>${o}</body></html>`;
}
function Cc(e) {
	let t = e.source.replace(/\u0000/g, "�").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${bc(xc(e.policy))}"></head><body><pre data-local-html-fallback="document">\n${t}</pre></body></html>`;
}
function wc(e, t, n) {
	if (t.depth >= $s) return "";
	let r = t.diagnostics.length, i = () => (kc(t, r), $(t, "local.html.fallback", "Native HTML was safely converted to inert source text.", n.start, n.end), Cc({
		...t,
		source: e
	})), a;
	try {
		a = Ho(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch {
		return i();
	}
	let o = {
		...t,
		source: e,
		lines: { starts: tc(e) },
		depth: t.depth + 1,
		bodyFallbacks: []
	};
	try {
		let e = vc(a, "html");
		if (e) {
			let n = t.diagnostics.length;
			if (!Tc(e, "html", !0, o)) return kc(o, n), Cc(o);
			Ac(e, o, !1);
		}
		return Sc(o, a);
	} catch (e) {
		if (e instanceof ec) throw e;
		return i();
	}
}
function Tc(e, t, n, r) {
	e.sourceCodeLocation;
	let i = [], a = !1, o = !0;
	for (let s of e.attrs) {
		let c = s.name.toLowerCase(), l = s.prefix ? `${s.prefix}:${s.name}` : s.name, u = ic(e, s, r);
		if (n && Go.has(t) && !qo(c, s.value)) o = !1, $(r, "local.html.table", `Invalid value for ${c} on native HTML <${t}>.`, u.start, u.end, {
			key: "html.table.value",
			params: {
				name: c,
				tag: t
			}
		});
		else if (n && c === "align" && te.has(t)) {
			let e = ne(s.value);
			e ? i.push({
				...s,
				value: e
			}) : (o = !1, $(r, "local.html.attribute", "HTML attribute align requires left, center, right or justify.", u.start, u.end, {
				key: "local.html.attribute",
				params: {
					name: l,
					tag: t
				}
			}));
		} else if (mc(c)) {
			if (!r.policy.enableJavaScript) {
				$(r, "local.html.capability", `Author event handler attribute ${l} was disabled by the compile options.`, u.start, u.end, {
					key: "local.html.capability",
					params: { feature: "event handlers" }
				});
				continue;
			}
			i.push(s);
		} else if (c === "style" || hc(c, n)) {
			if (!r.policy.enableCss) {
				$(r, "local.html.capability", `Author style attribute ${l} was disabled by the compile options.`, u.start, u.end, {
					key: "local.html.capability",
					params: { feature: "CSS" }
				});
				continue;
			}
			i.push(s);
		} else if (c === "srcset" || c === "imagesrcset") $(r, "local.html.unsafe-url", `Unsafe URL in attribute ${l} was removed.`, u.start, u.end, {
			key: "local.html.unsafe-url",
			params: { name: l }
		});
		else if (c === "srcdoc" && t === "iframe") {
			let e = wc(s.value, r, u);
			if (e === "") continue;
			s.value = e, i.push(s);
		} else c === "sandbox" && t === "iframe" ? (s.value = _c(s.value, r.policy), a = !0, i.push(s)) : dc(c) && !uc(s.value, fc(c, t)) ? $(r, "local.html.unsafe-url", `Unsafe URL in attribute ${l} was removed.`, u.start, u.end, {
			key: "local.html.unsafe-url",
			params: { name: l }
		}) : c === "target" && /^_(?:top|parent)$/i.test(s.value.trim()) ? $(r, "local.html.capability", `Navigation target ${s.value} was disabled.`, u.start, u.end, {
			key: "local.html.capability",
			params: { feature: "top-level navigation" }
		}) : !r.policy.enableExtendedHtml && !pc(t, c) ? (o = !1, $(r, "local.html.attribute", `HTML attribute ${l} on <${t}> is not supported; the element is shown as source.`, u.start, u.end, {
			key: "local.html.attribute",
			params: {
				name: l,
				tag: t
			}
		})) : i.push(s);
	}
	if (t === "iframe" && !a && i.push({
		name: "sandbox",
		value: gc(r.policy)
	}), t === "a") {
		let e = i.find((e) => e.name.toLowerCase() === "target")?.value, t = i.find((e) => e.name.toLowerCase() === "rel"), n = _(t?.value, e);
		n !== void 0 && (t ? t.value = n : i.push({
			name: "rel",
			value: n
		}));
	}
	return e.attrs = i, o;
}
function Ec(e, t, n) {
	let r = t.diagnostics.length, i = rc(e, t);
	ac(t, i.start, i.end);
	let a = e.tagName.toLowerCase(), o = e.namespaceURI === Us;
	if (Ks.has(a)) return t.bodyFallbacks.push(oc(e, t)), $(t, "local.html.fallback", `HTML element <${a}> requires enableExtendedHtml in this mode; it is shown as source.`, i.start, i.end, {
		key: "local.html.extended",
		params: { name: a }
	}), [];
	if (!o && !t.policy.enableCss && qs.has(a)) return $(t, "local.html.capability", `Author animation <${a}> was disabled by the compile options.`, i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "animation" }
	}), [];
	if (a === "script") return t.policy.enableJavaScript ? Tc(e, a, o, t) ? [e] : Oc(e, t, n, r) : ($(t, "local.html.capability", "Author JavaScript was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "JavaScript" }
	}), []);
	if (a === "style") return t.policy.enableCss ? Tc(e, a, o, t) ? [e] : Oc(e, t, n, r) : ($(t, "local.html.capability", "Author CSS was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "CSS" }
	}), []);
	if (a === "link") return (e.attrs.find((e) => e.name.toLowerCase() === "rel")?.value.toLowerCase() ?? "").split(/\s+/).includes("stylesheet") ? t.policy.enableCss ? Tc(e, a, o, t) ? [e] : Oc(e, t, n, r) : ($(t, "local.html.capability", "Author CSS was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "CSS" }
	}), []) : t.policy.enableExtendedHtml ? Tc(e, a, o, t) ? [e] : Oc(e, t, n, r) : Dc(e, t);
	if (a === "meta") {
		if (!t.policy.enableExtendedHtml) return Dc(e, t);
		let s = e.attrs.find((e) => e.name.toLowerCase() === "http-equiv")?.value.trim().toLowerCase() ?? "";
		return s === "refresh" || s === "content-security-policy" || s === "set-cookie" ? ($(t, "local.html.capability", `Author metadata ${s} was disabled.`, i.start, i.end, {
			key: "local.html.capability",
			params: { feature: "document metadata" }
		}), []) : Tc(e, a, o, t) ? [e] : Oc(e, t, n, r);
	}
	return (a === "title" || a === "html" || a === "head" || a === "body") && !t.policy.enableExtendedHtml && a === "title" || !(o && (Ws.has(a) || Gs.has(a)) || t.policy.enableExtendedHtml) ? Dc(e, t, n) : Tc(e, a, o, t) ? a === "template" ? (Ac(K.getTemplateContent(e), t, !1), [e]) : (Ac(e, t, n), [e]) : Oc(e, t, n, r);
}
function Dc(e, t, n = !1) {
	let r = t.diagnostics.length, i = e.tagName.toLowerCase(), a = rc(e, t);
	return $(t, "local.html.extended", `HTML element <${i}> requires enableExtendedHtml in this mode; it is shown as source.`, a.start, a.end, {
		key: "local.html.extended",
		params: { name: i }
	}), Oc(e, t, n, r);
}
function Oc(e, t, n, r) {
	return kc(t, r), n ? (t.bodyFallbacks.push(oc(e, t)), []) : [sc(oc(e, t))];
}
function kc(e, t) {
	for (let n of e.diagnostics.slice(t)) n.severity === "warning" && (n.code = "local.html.fallback");
}
function Ac(e, t, n) {
	let r = [];
	for (let i of e.childNodes) if (K.isTextNode(i)) ac(t, 0, 0), r.push(i);
	else if (K.isCommentNode(i)) ac(t, 0, 0), r.push(i);
	else if (!K.isDocumentTypeNode(i) && K.isElementNode(i)) {
		let e = i.tagName.toLowerCase(), a = n || e === "head";
		r.push(...Ec(i, t, a));
	}
	e.childNodes = r;
}
function jc(e, t, n) {
	let r = [], i = {
		policy: t,
		source: e,
		lines: { starts: tc(e) },
		diagnostics: r,
		maxNodes: n,
		depth: 0,
		budget: { nodes: 0 },
		bodyFallbacks: [],
		stopped: !1
	}, a;
	try {
		a = Ho(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch (e) {
		return {
			markup: Cc(i),
			diagnostics: [{
				code: "local.parse",
				message: `Cannot parse the HTML document: ${e instanceof Error ? e.message : String(e)}`,
				severity: "error",
				range: {
					start: 0,
					end: 0
				},
				line: 1,
				column: 1,
				messageKey: "local.parse.document",
				params: { detail: e instanceof Error ? e.message : String(e) }
			}]
		};
	}
	try {
		let e = vc(a, "html");
		if (e) {
			let t = i.diagnostics.length;
			if (!Tc(e, "html", !0, i)) return kc(i, t), {
				markup: Cc(i),
				diagnostics: r
			};
			Ac(e, i, !1);
		} else Ac(a, i, !1);
		return {
			markup: Sc(i, a),
			diagnostics: r
		};
	} catch (e) {
		if (e instanceof ec) {
			let t = nc(i, e.start, e.end);
			return {
				markup: Cc(i),
				diagnostics: [{
					code: "local.budget",
					message: e.message,
					severity: "error",
					range: {
						start: t.start,
						end: t.end
					},
					line: t.line,
					column: t.column,
					messageKey: "local.budget.nodes",
					params: { limit: e.limit }
				}]
			};
		}
		return {
			markup: Cc(i),
			diagnostics: [{
				code: "local.parse",
				message: `Cannot parse the HTML document: ${e instanceof Error ? e.message : String(e)}`,
				severity: "error",
				range: {
					start: 0,
					end: 0
				},
				line: 1,
				column: 1,
				messageKey: "local.parse.document",
				params: { detail: e instanceof Error ? e.message : String(e) }
			}]
		};
	}
}
export { b as $, gn as A, on as B, Po as C, Sn as D, V as E, an as F, rn as G, Wt as H, fn as I, Vt as J, Jt as K, nn as L, $t as M, Zt as N, bn as O, cn as P, dn as Q, hn as R, Uo as S, z as T, Ut as U, ln as V, Gt as W, Kt as X, Ht as Y, zt as Z, Ko as _, Ls as a, Lt as at, qo as b, Bs as c, ms as d, Ze as et, Ps as f, es as g, Qo as h, Fs as i, ct as it, mn as j, xn as k, zs as l, Ms as m, jc as n, It as nt, Rs as o, se as ot, Ns as p, Bt as q, Is as r, lt as rt, Vs as s, oe as st, gc as t, At as tt, Hs as u, Go as v, K as w, Wo as x, Zo as y, tn as z };
